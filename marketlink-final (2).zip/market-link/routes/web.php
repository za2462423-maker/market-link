<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\FarmerController;
use App\Http\Controllers\FarmerOrderController;
use App\Http\Controllers\FarmerProductController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\PreorderController;
use App\Http\Controllers\ReviewController;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| MarketLink — public storefront
|--------------------------------------------------------------------------
*/
Route::get('/', fn() => view('index'))->name('home');
Route::get('/about', fn() => view('about'))->name('about');
Route::get('/contact', fn() => view('contact'))->name('contact');
Route::get('/farmers', fn() => view('farmers'))->name('farmers');
Route::get('/markets', fn() => view('markets'))->name('markets');
Route::get('/products', function () {
    return view('products', [
        'products' => Product::where('is_available', true)->where('stock', '>', 0)->with('farmer')->latest()->get(),
        'farmers' => User::where('role', User::ROLE_FARMER)->where('is_active', true)->with('farmer')->get(),
    ]);
})->name('products');
Route::get('/cart', fn() => view('cart'))->name('cart');
Route::get('/sitemap', fn() => view('sitemap'))->name('sitemap');
Route::get('/ai-assistant', fn() => view('ai-assistant'))->name('ai-assistant');
Route::get('/product-details', function () {
    return view('product-details', [
        'products' => Product::where('is_available', true)->with('farmer')->latest()->get(),
    ]);
})->name('product-details');
Route::get('/market-details', fn() => view('market-details'))->name('market-details');

/*
|--------------------------------------------------------------------------
| Authentication (SRS: secure registration + role-based login)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'loginCustomer'])->name('login.attempt');

    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'registerCustomer'])->name('register.attempt');

    Route::get('/farmer-login', [AuthController::class, 'showFarmerLogin'])->name('farmer.login');
    Route::post('/farmer-login', [AuthController::class, 'loginFarmer'])->name('farmer.login.attempt');

    Route::get('/farmer-register', [AuthController::class, 'showFarmerRegister'])->name('farmer.register');
    Route::post('/farmer-register', [AuthController::class, 'registerFarmer'])->name('farmer.register.attempt');

    Route::get('/admin-login', [AuthController::class, 'showAdminLogin'])->name('admin.login');
    Route::post('/admin-login', [AuthController::class, 'loginAdmin'])->name('admin.login.attempt');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

/* Farmer public profile (guests see demo, farmers see their own live data) */
Route::get('/farmer-profile', [FarmerController::class, 'profile'])->name('farmer.profile');

/*
|--------------------------------------------------------------------------
| Farmer area — auth + role:farmer
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:farmer'])->group(function () {
    Route::get('/farmer-dashboard', [FarmerController::class, 'dashboard'])->name('farmer.dashboard');
    Route::get('/farmer-reviews', [FarmerController::class, 'reviews'])->name('farmer.reviews');
    Route::get('/farmer-profile/edit', [FarmerController::class, 'editProfile'])->name('farmer.profile.edit');
    Route::put('/farmer-profile', [FarmerController::class, 'updateProfile'])->name('farmer.profile.update');
    Route::put('/farmer-password', [FarmerController::class, 'updatePassword'])->name('farmer.password.update');

    // Real product catalogue (CRUD + availability toggle).
    Route::get('/farmer-products', [FarmerProductController::class, 'index'])->name('farmer.products');
    Route::get('/farmer-add-product', [FarmerProductController::class, 'create'])->name('farmer.add-product');
    Route::post('/farmer-products', [FarmerProductController::class, 'store'])->name('farmer.products.store');
    Route::get('/farmer-products/{id}/edit', [FarmerProductController::class, 'edit'])->name('farmer.products.edit');
    Route::put('/farmer-products/{id}', [FarmerProductController::class, 'update'])->name('farmer.products.update');
    Route::delete('/farmer-products/{id}', [FarmerProductController::class, 'destroy'])->name('farmer.products.destroy');
    Route::post('/farmer-products/{id}/toggle', [FarmerProductController::class, 'toggle'])->name('farmer.products.toggle');

    // Real incoming orders.
    Route::get('/farmer-orders', [FarmerOrderController::class, 'index'])->name('farmer.orders');
    Route::post('/farmer-orders/{id}/status', [FarmerOrderController::class, 'updateStatus'])->name('farmer.orders.status');
});

/*
|--------------------------------------------------------------------------
| Customer area — auth + role:customer
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:customer'])->group(function () {
    Route::get('/customer-dashboard', [CustomerController::class, 'dashboard'])->name('customer.dashboard');
    Route::get('/customer-orders', [CustomerController::class, 'orders'])->name('customer.orders');
    Route::get('/customer-favorites', [CustomerController::class, 'favorites'])->name('customer.favorites');
    Route::get('/customer-reviews', [CustomerController::class, 'reviews'])->name('customer.reviews');
    Route::get('/customer-profile', [CustomerController::class, 'profile'])->name('customer.profile');
    Route::put('/customer-profile', [CustomerController::class, 'updateProfile'])->name('customer.profile.update');
    Route::put('/customer-password', [CustomerController::class, 'updatePassword'])->name('customer.password.update');
    Route::get('/preorder', fn() => view('preorder'))->name('preorder');

    // Real pre-orders, favorites and reviews.
    Route::post('/preorder', [PreorderController::class, 'store'])->name('preorder.store');
    Route::post('/customer-orders/{id}/cancel', [PreorderController::class, 'cancel'])->name('customer.orders.cancel');
    Route::post('/favorites/toggle', [FavoriteController::class, 'toggle'])->name('favorites.toggle');
    Route::post('/reviews', [ReviewController::class, 'store'])->name('reviews.store');
    Route::delete('/reviews/{id}', [ReviewController::class, 'destroy'])->name('reviews.destroy');
});

/*
|--------------------------------------------------------------------------
| Shared order details — customers + farmers
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:customer,farmer'])->group(function () {
    Route::get('/order-details', [CustomerController::class, 'orderDetails'])->name('order-details');
});

/*
|--------------------------------------------------------------------------
| Admin area — auth + role:admin
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin-dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/admin-farmers', [AdminController::class, 'farmers'])->name('admin.farmers');
    Route::get('/admin-customers', [AdminController::class, 'customers'])->name('admin.customers');
    Route::get('/admin-markets', [AdminController::class, 'markets'])->name('admin.markets');
    Route::get('/admin-products', [AdminController::class, 'products'])->name('admin.products');
    Route::get('/admin-orders', [AdminController::class, 'orders'])->name('admin.orders');
    Route::get('/admin-reviews', [AdminController::class, 'reviews'])->name('admin.reviews');
    Route::get('/admin-reports', [AdminController::class, 'reports'])->name('admin.reports');

    // Real account moderation.
    Route::post('/admin-farmers/{user}/toggle', [AdminController::class, 'toggleFarmer'])->name('admin.farmers.toggle');
    Route::delete('/admin-farmers/{user}', [AdminController::class, 'destroyFarmer'])->name('admin.farmers.destroy');
    Route::post('/admin-customers/{user}/toggle', [AdminController::class, 'toggleCustomer'])->name('admin.customers.toggle');
    Route::delete('/admin-customers/{user}', [AdminController::class, 'destroyCustomer'])->name('admin.customers.destroy');
});

/*
|--------------------------------------------------------------------------
| Public form handlers (demo: validate + bounce back with flash)
|--------------------------------------------------------------------------
*/
Route::post('/contact', function () {
    request()->validate([
        'name' => 'nullable|string|max:255',
        'contactName' => 'nullable|string|max:255',
        'email' => 'nullable|email',
        'contactEmail' => 'nullable|email',
        'message' => 'nullable|string',
        'contactMessage' => 'nullable|string',
    ]);
    return back()->with('success', 'Message sent! We will get back to you soon.');
})->name('contact.send');

Route::post('/newsletter', function () {
    request()->validate(['newsletter_email' => 'required|email']);
    return back()->with('success', 'Subscribed successfully! Welcome to MarketLink.');
})->name('newsletter.subscribe');

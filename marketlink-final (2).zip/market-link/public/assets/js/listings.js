/* ============================================================
   MarketLink — Listings
   Farmers/Markets: filter static cards. Products: render + filter
   + sort + grid/list + quick view from window.ML mock data.
   ============================================================ */
(function () {
    'use strict';

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function stars(rating) {
        var r = parseFloat(rating) || 0, out = '';
        for (var i = 1; i <= 5; i++) {
            out += i <= Math.round(r) ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
        }
        return out;
    }
    function setCount(el, n, singular, plural) {
        if (!el) return;
        el.textContent = 'Showing ' + n + ' ' + (n === 1 ? singular : plural);
    }

    document.addEventListener('DOMContentLoaded', function () {
        var ML = window.ML || { markets: [], farmers: [], products: [], categories: [] };

        /* ================= FARMERS (filter static cards) ================= */
        var farmersGrid = document.getElementById('farmersGrid');
        if (farmersGrid) {
            var items = Array.prototype.slice.call(farmersGrid.querySelectorAll('.farmer-item'));
            var searchEl = document.getElementById('searchFilter');
            var locEl = document.getElementById('locFilter');
            var marketEl = document.getElementById('marketFilter');
            var catEl = document.getElementById('catFilter');
            var openEl = document.getElementById('openTodayFilter');
            var sortEl = document.getElementById('farmerSort');
            var countEl = document.getElementById('resultsCount');
            var clearBtn = document.getElementById('clearFiltersBtn');

            var applyFarmers = function () {
                var q = (searchEl ? searchEl.value : '').toLowerCase().trim();
                var loc = locEl ? locEl.value : 'all';
                var mkt = marketEl ? marketEl.value : 'all';
                var cat = catEl ? catEl.value : 'all';
                var visible = 0;
                items.forEach(function (it) {
                    var d = it.dataset;
                    var ok = true;
                    if (q && ((d.name || '') + ' ' + (it.textContent || '')).toLowerCase().indexOf(q) === -1) ok = false;
                    if (loc !== 'all' && (d.loc || '') !== loc) ok = false;
                    if (mkt !== 'all' && (d.market || '').indexOf(mkt.split(' ')[0]) === -1 && (d.market || '') !== mkt) ok = false;
                    if (cat !== 'all' && (d.cat || '') !== cat) ok = false;
                    it.style.display = ok ? '' : 'none';
                    if (ok) visible++;
                });
                setCount(countEl, visible, 'farmer', 'farmers');
            };
            var sortFarmers = function () {
                if (!sortEl) return;
                var mode = sortEl.selectedOptions ? sortEl.selectedOptions[0].textContent.trim() : '';
                var sorted = items.slice().sort(function (a, b) {
                    if (mode === 'A-Z') return (a.dataset.name || '').localeCompare(b.dataset.name || '');
                    var ra = parseFloat((a.querySelector('.rating') || {}).textContent) || 0;
                    var rb = parseFloat((b.querySelector('.rating') || {}).textContent) || 0;
                    return rb - ra;
                });
                sorted.forEach(function (it) { farmersGrid.appendChild(it); });
            };
            [searchEl, locEl, marketEl, catEl, openEl].forEach(function (el) {
                if (el) el.addEventListener('input', applyFarmers);
            });
            if (sortEl) sortEl.addEventListener('change', sortFarmers);
            if (clearBtn) clearBtn.addEventListener('click', function (e) {
                e.preventDefault();
                if (searchEl) searchEl.value = '';
                [locEl, marketEl, catEl].forEach(function (s) { if (s) s.value = 'all'; });
                if (openEl) openEl.checked = false;
                applyFarmers();
            });
            applyFarmers();
        }

        /* ================= MARKETS (filter static cards) ================= */
        var marketsGrid = document.getElementById('marketsGrid');
        if (marketsGrid) {
            var mItems = Array.prototype.slice.call(marketsGrid.querySelectorAll('.market-item'));
            var heroSearch = document.getElementById('heroSearch');
            var searchInput = document.getElementById('searchInput');
            var locFilter = document.getElementById('locationFilter');
            var dayFilters = Array.prototype.slice.call(document.querySelectorAll('.day-filter'));
            var applyBtn = document.getElementById('applyFiltersBtn');
            var mClearBtn = document.getElementById('clearFiltersBtn');
            var mCountEl = document.getElementById('resultsCount');
            var mSortEl = document.getElementById('marketSort');

            var applyMarkets = function () {
                var q = ((searchInput && searchInput.value) || (heroSearch && heroSearch.value) || '').toLowerCase().trim();
                var loc = locFilter ? locFilter.value : 'all';
                var days = dayFilters.filter(function (d) { return d.checked; }).map(function (d) { return d.value; });
                var visible = 0;
                mItems.forEach(function (it) {
                    var d = it.dataset;
                    var ok = true;
                    if (q && ((d.name || '') + ' ' + (it.textContent || '')).toLowerCase().indexOf(q) === -1) ok = false;
                    if (loc !== 'all' && (d.location || '') !== loc) ok = false;
                    if (days.length) {
                        var itemDays = (d.days || '').split(',');
                        var hit = days.some(function (day) { return itemDays.indexOf(day) !== -1; });
                        if (!hit) ok = false;
                    }
                    it.style.display = ok ? '' : 'none';
                    if (ok) visible++;
                });
                setCount(mCountEl, visible, 'market', 'markets');
            };
            var sortMarkets = function () {
                if (!mSortEl) return;
                var mode = mSortEl.value;
                mItems.slice().sort(function (a, b) {
                    if (mode === 'az') return (a.dataset.name || '').localeCompare(b.dataset.name || '');
                    if (mode === 'farmers') {
                        var na = parseInt((a.textContent.match(/(\d+)\s*Farmers/) || [0, 0])[1], 10);
                        var nb = parseInt((b.textContent.match(/(\d+)\s*Farmers/) || [0, 0])[1], 10);
                        return nb - na;
                    }
                    return 0;
                }).forEach(function (it) { marketsGrid.appendChild(it); });
            };
            if (searchInput) searchInput.addEventListener('input', applyMarkets);
            if (heroSearch) heroSearch.addEventListener('input', function () {
                if (searchInput) searchInput.value = heroSearch.value;
                applyMarkets();
            });
            if (locFilter) locFilter.addEventListener('change', applyMarkets);
            dayFilters.forEach(function (d) { d.addEventListener('change', applyMarkets); });
            if (applyBtn) applyBtn.addEventListener('click', applyMarkets);
            if (mSortEl) mSortEl.addEventListener('change', sortMarkets);
            if (mClearBtn) mClearBtn.addEventListener('click', function (e) {
                e.preventDefault();
                if (searchInput) searchInput.value = '';
                if (heroSearch) heroSearch.value = '';
                if (locFilter) locFilter.value = 'all';
                dayFilters.forEach(function (d) { d.checked = false; });
                applyMarkets();
            });
            applyMarkets();
        }

        /* ================= PRODUCTS (render from data) ================= */
        var productGrid = document.getElementById('product-grid');
        if (productGrid && ML.products && ML.products.length) {
            var productList = document.getElementById('product-list');
            var searchInputP = document.getElementById('search-input');
            var catFilters = Array.prototype.slice.call(document.querySelectorAll('.category-filter'));
            var minPrice = document.getElementById('min-price');
            var maxPrice = document.getElementById('max-price');
            var sortSelect = document.getElementById('sort-select');
            var countP = document.getElementById('product-count');
            var clearP = document.getElementById('clear-filters');
            var btnGrid = document.getElementById('btn-grid');
            var btnList = document.getElementById('btn-list');
            var quickContent = document.getElementById('quick-view-content');
            var view = 'grid';

            var farmerName = function (fid) {
                var f = (ML.farmers || []).find(function (x) { return String(x.id) === String(fid); });
                return f ? f.stallName : 'Local Farm';
            };

            var filtered = function () {
                var q = (searchInputP ? searchInputP.value : '').toLowerCase().trim();
                var cats = catFilters.filter(function (c) { return c.checked; }).map(function (c) { return c.value; });
                var lo = minPrice && minPrice.value !== '' ? parseFloat(minPrice.value) : null;
                var hi = maxPrice && maxPrice.value !== '' ? parseFloat(maxPrice.value) : null;
                var rated = document.querySelector('input[name="rating-filter"]:checked');
                var minRating = rated ? parseFloat(rated.value) : 0;
                var list = ML.products.filter(function (p) {
                    if (q && (p.name + ' ' + p.category + ' ' + farmerName(p.farmerId)).toLowerCase().indexOf(q) === -1) return false;
                    if (cats.length && cats.indexOf(p.category) === -1) return false;
                    if (lo !== null && p.price < lo) return false;
                    if (hi !== null && p.price > hi) return false;
                    if ((p.rating || 0) < minRating) return false;
                    return true;
                });
                var mode = sortSelect ? sortSelect.value : 'newest';
                list.sort(function (a, b) {
                    if (mode === 'price-asc') return a.price - b.price;
                    if (mode === 'price-desc') return b.price - a.price;
                    if (mode === 'rating') return (b.rating || 0) - (a.rating || 0);
                    if (mode === 'name') return a.name.localeCompare(b.name);
                    return 0;
                });
                return list;
            };

            var cardGrid = function (p) {
                return '<div class="col-6 col-lg-4">' +
                    '<div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">' +
                    '<div class="position-relative">' +
                    '<a href="' + window.mlUrl('product-details') + '?id=' + esc(p.id) + '"><img src="' + esc(p.image) + '" class="card-img-top object-fit-cover" alt="' + esc(p.name) + '" height="200" loading="lazy"></a>' +
                    '<button class="btn btn-light btn-sm rounded-circle position-absolute top-0 end-0 m-2 shadow-sm text-danger ml-fav-btn" data-product-id="' + esc(p.id) + '" aria-label="Favorite"><i class="far fa-heart"></i></button>' +
                    '<span class="badge bg-success position-absolute top-0 start-0 m-2">' + esc(p.category) + '</span>' +
                    '</div><div class="card-body p-3">' +
                    '<span class="text-muted small">' + esc(farmerName(p.farmerId)) + '</span>' +
                    '<h6 class="card-title fw-bold mt-1 mb-1"><a href="' + window.mlUrl('product-details') + '?id=' + esc(p.id) + '" class="text-dark text-decoration-none">' + esc(p.name) + '</a></h6>' +
                    '<div class="text-warning small mb-2">' + stars(p.rating) + ' <span class="text-muted">(' + (p.rating || 0).toFixed(1) + ')</span></div>' +
                    '<div class="d-flex justify-content-between align-items-center mt-2">' +
                    '<span class="fw-bold fs-5 ml-text-green">Rs ' + Number(p.price).toLocaleString('en-PK') + ' <small class="text-muted fs-6 fw-normal">/ ' + esc(p.unit) + '</small></span>' +
                    '<button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm add-to-cart-btn" aria-label="Add to Cart" style="width:36px;height:36px;" data-id="' + esc(p.id) + '" data-name="' + esc(p.name) + '" data-price="' + p.price + '" data-image="' + esc(p.image) + '"><i class="fas fa-plus"></i></button>' +
                    '</div>' +
                    '<button class="btn btn-link btn-sm text-muted text-decoration-none p-0 mt-1 quick-view-btn" data-id="' + esc(p.id) + '">Quick view</button>' +
                    '</div></div></div>';
            };

            var cardList = function (p) {
                return '<div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3"><div class="row g-0">' +
                    '<div class="col-sm-3"><a href="' + window.mlUrl('product-details') + '?id=' + esc(p.id) + '"><img src="' + esc(p.image) + '" class="img-fluid h-100 object-fit-cover w-100" alt="' + esc(p.name) + '" style="min-height:160px;" loading="lazy"></a></div>' +
                    '<div class="col-sm-9"><div class="card-body">' +
                    '<div class="d-flex justify-content-between align-items-start">' +
                    '<div><span class="badge bg-success mb-2">' + esc(p.category) + '</span>' +
                    '<h5 class="card-title fw-bold mb-1"><a href="' + window.mlUrl('product-details') + '?id=' + esc(p.id) + '" class="text-dark text-decoration-none">' + esc(p.name) + '</a></h5>' +
                    '<p class="text-muted small mb-1">' + esc(farmerName(p.farmerId)) + '</p>' +
                    '<div class="text-warning small">' + stars(p.rating) + ' <span class="text-muted">(' + (p.rating || 0).toFixed(1) + ')</span></div></div>' +
                    '<button class="btn btn-light btn-sm rounded-circle text-danger ml-fav-btn" data-product-id="' + esc(p.id) + '" aria-label="Favorite"><i class="far fa-heart"></i></button></div>' +
                    '<div class="d-flex justify-content-between align-items-center mt-3">' +
                    '<span class="fw-bold fs-5 ml-text-green">Rs ' + Number(p.price).toLocaleString('en-PK') + ' <small class="text-muted fs-6 fw-normal">/ ' + esc(p.unit) + '</small></span>' +
                    '<div class="d-flex gap-2"><button class="btn btn-sm btn-outline-secondary quick-view-btn" data-id="' + esc(p.id) + '">Quick view</button>' +
                    '<button class="btn btn-sm ml-btn-primary add-to-cart-btn" data-id="' + esc(p.id) + '" data-name="' + esc(p.name) + '" data-price="' + p.price + '" data-image="' + esc(p.image) + '"><i class="fas fa-plus me-1"></i>Add</button></div>' +
                    '</div></div></div></div></div>';
            };

            var render = function () {
                var list = filtered();
                document.querySelectorAll('[data-cat-count]').forEach(function (el) {
                    var c = el.getAttribute('data-cat-count');
                    var n = ML.products.filter(function (p) { return p.category === c; }).length;
                    el.textContent = '(' + n + ')';
                });
                if (countP) countP.textContent = list.length;
                if (!list.length) {
                    var empty = '<div class="col-12"><div class="text-center py-5 bg-white rounded-4 shadow-sm">' +
                        '<i class="fas fa-basket-shopping fa-3x text-muted mb-3"></i>' +
                        '<h5 class="fw-bold">No products found</h5>' +
                        '<p class="text-muted mb-0">Try adjusting your filters or search.</p></div></div>';
                    productGrid.innerHTML = empty;
                    if (productList) productList.innerHTML = '';
                    return;
                }
                productGrid.innerHTML = list.map(cardGrid).join('');
                if (productList) productList.innerHTML = list.map(cardList).join('');
            };

            var setView = function (v) {
                view = v;
                var isGrid = v === 'grid';
                productGrid.classList.toggle('d-none', !isGrid);
                if (productList) productList.classList.toggle('d-none', isGrid);
                if (btnGrid) btnGrid.classList.toggle('active', isGrid);
                if (btnList) btnList.classList.toggle('active', !isGrid);
            };

            document.addEventListener('click', function (e) {
                var qv = e.target.closest('.quick-view-btn');
                if (qv && quickContent) {
                    var p = ML.products.find(function (x) { return String(x.id) === String(qv.dataset.id); });
                    if (p) {
                        quickContent.innerHTML = '<div class="row g-4">' +
                            '<div class="col-md-5"><img src="' + esc(p.image) + '" class="img-fluid rounded-4" alt="' + esc(p.name) + '"></div>' +
                            '<div class="col-md-7"><span class="badge bg-success mb-2">' + esc(p.category) + '</span>' +
                            '<h3 class="fw-bold">' + esc(p.name) + '</h3>' +
                            '<p class="text-muted">' + esc(farmerName(p.farmerId)) + '</p>' +
                            '<div class="text-warning mb-3">' + stars(p.rating) + ' <span class="text-muted">(' + (p.rating || 0).toFixed(1) + ')</span></div>' +
                            '<h4 class="fw-bold ml-text-green mb-4">Rs ' + Number(p.price).toLocaleString('en-PK') + ' <small class="text-muted fs-6 fw-normal">/ ' + esc(p.unit) + '</small></h4>' +
                            '<div class="d-flex gap-2"><button class="btn ml-btn-primary add-to-cart-btn" data-id="' + esc(p.id) + '" data-name="' + esc(p.name) + '" data-price="' + p.price + '" data-image="' + esc(p.image) + '"><i class="fas fa-shopping-cart me-2"></i>Add to Cart</button>' +
                            '<a href="' + window.mlUrl('product-details') + '?id=' + esc(p.id) + '" class="btn ml-btn-outline-green">Full Details</a></div></div></div>';
                        var modal = document.getElementById('quickViewModal');
                        if (modal && window.bootstrap) {
                            try { window.bootstrap.Modal.getOrCreateInstance(modal).show(); } catch (err) { /* noop */ }
                        }
                    }
                }
            });

            [searchInputP, minPrice, maxPrice].forEach(function (el) { if (el) el.addEventListener('input', render); });
            catFilters.forEach(function (c) { c.addEventListener('change', render); });
            document.querySelectorAll('input[name="rating-filter"]').forEach(function (r) { r.addEventListener('change', render); });
            if (sortSelect) sortSelect.addEventListener('change', render);
            if (btnGrid) btnGrid.addEventListener('click', function () { setView('grid'); });
            if (btnList) btnList.addEventListener('click', function () { setView('list'); });
            if (clearP) clearP.addEventListener('click', function (e) {
                e.preventDefault();
                if (searchInputP) searchInputP.value = '';
                catFilters.forEach(function (c) { c.checked = false; });
                if (minPrice) minPrice.value = '';
                if (maxPrice) maxPrice.value = '';
                document.querySelectorAll('input[name="rating-filter"]').forEach(function (r) { r.checked = false; });
                if (sortSelect) sortSelect.value = 'newest';
                render();
            });
            render();
        }
    });
})();

document.getElementById('item-form').addEventListener('submit', function(e){
    e.preventDefault();
    const nameInput = document.getElementById('item-name');
    const categorySelect = document.getElementById('item-category');
    const name = nameInput.value.trim();
    const category = categorySelect.value;
    if(!name){return;}
    const ul = document.querySelector(`#${category}-list ul`);
    const li = document.createElement('li');
    li.textContent = name;
    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.addEventListener('click',()=> li.remove());
    li.appendChild(delBtn);
    ul.appendChild(li);
    nameInput.value = '';
    categorySelect.selectedIndex = 0;
});

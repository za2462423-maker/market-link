/* ============================================================
   MarketLink — Cart (localStorage)
   Works with: navbar badge (#cartBadge) + cart page
   (#cart-table, #summary-*, #cart-item-count, #empty-cart-state)
   ============================================================ */
(function () {
    'use strict';

    var STORAGE_KEY = 'ml_cart';

    function loadCart() {
        try {
            return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
        } catch (e) {
            return [];
        }
    }

    var cart = loadCart();

    function saveCart() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cart)); } catch (e) { /* noop */ }
        updateCartBadge();
    }

    function money(n) {
        return 'Rs ' + (parseFloat(n) || 0).toLocaleString('en-PK', { maximumFractionDigits: 0 });
    }

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    /* ---------- Public API ---------- */
    window.addToCart = function (product) {
        if (!product || typeof product !== 'object') return;
        var id = String(product.id || '');
        if (!id) return;
        var qty = parseInt(product.quantity, 10) || 1;
        var existing = cart.find(function (item) { return String(item.id) === id; });
        if (existing) {
            existing.quantity += qty;
        } else {
            cart.push({
                id: id,
                name: product.name || 'Fresh Product',
                price: parseFloat(product.price) || 0,
                image: product.image || 'https://picsum.photos/100/100?food',
                quantity: qty
            });
        }
        saveCart();
        renderCart();
        if (window.showToast) window.showToast('Added to cart!');
    };

    window.removeFromCart = function (id) {
        cart = cart.filter(function (item) { return String(item.id) !== String(id); });
        saveCart();
        renderCart();
    };

    window.updateQuantity = function (id, delta) {
        var item = cart.find(function (i) { return String(i.id) === String(id); });
        if (!item) return;
        item.quantity += parseInt(delta, 10) || 0;
        if (item.quantity <= 0) {
            window.removeFromCart(id);
        } else {
            saveCart();
            renderCart();
        }
    };

    window.removeSelected = function () {
        var checked = document.querySelectorAll('#cart-table tbody .cart-select:checked');
        if (!checked.length) {
            if (window.showToast) window.showToast('No items selected', 'info');
            return;
        }
        var ids = Array.prototype.map.call(checked, function (c) { return c.value; });
        cart = cart.filter(function (item) { return ids.indexOf(String(item.id)) === -1; });
        saveCart();
        renderCart();
        if (window.showToast) window.showToast('Selected items removed');
    };

    window.clearCart = function () {
        if (!cart.length) return;
        cart = [];
        saveCart();
        renderCart();
        if (window.showToast) window.showToast('Cart cleared', 'info');
    };

    window.getCart = function () { return cart; };
    window.getCartTotal = function () {
        return cart.reduce(function (t, i) { return t + (parseFloat(i.price) || 0) * (i.quantity || 0); }, 0);
    };
    window.getCartCount = function () {
        return cart.reduce(function (c, i) { return c + (i.quantity || 0); }, 0);
    };

    function updateCartBadge() {
        var count = window.getCartCount();
        document.querySelectorAll('#cartBadge, .ml-cart-badge, .cart-badge').forEach(function (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline-flex' : 'none';
        });
        var countLabel = document.getElementById('cart-item-count');
        if (countLabel) {
            countLabel.textContent = count + (count === 1 ? ' item' : ' items');
            countLabel.style.display = count > 0 ? '' : 'none';
        }
    }
    window.updateCartBadge = updateCartBadge;

    /* ---------- Render cart page ---------- */
    function renderCart() {
        updateCartBadge();

        var tbody = document.querySelector('#cart-table tbody');
        var summaryItems = document.getElementById('summary-items');
        var subtotalEl = document.getElementById('summary-subtotal');
        var totalEl = document.getElementById('summary-total');
        var emptyState = document.getElementById('empty-cart-state');
        var summaryCol = document.getElementById('order-summary-col');
        var cartTable = document.getElementById('cart-table');

        /* Legacy fallback container (other pages) */
        var legacyBox = document.getElementById('cartItemsContainer');
        var legacyTotal = document.getElementById('cartTotalAmount');

        if (!tbody && !legacyBox) return; /* not on cart page */

        var total = window.getCartTotal();

        if (tbody) {
            tbody.innerHTML = cart.map(function (item) {
                var sub = (parseFloat(item.price) || 0) * (item.quantity || 0);
                return '' +
                    '<tr>' +
                    '<td class="ps-4"><div class="form-check"><input class="form-check-input cart-select" type="checkbox" value="' + esc(item.id) + '" checked></div></td>' +
                    '<td><div class="d-flex align-items-center gap-3">' +
                    '<img src="' + esc(item.image) + '" alt="' + esc(item.name) + '" width="56" height="56" class="rounded object-fit-cover">' +
                    '<span class="fw-medium">' + esc(item.name) + '</span></div></td>' +
                    '<td>' + money(item.price) + '</td>' +
                    '<td><div class="input-group input-group-sm" style="max-width:130px;">' +
                    '<button class="btn btn-outline-secondary" type="button" onclick="updateQuantity(\'' + esc(item.id) + '\', -1)">−</button>' +
                    '<input type="text" class="form-control text-center" value="' + (item.quantity || 0) + '" readonly>' +
                    '<button class="btn btn-outline-secondary" type="button" onclick="updateQuantity(\'' + esc(item.id) + '\', 1)">+</button>' +
                    '</div></td>' +
                    '<td class="fw-bold">' + money(sub) + '</td>' +
                    '<td class="pe-4 text-end"><button class="btn btn-sm btn-outline-danger" onclick="removeFromCart(\'' + esc(item.id) + '\')" aria-label="Remove"><i class="fas fa-trash"></i></button></td>' +
                    '</tr>';
            }).join('');

            var hasItems = cart.length > 0;
            if (emptyState) emptyState.classList.toggle('d-none', hasItems);
            if (cartTable) cartTable.style.display = hasItems ? '' : 'none';
            if (summaryCol) summaryCol.style.display = hasItems ? '' : 'none';

            var selectAll = document.getElementById('select-all');
            if (selectAll && !selectAll.dataset.wired) {
                selectAll.dataset.wired = '1';
                selectAll.addEventListener('change', function () {
                    document.querySelectorAll('#cart-table tbody .cart-select').forEach(function (c) {
                        c.checked = selectAll.checked;
                    });
                });
            }
        }

        if (summaryItems) {
            summaryItems.innerHTML = cart.map(function (item) {
                return '<div class="d-flex justify-content-between small mb-2"><span class="text-muted">' +
                    esc(item.name) + ' × ' + (item.quantity || 0) + '</span><span class="fw-medium">' +
                    money((parseFloat(item.price) || 0) * (item.quantity || 0)) + '</span></div>';
            }).join('') || '<p class="text-muted small mb-0">No items yet.</p>';
        }
        if (subtotalEl) subtotalEl.textContent = money(total);
        if (totalEl) totalEl.textContent = money(total);

        if (legacyBox) {
            legacyBox.innerHTML = cart.length
                ? cart.map(function (item) {
                    return '<div class="d-flex align-items-center mb-3 p-3 border rounded bg-white">' +
                        '<img src="' + esc(item.image) + '" alt="' + esc(item.name) + '" width="64" class="rounded me-3">' +
                        '<div class="flex-grow-1"><h6 class="mb-1">' + esc(item.name) + '</h6>' +
                        '<p class="mb-0 text-muted small">' + money(item.price) + ' × ' + (item.quantity || 0) + '</p></div>' +
                        '<div class="fw-bold me-3">' + money((parseFloat(item.price) || 0) * (item.quantity || 0)) + '</div>' +
                        '<button class="btn btn-sm btn-outline-danger" onclick="removeFromCart(\'' + esc(item.id) + '\')"><i class="fas fa-trash"></i></button></div>';
                }).join('')
                : '<p class="text-center text-muted py-4">Your cart is empty.</p>';
            if (legacyTotal) legacyTotal.textContent = money(total);
        }
    }
    window.renderCart = renderCart;

    document.addEventListener('DOMContentLoaded', function () {
        renderCart();
    });
})();

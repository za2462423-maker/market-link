// Mock Data for MarketLink

const markets = [
    { id: 1, name: "Downtown Farmers Market", address: "100 Main St", city: "Metropolis", days: "Saturday", openTime: "08:00", closeTime: "14:00", farmerCount: 45, image: "https://picsum.photos/400/300?market", description: "Vibrant downtown market." },
    { id: 2, name: "Riverside Organic", address: "River Walk", city: "Metropolis", days: "Sunday", openTime: "09:00", closeTime: "15:00", farmerCount: 30, image: "https://picsum.photos/400/300?vegetables", description: "Certified organic goods." },
    { id: 3, name: "Westside Community Market", address: "West Park", city: "Star City", days: "Wednesday", openTime: "15:00", closeTime: "19:00", farmerCount: 20, image: "https://picsum.photos/400/300?fruits", description: "Evening market for mid-week shopping." },
    { id: 4, name: "North Square", address: "North Sq", city: "Star City", days: "Saturday", openTime: "07:00", closeTime: "12:00", farmerCount: 50, image: "https://picsum.photos/400/300?farm", description: "Early bird market." },
    { id: 5, name: "Sunnyvale Market", address: "Sun Ave", city: "Sunnyvale", days: "Sunday", openTime: "08:00", closeTime: "13:00", farmerCount: 25, image: "https://picsum.photos/400/300?food", description: "Family friendly market." },
    { id: 6, name: "East End Local", address: "East St", city: "Metropolis", days: "Friday", openTime: "16:00", closeTime: "20:00", farmerCount: 15, image: "https://picsum.photos/400/300?stall", description: "Start your weekend fresh." }
];

const farmers = [
    { id: 1, name: "John Doe", stallName: "Green Valley Farms", image: "https://picsum.photos/100/100?face", coverImage: "https://picsum.photos/800/300?farm", markets: [1, 2], rating: 4.8, reviewCount: 120, productCount: 15, specialties: "Organic Vegetables" },
    { id: 2, name: "Jane Smith", stallName: "Sunrise Dairy", image: "https://picsum.photos/100/100?woman", coverImage: "https://picsum.photos/800/300?cow", markets: [1, 3], rating: 4.9, reviewCount: 85, productCount: 8, specialties: "Artisan Cheese & Milk" },
    { id: 3, name: "Bob Wilson", stallName: "Wilson's Orchard", image: "https://picsum.photos/100/100?man", coverImage: "https://picsum.photos/800/300?apple", markets: [2, 4], rating: 4.7, reviewCount: 200, productCount: 12, specialties: "Seasonal Fruits" },
    { id: 4, name: "Alice Brown", stallName: "The Daily Bread", image: "https://picsum.photos/100/100?baker", coverImage: "https://picsum.photos/800/300?bread", markets: [1, 5], rating: 5.0, reviewCount: 340, productCount: 20, specialties: "Sourdough & Pastries" },
    { id: 5, name: "Tom Hardy", stallName: "Hardy Meats", image: "https://picsum.photos/100/100?butcher", coverImage: "https://picsum.photos/800/300?meat", markets: [1, 6], rating: 4.6, reviewCount: 90, productCount: 10, specialties: "Grass-fed Beef" },
    { id: 6, name: "Sarah Connor", stallName: "Sarah's Honey", image: "https://picsum.photos/100/100?girl", coverImage: "https://picsum.photos/800/300?bee", markets: [3, 4], rating: 4.9, reviewCount: 150, productCount: 5, specialties: "Raw Honey" },
    { id: 7, name: "Mike Tyson", stallName: "Mike's Greens", image: "https://picsum.photos/100/100?guy", coverImage: "https://picsum.photos/800/300?leaf", markets: [2, 5], rating: 4.5, reviewCount: 60, productCount: 18, specialties: "Microgreens" },
    { id: 8, name: "Emma Watson", stallName: "Floral Magic", image: "https://picsum.photos/100/100?lady", coverImage: "https://picsum.photos/800/300?flower", markets: [1, 2], rating: 4.8, reviewCount: 210, productCount: 25, specialties: "Fresh Cut Flowers" }
];

const products = [
    { id: "p1", name: "Organic Tomatoes", farmerId: 1, price: 4.99, unit: "lb", category: "Vegetables", rating: 4.5, image: "https://picsum.photos/300/300?tomato" },
    { id: "p2", name: "Fresh Milk", farmerId: 2, price: 3.50, unit: "gallon", category: "Dairy", rating: 4.8, image: "https://picsum.photos/300/300?milk" },
    { id: "p3", name: "Honeycrisp Apples", farmerId: 3, price: 2.99, unit: "lb", category: "Fruits", rating: 4.7, image: "https://picsum.photos/300/300?apple" },
    { id: "p4", name: "Sourdough Loaf", farmerId: 4, price: 6.00, unit: "loaf", category: "Baked Goods", rating: 5.0, image: "https://picsum.photos/300/300?bread" },
    { id: "p5", name: "Ribeye Steak", farmerId: 5, price: 15.99, unit: "lb", category: "Meat", rating: 4.6, image: "https://picsum.photos/300/300?steak" },
    { id: "p6", name: "Wildflower Honey", farmerId: 6, price: 8.50, unit: "jar", category: "Other", rating: 4.9, image: "https://picsum.photos/300/300?honey" },
    { id: "p7", name: "Sunflower Bouquet", farmerId: 8, price: 12.00, unit: "bunch", category: "Other", rating: 4.8, image: "https://picsum.photos/300/300?sunflower" },
    { id: "p8", name: "Arugula", farmerId: 7, price: 3.00, unit: "bunch", category: "Vegetables", rating: 4.5, image: "https://picsum.photos/300/300?arugula" },
    { id: "p9", name: "Carrots", farmerId: 1, price: 2.00, unit: "bunch", category: "Vegetables", rating: 4.4, image: "https://picsum.photos/300/300?carrot" },
    { id: "p10", name: "Cheddar Cheese", farmerId: 2, price: 5.50, unit: "block", category: "Dairy", rating: 4.9, image: "https://picsum.photos/300/300?cheese" }
];

const categories = ['Vegetables', 'Fruits', 'Dairy', 'Baked Goods', 'Meat', 'Other'];

window.ML = { markets, farmers, products, categories };

/* ============================================================
   MarketLink — Global JS
   - Toast notifications        - Favorites (delegated)
   - Add-to-cart (delegated)    - Counters, search, sidebar
   - Newsletter / contact demo  - Product-details widgets
   ============================================================ */
(function () {
    'use strict';

    /* ---------- Link helper (works in Laravel + static preview) ---------- */
    window.mlUrl = function (slug) {
        var suffix = (document.body && document.body.dataset.linkSuffix) || '';
        return '/' + slug + suffix;
    };

    /* ---------- Toast notification system ---------- */
    window.showToast = function (message, type) {
        type = type || 'success';
        var container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        var toast = document.createElement('div');
        toast.className = 'toast';
        var icon = type === 'success' ? 'check-circle text-success' : 'info-circle text-primary';
        toast.innerHTML = '<i class="fas fa-' + icon + ' me-2"></i><span></span>';
        toast.querySelector('span').textContent = message;
        container.appendChild(toast);
        setTimeout(function () {
            toast.style.transition = 'opacity .3s ease';
            toast.style.opacity = '0';
            setTimeout(function () { toast.remove(); }, 320);
        }, 2800);
    };

    /* ---------- Favorite toggle (shared) ---------- */
    function paintFav(btn, on) {
        var icon = btn.querySelector('i');
        if (!icon) return;
        if (on) {
            icon.classList.replace('far', 'fas');
            btn.classList.add('favorited');
        } else {
            icon.classList.replace('fas', 'far');
            btn.classList.remove('favorited');
        }
    }
    function toggleFavButton(btn) {
        var icon = btn.querySelector('i');
        if (!icon) return;
        var adding = icon.classList.contains('far');
        paintFav(btn, adding);
        var pid = btn.getAttribute('data-product-id');
        var csrf = document.querySelector('meta[name="csrf-token"]');
        var authed = document.body && document.body.getAttribute('data-auth') === '1';
        if (pid && authed && csrf && csrf.content && csrf.content !== 'PREVIEW') {
            fetch('/favorites/toggle', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': csrf.content },
                body: JSON.stringify({ product_id: pid })
            }).then(function (r) {
                if (!r.ok) throw new Error('fav failed');
                return r.json();
            }).then(function (d) {
                paintFav(btn, !!d.favorited);
                window.showToast(d.message || (d.favorited ? 'Added to favorites!' : 'Removed from favorites'), d.favorited ? 'success' : 'info');
            }).catch(function () {
                window.showToast(adding ? 'Added to favorites!' : 'Removed from favorites', adding ? 'success' : 'info');
            });
            return;
        }
        if (pid && !authed) {
            window.showToast('Log in as a customer to save favorites', 'info');
            return;
        }
        window.showToast(adding ? 'Added to favorites!' : 'Removed from favorites', adding ? 'success' : 'info');
    }
    window.toggleFav = function () {
        var btn = document.getElementById('fav-btn');
        if (btn) toggleFavButton(btn);
    };

    /* ---------- Add to cart from any card ---------- */
    function addCardToCart(btn) {
        var data = btn.dataset || {};
        var product = {
            id: data.id || '',
            name: data.name || '',
            price: parseFloat(data.price) || 0,
            image: data.image || ''
        };
        if (!product.id || !product.name) {
            var card = btn.closest('.card');
            if (card) {
                var titleEl = card.querySelector('.card-title');
                var priceEl = card.querySelector('.ml-text-green, .text-success, .fw-bold.fs-5');
                var imgEl = card.querySelector('img');
                if (titleEl) product.name = titleEl.textContent.trim();
                if (priceEl) {
                    var m = priceEl.textContent.replace(/,/g, '').match(/[\d.]+/);
                    if (m) product.price = parseFloat(m[0]);
                }
                if (imgEl) product.image = imgEl.src;
                if (product.name && !product.id) {
                    product.id = product.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
                }
            }
        }
        if (!product.id) product.id = 'item-' + Date.now();
        if (!product.name) product.name = 'Fresh Product';
        if (window.addToCart) {
            window.addToCart({ id: product.id, name: product.name, price: product.price, image: product.image, quantity: 1 });
        } else {
            window.showToast('Item added to cart!');
        }
        /* Bootstrap toast on product pages (if present) */
        var bsToast = document.getElementById('cartToast');
        if (bsToast && window.bootstrap) {
            try { window.bootstrap.Toast.getOrCreateInstance(bsToast).show(); } catch (e) { /* noop */ }
        }
    }

    /* ---------- Delegated clicks (works for JS-rendered grids too) ---------- */
    document.addEventListener('click', function (e) {
        var fav = e.target.closest('.btn-favorite, .ml-fav-btn, .fav-btn');
        if (fav) { e.preventDefault(); toggleFavButton(fav); return; }

        var addBtn = e.target.closest('.add-to-cart-btn, button[aria-label="Add to Cart"]');
        if (addBtn) { e.preventDefault(); addCardToCart(addBtn); return; }

        /* Demo/dead links: give feedback instead of jumping to top.
           (Skips Bootstrap toggles which have their own handlers.) */
        var dead = e.target.closest('a[href="#"]');
        if (dead && !dead.hasAttribute('data-bs-toggle') && !dead.hasAttribute('data-bs-target') && !dead.hasAttribute('data-bs-dismiss')) {
            e.preventDefault();
            var label = (dead.textContent || '').trim().replace(/\s+/g, ' ');
            if (dead.closest('.pagination')) {
                window.showToast('Demo: all results fit on one page', 'info');
            } else if (dead.classList.contains('dropdown-item')) {
                window.showToast((label || 'Action') + ' — demo only', 'info');
            } else if (!label) {
                window.showToast('Coming soon!', 'info');
            } else {
                window.showToast(label + ' — coming soon!', 'info');
            }
            return;
        }

        /* Demo icon buttons in admin tables (Reject / Edit have no backend yet) */
        var demoBtn = e.target.closest('button[title="Reject"], button[title="Edit"]');
        if (demoBtn) {
            window.showToast(demoBtn.getAttribute('title') === 'Reject' ? 'Demo: request rejected' : 'Demo: edit opens in full version', 'info');
        }
    });

    /* ---------- Product details: gallery / qty ---------- */
    window.changeImage = function (thumb) {
        var main = document.getElementById('main-product-image');
        if (!main || !thumb) return;
        main.src = thumb.src;
        document.querySelectorAll('.thumbnail').forEach(function (t) { t.classList.remove('active'); });
        thumb.classList.add('active');
    };

    document.addEventListener('DOMContentLoaded', function () {
        /* 1. Navbar shadow on scroll */
        var navbar = document.querySelector('.ml-navbar, .navbar');
        var onScrollNav = function () {
            if (!navbar) return;
            navbar.classList.toggle('sticky-nav', window.scrollY > 40);
        };
        window.addEventListener('scroll', onScrollNav, { passive: true });
        onScrollNav();

        /* 2. Back to top */
        var backToTopBtn = document.getElementById('backToTop');
        if (backToTopBtn) {
            window.addEventListener('scroll', function () {
                backToTopBtn.classList.toggle('show', window.scrollY > 300);
            }, { passive: true });
            backToTopBtn.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* 3. Scroll animations */
        var animTargets = document.querySelectorAll('.animate-on-scroll, .scroll-animate');
        if ('IntersectionObserver' in window && animTargets.length) {
            var observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('anim-fade-up', 'visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            animTargets.forEach(function (el) { observer.observe(el); });
        } else {
            animTargets.forEach(function (el) { el.classList.add('anim-fade-up', 'visible'); });
        }

        /* 4. Number counters (stats bar) */
        var counters = document.querySelectorAll('.stat-number, .ml-counter');
        var runCounter = function (counter) {
            var target = parseInt(counter.getAttribute('data-target') || counter.textContent, 10);
            if (isNaN(target)) return;
            var duration = 1200, start = null;
            var step = function (ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / duration, 1);
                counter.textContent = Math.ceil(target * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(step);
                else counter.textContent = target;
            };
            requestAnimationFrame(step);
        };
        if ('IntersectionObserver' in window && counters.length) {
            var cObs = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) { runCounter(entry.target); cObs.unobserve(entry.target); }
                });
            }, { threshold: 0.4 });
            counters.forEach(function (c) { cObs.observe(c); });
        } else {
            counters.forEach(runCounter);
        }

        /* 5. Newsletter + contact demo submit */
        document.querySelectorAll('.ml-newsletter-form, .newsletter-form').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                window.showToast('Subscribed successfully!');
                form.reset();
            });
        });
        var contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function (e) {
                e.preventDefault();
                window.showToast('Message sent! We will get back to you soon.');
                contactForm.reset();
            });
        }

        /* 6. Generic live search */
        var searchInput = document.getElementById('mainSearch');
        if (searchInput) {
            searchInput.addEventListener('keyup', function (e) {
                var term = e.target.value.toLowerCase();
                document.querySelectorAll('[data-searchable]').forEach(function (el) {
                    el.style.display = el.textContent.toLowerCase().indexOf(term) !== -1 ? '' : 'none';
                });
            });
        }

        /* 7. Dashboard sidebar (mobile off-canvas) */
        var sidebar = document.getElementById('sidebar');
        var sidebarToggle = document.getElementById('sidebarToggle');
        var sidebarClose = document.getElementById('sidebarClose');
        var overlay = document.querySelector('.ml-sidebar-overlay');
        if (sidebar && !overlay) {
            overlay = document.createElement('div');
            overlay.className = 'ml-sidebar-overlay';
            document.body.appendChild(overlay);
        }
        var openSidebar = function () { if (sidebar) sidebar.classList.add('show'); if (overlay) overlay.classList.add('show'); };
        var closeSidebar = function () { if (sidebar) sidebar.classList.remove('show'); if (overlay) overlay.classList.remove('show'); };
        if (sidebarToggle) sidebarToggle.addEventListener('click', openSidebar);
        if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
        if (overlay) overlay.addEventListener('click', closeSidebar);

        /* 8. Product details quantity stepper */
        var qtyInput = document.getElementById('qty-input');
        var btnMinus = document.getElementById('btn-minus');
        var btnPlus = document.getElementById('btn-plus');
        if (qtyInput) {
            if (btnMinus) btnMinus.addEventListener('click', function () {
                qtyInput.value = Math.max(parseInt(qtyInput.min || '1', 10), (parseInt(qtyInput.value, 10) || 1) - 1);
            });
            if (btnPlus) btnPlus.addEventListener('click', function () {
                qtyInput.value = Math.min(parseInt(qtyInput.max || '50', 10), (parseInt(qtyInput.value, 10) || 1) + 1);
            });
        }

        /* 9. Product-details Add to Cart (with quantity) */
        var pdpAdd = document.getElementById('pdp-add-cart');
        if (pdpAdd) {
            pdpAdd.addEventListener('click', function () {
                var qty = qtyInput ? (parseInt(qtyInput.value, 10) || 1) : 1;
                var nameEl = document.querySelector('.col-md-5 h1, h1.fw-bold');
                var priceEl = document.querySelector('.display-5');
                var imgEl = document.getElementById('main-product-image');
                var price = 0;
                if (priceEl) {
                    var m = priceEl.textContent.replace(/,/g, '').match(/[\d.]+/);
                    if (m) price = parseFloat(m[0]);
                }
                if (window.addToCart) {
                    window.addToCart({
                        id: pdpAdd.getAttribute('data-id') || (nameEl ? nameEl.textContent.trim() : 'product').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
                        name: nameEl ? nameEl.textContent.trim() : 'Fresh Product',
                        price: price,
                        image: imgEl ? imgEl.src : '',
                        quantity: qty
                    });
                }
            });
        }

        /* 10. Password visibility toggles */
        document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(btn.getAttribute('data-toggle-password'));
                var icon = btn.querySelector('i');
                if (!input) return;
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                if (icon) {
                    icon.classList.toggle('fa-eye', !show);
                    icon.classList.toggle('fa-eye-slash', show);
                }
            });
        });

        /* 11. Review stars input (product details) */
        var reviewStars = document.getElementById('review-stars');
        if (reviewStars) {
            var stars = reviewStars.querySelectorAll('i');
            stars.forEach(function (star, idx) {
                star.style.cursor = 'pointer';
                star.addEventListener('click', function () {
                    stars.forEach(function (s, i) {
                        s.classList.toggle('fas', i <= idx);
                        s.classList.toggle('far', i > idx);
                    });
                });
            });
        }
        /* 12. No-Bootstrap fallback: navbar toggler + dropdowns (vanilla).
           Runs only if bootstrap.js failed to load, so the navbar,
           user menu and alerts keep working no matter what. */
        if (!window.bootstrap) {
            /* Mobile navbar collapse */
            document.querySelectorAll('[data-bs-toggle="collapse"]').forEach(function (toggler) {
                var target = document.querySelector(toggler.getAttribute('data-bs-target'));
                if (!target) return;
                toggler.addEventListener('click', function () {
                    target.classList.toggle('show');
                    toggler.setAttribute('aria-expanded', target.classList.contains('show') ? 'true' : 'false');
                });
            });
            /* Dropdown menus (e.g. navbar user chip) */
            document.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(function (toggler) {
                var menu = toggler.parentElement ? toggler.parentElement.querySelector('.dropdown-menu') : null;
                if (!menu) return;
                toggler.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var open = menu.classList.contains('show');
                    document.querySelectorAll('.dropdown-menu.show').forEach(function (m) { m.classList.remove('show'); });
                    if (!open) menu.classList.add('show');
                });
            });
            document.addEventListener('click', function () {
                document.querySelectorAll('.dropdown-menu.show').forEach(function (m) { m.classList.remove('show'); });
            });
            /* Dismissible alerts + modals (flash close buttons) */
            document.querySelectorAll('[data-bs-dismiss="alert"], [data-bs-dismiss="modal"]').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var t = btn.closest('.alert, .modal');
                    if (t) { t.classList.remove('show'); t.style.display = 'none'; }
                });
            });
        }
    });
})();

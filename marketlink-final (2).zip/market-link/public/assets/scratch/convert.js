const fs = require('fs');
const path = require('path');

const baseDir = 'c:/Users/Saad Raees/Downloads/OneDrive/Desktop/market link 2';

const htmlFiles = [
  'about.html',
  'admin-customers.html',
  'admin-dashboard.html',
  'admin-farmers.html',
  'admin-login.html',
  'admin-markets.html',
  'admin-orders.html',
  'admin-products.html',
  'admin-reports.html',
  'admin-reviews.html',
  'ai-assistant.html',
  'cart.html',
  'contact.html',
  'customer-dashboard.html',
  'customer-favorites.html',
  'customer-orders.html',
  'customer-reviews.html',
  'farmer-add-product.html',
  'farmer-dashboard.html',
  'farmer-login.html',
  'farmer-orders.html',
  'farmer-products.html',
  'farmer-profile.html',
  'farmer-register.html',
  'farmer-reviews.html',
  'farmers.html',
  'index.html',
  'login.html',
  'market-details.html',
  'markets.html',
  'order-details.html',
  'preorder.html',
  'product-details.html',
  'products.html',
  'register.html',
  'sitemap.html'
];

function processHtmlFile(fileName) {
  const filePath = path.join(baseDir, fileName);
  if (!fs.existsSync(filePath)) return;

  let content = fs.readFileSync(filePath, 'utf8');

  // Extract title
  const titleMatch = content.match(/<title>(.*?)<\/title>/s);
  const pageTitle = titleMatch ? titleMatch[1].trim() : 'MarketLink';

  // Determine current page ID
  const pageId = fileName.replace('.html', '');

  // Update all .html references to .php in content
  content = content.replace(/href="([^"]+)\.html(#|\?|")?/g, (match, p1, p2) => {
    return `href="${p1}.php${p2 || ''}`;
  });
  content = content.replace(/action="([^"]+)\.html(#|\?|")?/g, (match, p1, p2) => {
    return `action="${p1}.php${p2 || ''}`;
  });

  // Check if standard header & nav exist
  const bodyStartIdx = content.indexOf('<body');
  const mainStartIdx = content.indexOf('<main');
  const navStartIdx = content.indexOf('<nav');
  const footerStartIdx = content.lastIndexOf('<footer');
  const bodyEndIdx = content.lastIndexOf('</body>');

  let newContent = '';

  if (navStartIdx !== -1 && footerStartIdx !== -1) {
    // Has nav and footer
    const navEndIdx = content.indexOf('</nav>', navStartIdx) + 6;

    // Body header replacement
    const topPhpHeader = `<?php
$page_title = "${pageTitle.replace(/"/g, '\\"')} ";
$current_page = "${pageId}";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>\n`;

    // Footer replacement
    const bottomPhpFooter = `\n<?php
require_once __DIR__ . '/includes/footer.php';
?>\n`;

    const mainBody = content.substring(navEndIdx, footerStartIdx);

    newContent = topPhpHeader + mainBody + bottomPhpFooter;
  } else {
    // Simple header + footer wrap for admin/auth files without main nav
    let bodyContent = content;
    
    // Replace html head with header.php
    if (content.includes('</head>')) {
      const headEnd = content.indexOf('</head>') + 7;
      const bodyTagEnd = content.indexOf('>', content.indexOf('<body')) + 1;
      const startCut = bodyTagEnd > headEnd ? bodyTagEnd : headEnd;
      
      const footerCut = footerStartIdx !== -1 ? footerStartIdx : (bodyEndIdx !== -1 ? bodyEndIdx : content.length);
      
      bodyContent = content.substring(startCut, footerCut);
    }

    newContent = `<?php
$page_title = "${pageTitle.replace(/"/g, '\\"')} ";
$current_page = "${pageId}";
require_once __DIR__ . '/includes/header.php';
?>\n` + bodyContent + `\n<?php
require_once __DIR__ . '/includes/footer.php';
?>\n`;
  }

  // Write to .php file
  const phpFileName = fileName.replace('.html', '.php');
  const phpFilePath = path.join(baseDir, phpFileName);
  fs.writeFileSync(phpFilePath, newContent, 'utf8');

  // Delete original html file
  fs.unlinkSync(filePath);
  console.log(`Converted ${fileName} -> ${phpFileName}`);
}

// Convert all HTML files
htmlFiles.forEach(processHtmlFile);

// Also update JS files to replace .html references with .php
const jsDir = path.join(baseDir, 'js');
if (fs.existsSync(jsDir)) {
  fs.readdirSync(jsDir).forEach(file => {
    if (file.endsWith('.js')) {
      const jsPath = path.join(jsDir, file);
      let jsContent = fs.readFileSync(jsPath, 'utf8');
      const updatedJs = jsContent.replace(/\.html/g, '.php');
      fs.writeFileSync(jsPath, updatedJs, 'utf8');
      console.log(`Updated JS references in ${file}`);
    }
  });
}

console.log('Conversion complete!');

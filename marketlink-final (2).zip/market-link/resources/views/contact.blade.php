@extends('layouts.app')

@section('title', 'Contact Us — MarketLink')

@section('content')
<main>
        <!-- Page Hero -->
        <section class="ml-page-hero text-white py-5" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-5 text-center">
                <h1 class="display-4 fw-bold mb-3">Contact Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">Contact</li>
                    </ol>
                </nav>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="py-5">
            <div class="container py-4">
                <div class="row g-5">
                    <!-- Contact Form -->
                    <div class="col-lg-7">
                        <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border">
                            <h3 class="fw-bold mb-2">Get in Touch</h3>
                            <p class="text-muted mb-4">Have questions about an order, a farmer, or want to join our platform? Fill out the form below and we'll get back to you within 24 hours.</p>
                            
                            <form id="contactForm" action="/contact" method="POST">
                                @csrf
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="contactName" class="form-label fw-medium">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="contactName" placeholder="John Doe" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="contactEmail" class="form-label fw-medium">Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" id="contactEmail" placeholder="john@example.com" required>
                                    </div>
                                    <div class="col-12">
                                        <label for="contactSubject" class="form-label fw-medium">Subject <span class="text-danger">*</span></label>
                                        <select class="form-select" id="contactSubject" required>
                                            <option value="" selected disabled>Select a subject...</option>
                                            <option value="General Inquiry">General Inquiry</option>
                                            <option value="Customer Support">Customer Support / Order Issue</option>
                                            <option value="Farmer Application">Farmer Application</option>
                                            <option value="Market Partnership">Market Partnership</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="contactMessage" class="form-label fw-medium">Message <span class="text-danger">*</span></label>
                                        <textarea class="form-control" id="contactMessage" rows="5" placeholder="How can we help you?" required></textarea>
                                    </div>
                                    <div class="col-12 mt-4">
                                        <button type="submit" class="btn ml-btn-primary px-5 py-2">Send Message <i class="fas fa-paper-plane ms-2"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Contact Info -->
                    <div class="col-lg-5">
                        <div class="d-flex flex-column h-100 gap-4">
                            <!-- Info Cards -->
                            <div class="bg-success-subtle p-4 rounded-4">
                                <h4 class="fw-bold mb-4">Contact Information</h4>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Office Address</h6>
                                        <p class="text-muted small mb-0">123 Green Valley Road<br>Suite 200<br>Portland, OR 97204</p>
                                    </div>
                                </div>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Email Us</h6>
                                        <p class="text-muted small mb-0"><a href="mailto:support@marketlink.com" class="text-decoration-none text-muted">support@marketlink.com</a><br><a href="mailto:farmers@marketlink.com" class="text-decoration-none text-muted">farmers@marketlink.com</a></p>
                                    </div>
                                </div>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Call Us</h6>
                                        <p class="text-muted small mb-0"><a href="tel:+15551234567" class="text-decoration-none text-muted">+1 (555) 123-4567</a><br>Mon-Fri, 9am - 5pm</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Social Links -->
                            <div class="bg-light p-4 rounded-4 text-center">
                                <h5 class="fw-bold mb-3">Connect With Us</h5>
                                <div class="d-flex justify-content-center gap-3">
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-twitter"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-instagram"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Map Placeholder -->
        <section class="py-5 bg-light">
            <div class="container-fluid px-0">
                <div class="w-100 bg-secondary" style="height: 400px; position: relative;">
                    <div class="d-flex align-items-center justify-content-center h-100 text-center" style="background: url('https://picsum.photos/1600/400?random=50') center/cover; position: relative;">
                        <div class="position-absolute top-0 start-0 w-100 h-100 bg-dark opacity-50"></div>
                        <div class="position-relative z-1 text-white p-4">
                            <i class="fas fa-map-pin fa-3x mb-3 text-success"></i>
                            <h3 class="fw-bold">Find us on the map</h3>
                            <p class="mb-0">Interactive OpenStreetMap loading...</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
@endsection

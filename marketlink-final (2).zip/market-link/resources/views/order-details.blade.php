@extends('layouts.app')

@section('title', 'Order Details - MarketLink')

@section('content')
@if(!empty($order ?? null))
<div class="container py-5">
    <a href="{{ $backUrl ?? '/customer-orders' }}" class="text-decoration-none text-muted mb-3 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <h2 class="fw-bold mb-0">Order {{ $order->code() }}</h2>
        <span class="badge {{ $order->statusBadge() }} px-3 py-2 rounded-pill fs-6">{{ $order->statusLabel() }}</span>
    </div>

    @if($order->status === 'cancelled')
      <div class="alert alert-danger"><i class="fas fa-ban me-2"></i> This order was cancelled. Stock has been returned to the farmer's inventory.</div>
    @endif

    <!-- Progress Timeline -->
    @php
      $steps = ['pending' => 'Pending', 'confirmed' => 'Confirmed', 'ready' => 'Ready for Pickup', 'completed' => 'Completed'];
      $keys = array_keys($steps);
      $currentIdx = array_search($order->status, $keys);
      if ($currentIdx === false) $currentIdx = -1;
    @endphp
    <div class="step-indicator mb-5">
        @foreach($steps as $key => $label)
          @php $idx = array_search($key, $keys); @endphp
          @if($idx > 0)<div class="step-line {{ $idx <= $currentIdx ? 'bg-success' : '' }}"></div>@endif
          <div class="step {{ $idx < $currentIdx ? 'completed' : ($idx === $currentIdx ? 'active' : '') }}">
              <div class="step-icon">@if($idx < $currentIdx)<i class="fas fa-check"></i>@else{{ $idx + 1 }}@endif</div>
              <span>{{ $label }}</span>
          </div>
        @endforeach
    </div>

    <div class="row g-4">
        <!-- Left: Items -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Items ({{ $order->items->count() }})</h5>
                    @foreach($order->items as $it)
                      <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                          <img src="{{ $it->product ? $it->product->imageUrl() : 'https://via.placeholder.com/70' }}" class="rounded-2" width="70" height="70" alt="Item" style="object-fit: cover;">
                          <div class="flex-grow-1">
                              <div class="fw-medium">{{ $it->name }}</div>
                              <small class="text-muted">{{ $it->qty }} {{ $it->unit }} &times; PKR {{ number_format($it->price, 0) }}</small>
                          </div>
                          <div class="fw-bold">PKR {{ number_format($it->price * $it->qty, 0) }}</div>
                      </div>
                    @endforeach
                    <hr>
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-medium">PKR {{ number_format($order->subtotal, 0) }}</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold fs-5">Total (pay at pickup)</span>
                        <span class="fw-bold fs-5 text-success">PKR {{ number_format($order->subtotal, 0) }}</span>
                    </div>
                </div>
            </div>

            <!-- Pickup Info -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Pickup Information</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-map-marker-alt text-success mb-1"></i>
                                <div class="fw-medium small">Market</div>
                                <div class="small text-muted">{{ $order->market ?? '—' }}</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-calendar-alt text-success mb-1"></i>
                                <div class="fw-medium small">Pickup Date</div>
                                <div class="small text-muted">{{ $order->pickup_date ? \Carbon\Carbon::parse($order->pickup_date)->format('D, M d, Y') : '—' }}</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-clock text-success mb-1"></i>
                                <div class="fw-medium small">Time Slot</div>
                                <div class="small text-muted">{{ $order->pickup_slot ?? '—' }}</div>
                            </div>
                        </div>
                    </div>
                    @if($order->notes)
                      <div class="mt-3 p-3 bg-light rounded-3">
                          <div class="fw-medium small mb-1">Your Notes</div>
                          <div class="small text-muted">{{ $order->notes }}</div>
                      </div>
                    @endif
                </div>
            </div>

            <!-- Review -->
            @if($canReview ?? false)
            <div class="card border-0 shadow-sm mb-4" id="write-review">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Write a Review</h5>
                    <form action="/reviews" method="POST">
                        @csrf
                        <input type="hidden" name="order_id" value="{{ $order->id }}">
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Rating *</label>
                            <div class="d-flex gap-1 fs-4" id="star-picker">
                                @for($i = 1; $i <= 5; $i++)
                                  <i class="far fa-star text-warning" data-star="{{ $i }}" style="cursor:pointer;"></i>
                                @endfor
                            </div>
                            <input type="hidden" name="rating" id="rating-input" value="{{ old('rating', 5) }}" required>
                            @error('rating')<div class="text-danger small">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Review</label>
                            <textarea class="form-control" name="comment" rows="3" placeholder="How was the quality? Was pickup smooth?">{{ old('comment') }}</textarea>
                        </div>
                        <button type="submit" class="btn btn-warning fw-bold"><i class="fas fa-star me-1"></i> Submit Review</button>
                    </form>
                </div>
            </div>
            @elseif($order->review)
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Your Review</h5>
                    <div class="text-warning mb-2">
                        @for($i = 1; $i <= 5; $i++)
                          <i class="fas fa-star {{ $i <= $order->review->rating ? '' : 'text-muted opacity-25' }}"></i>
                        @endfor
                    </div>
                    @if($order->review->comment)
                      <p class="mb-0">{{ $order->review->comment }}</p>
                    @endif
                </div>
            </div>
            @endif
        </div>

        <!-- Right: Farmer + Actions -->
        <div class="col-lg-4">
            @if($order->farmer)
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4 text-center">
                    <img src="{{ $order->farmer->avatarUrl() }}" class="rounded-circle mb-2" width="70" height="70" alt="Farmer" style="object-fit: cover;">
                    <h6 class="fw-bold mb-0">{{ $order->farmer->displayName() }}</h6>
                    <small class="text-muted">{{ $order->farmer->farm_name ?? 'Local Farmer' }}</small>
                    <div class="mt-2">
                        <a href="/farmer-profile?id={{ $order->farmer->id }}" class="btn btn-sm btn-outline-success">View Profile</a>
                    </div>
                </div>
            </div>
            @endif

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Order Info</h6>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Placed</span><span>{{ $order->created_at->format('M d, Y h:i A') }}</span></div>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Customer</span><span>{{ $order->customer->name }}</span></div>
                    <div class="small d-flex justify-content-between"><span class="text-muted">Status</span><span class="badge {{ $order->statusBadge() }}">{{ $order->statusLabel() }}</span></div>
                </div>
            </div>

            @if($canCancel ?? false)
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4 d-grid">
                    <form action="/customer-orders/{{ $order->id }}/cancel" method="POST" onsubmit="return confirm('Cancel this order?')">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger w-100"><i class="fas fa-times me-1"></i> Cancel Order</button>
                    </form>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@else
<div class="container py-5">
    <a href="/customer-orders" class="text-decoration-none text-muted mb-3 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <h2 class="fw-bold mb-0">Order #ML-00001</h2>
        <span class="badge bg-warning px-3 py-2 rounded-pill fs-6">Pending</span>
    </div>

    <div class="step-indicator mb-5">
        <div class="step active"><div class="step-icon">1</div><span>Pending</span></div>
        <div class="step-line"></div>
        <div class="step"><div class="step-icon">2</div><span>Confirmed</span></div>
        <div class="step-line"></div>
        <div class="step"><div class="step-icon">3</div><span>Ready for Pickup</span></div>
        <div class="step-line"></div>
        <div class="step"><div class="step-icon">4</div><span>Completed</span></div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Items (2)</h5>
                    <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                        <img src="https://picsum.photos/70/70?tomato" class="rounded-2" width="70" height="70" alt="Item" style="object-fit: cover;">
                        <div class="flex-grow-1">
                            <div class="fw-medium">Organic Tomatoes</div>
                            <small class="text-muted">2 kg &times; PKR 350</small>
                        </div>
                        <div class="fw-bold">PKR 700</div>
                    </div>
                    <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                        <img src="https://picsum.photos/70/70?milk" class="rounded-2" width="70" height="70" alt="Item" style="object-fit: cover;">
                        <div class="flex-grow-1">
                            <div class="fw-medium">Fresh Milk</div>
                            <small class="text-muted">3 litre &times; PKR 220</small>
                        </div>
                        <div class="fw-bold">PKR 660</div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold fs-5">Total (pay at pickup)</span>
                        <span class="fw-bold fs-5 text-success">PKR 1,360</span>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Pickup Information</h5>
                    <div class="row g-3">
                        <div class="col-md-4"><div class="p-3 bg-light rounded-3 text-center"><i class="fas fa-map-marker-alt text-success mb-1"></i><div class="fw-medium small">Market</div><div class="small text-muted">Downtown Farmers Market</div></div></div>
                        <div class="col-md-4"><div class="p-3 bg-light rounded-3 text-center"><i class="fas fa-calendar-alt text-success mb-1"></i><div class="fw-medium small">Pickup Date</div><div class="small text-muted">Sat, Sep 26, 2026</div></div></div>
                        <div class="col-md-4"><div class="p-3 bg-light rounded-3 text-center"><i class="fas fa-clock text-success mb-1"></i><div class="fw-medium small">Time Slot</div><div class="small text-muted">9:00 AM - 10:00 AM</div></div></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4 text-center">
                    <img src="https://picsum.photos/70/70?farmer" class="rounded-circle mb-2" width="70" height="70" alt="Farmer" style="object-fit: cover;">
                    <h6 class="fw-bold mb-0">Green Valley Farm</h6>
                    <small class="text-muted">Local Farmer</small>
                    <div class="mt-2"><a href="/farmer-profile" class="btn btn-sm btn-outline-success">View Profile</a></div>
                </div>
            </div>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Order Info</h6>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Placed</span><span>Sep 25, 2026</span></div>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Customer</span><span>John Smith</span></div>
                    <div class="small d-flex justify-content-between"><span class="text-muted">Status</span><span class="badge bg-warning">Pending</span></div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
@endsection

@push('scripts')
<script>
    (function() {
        const picker = document.getElementById('star-picker');
        const input = document.getElementById('rating-input');
        if (!picker || !input) return;
        const stars = picker.querySelectorAll('[data-star]');
        const paint = (n) => {
            stars.forEach(s => {
                const v = parseInt(s.dataset.star, 10);
                s.classList.toggle('fas', v <= n);
                s.classList.toggle('far', v > n);
            });
        };
        paint(parseInt(input.value, 10) || 5);
        stars.forEach(s => s.addEventListener('click', () => {
            input.value = s.dataset.star;
            paint(parseInt(input.value, 10));
        }));
    })();
</script>
@endpush

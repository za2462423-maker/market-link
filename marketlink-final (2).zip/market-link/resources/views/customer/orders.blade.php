@extends('layouts.dashboard')

@section('title', 'MarketLink - My Orders')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-customer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Customer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Customer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/customer-orders" class="ml-sidebar-link active"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/products" class="ml-sidebar-link"><i class="fas fa-store"></i> Browse Products</a>
        <a href="/customer-favorites" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> My Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <a href="/cart" class="btn btn-light position-relative"><i class="fas fa-shopping-cart"></i></a>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div>
            <h2 class="h4 fw-bold mb-0">My Orders</h2>
            <p class="text-muted mb-0 small">Track your pre-orders and pickup schedule.</p>
          </div>
          <a href="/products" class="btn btn-success"><i class="fas fa-plus"></i> New Order</a>
        </div>

        <ul class="nav nav-pills gap-2 mb-4 flex-wrap">
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="" href="/customer-orders">
                All <span class="badge bg-light text-dark ms-1">{{ $countsAll ?? 0 }}</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="pending" href="/customer-orders?status=pending">
                Pending <span class="badge bg-light text-dark ms-1">{{ $countsPending ?? 0 }}</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="confirmed" href="/customer-orders?status=confirmed">
                Confirmed <span class="badge bg-light text-dark ms-1">{{ $countsConfirmed ?? 0 }}</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="ready" href="/customer-orders?status=ready">
                Ready <span class="badge bg-light text-dark ms-1">{{ $countsReady ?? 0 }}</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="completed" href="/customer-orders?status=completed">
                Completed <span class="badge bg-light text-dark ms-1">{{ $countsCompleted ?? 0 }}</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link bg-white text-dark border order-tab" data-status="cancelled" href="/customer-orders?status=cancelled">
                Cancelled <span class="badge bg-light text-dark ms-1">{{ $countsCancelled ?? 0 }}</span>
              </a>
            </li>
        </ul>

        <form method="GET" action="/customer-orders" class="d-flex flex-wrap gap-2 mb-4">
          <input type="hidden" name="status" value="{{ $status ?? '' }}">
          <div class="input-group" style="max-width: 350px;">
            <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
            <input type="text" name="search" class="form-control border-start-0" placeholder="Search order ID..." value="{{ $search ?? '' }}">
          </div>
          <input type="date" name="date" class="form-control" style="max-width: 170px;" value="{{ $date ?? '' }}" onchange="this.form.submit()">
          <button type="submit" class="btn btn-success">Search</button>
          <a href="/customer-orders" class="btn btn-light border">Clear</a>
        </form>

        @forelse($orders ?? [] as $o)
        <div class="card border-0 shadow-sm rounded-3 mb-3">
          <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
              <span class="fw-bold">{{ $o->code() }}</span>
              <span class="text-muted small ms-2"><i class="far fa-clock"></i> {{ $o->created_at->diffForHumans() }}</span>
            </div>
            <span class="badge {{ $o->statusBadge() }} px-3 py-2 rounded-pill">{{ $o->statusLabel() }}</span>
          </div>
          <div class="card-body p-3">
            <div class="d-flex align-items-center gap-2 flex-wrap mb-2">
              @foreach($o->items->take(4) as $it)
                <img src="{{ $it->product ? $it->product->imageUrl() : 'https://via.placeholder.com/60' }}" class="rounded-2 border" width="56" height="56" alt="Item" style="object-fit: cover;" title="{{ $it->name }} ({{ $it->qty }} {{ $it->unit }})">
              @endforeach
              @if($o->items->count() > 4)
                <span class="text-muted small">+{{ $o->items->count() - 4 }} more</span>
              @endif
            </div>
            <div class="small text-muted mb-1">{{ $o->itemsSummary() }}</div>
            <div class="small">
              <i class="fas fa-store text-success me-1"></i>
              @if($o->farmer)
                <a href="/farmer-profile?id={{ $o->farmer->id }}" class="text-decoration-none">{{ $o->farmer->displayName() }}</a>
              @else
                <span class="text-muted">Farmer</span>
              @endif
              <span class="text-muted ms-2"><i class="fas fa-map-marker-alt me-1"></i>{{ $o->market ?? '—' }}</span>
              <span class="text-muted ms-2"><i class="fas fa-calendar-alt me-1"></i>{{ $o->pickup_date ?? '—' }} {{ $o->pickup_slot ?? '' }}</span>
            </div>
          </div>
          <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="fw-bold">Total: <span class="text-success">PKR {{ number_format($o->subtotal, 0) }}</span></span>
            <div class="d-flex gap-2">
              <a href="/order-details?id={{ $o->id }}" class="btn btn-outline-success btn-sm"><i class="fas fa-eye me-1"></i> View Details</a>
              @if($o->status === 'pending')
                <form action="/customer-orders/{{ $o->id }}/cancel" method="POST" class="d-inline" onsubmit="return confirm('Cancel this order?')">
                  @csrf
                  <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-times me-1"></i> Cancel Order</button>
                </form>
              @elseif($o->status === 'completed' && !$o->review)
                <a href="/order-details?id={{ $o->id }}#write-review" class="btn btn-warning btn-sm"><i class="fas fa-star me-1"></i> Write Review</a>
              @endif
            </div>
          </div>
        </div>
        @empty
        <div class="card border-0 shadow-sm rounded-3 mb-3">
          <div class="card-body text-center py-5 text-muted">
            <i class="fas fa-shopping-bag fa-2x mb-3 d-block"></i>
            No orders yet. <a href="/products" class="text-success fw-medium">Browse products</a> to place your first pre-order.
          </div>
        </div>
        @endforelse

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
      var curStatus = new URLSearchParams(window.location.search).get('status') || '';
      document.querySelectorAll('.order-tab').forEach(function (a) {
        if ((a.getAttribute('data-status') || '') !== curStatus) return;
        a.classList.add('active');
        if (a.classList.contains('bg-white')) { a.classList.remove('bg-white', 'text-dark', 'border'); a.classList.add('bg-success', 'text-white'); }
        var b = a.querySelector('.badge');
        if (b) { b.classList.remove('bg-light', 'text-dark'); b.classList.add('bg-white', 'text-success'); }
      });
    });
  </script>
@endpush

@extends('layouts.dashboard')

@section('title', 'MarketLink - My Favorites')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-customer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Customer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Customer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/products" class="ml-sidebar-link"><i class="fas fa-store"></i> Browse Products</a>
        <a href="/customer-favorites" class="ml-sidebar-link active"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> My Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <a href="/cart" class="btn btn-light position-relative"><i class="fas fa-shopping-cart"></i></a>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div>
            <h2 class="h4 fw-bold mb-0">My Favorites</h2>
            <p class="text-muted mb-0 small">Your saved products &mdash; open one to add it to your cart.</p>
          </div>
          <a href="/products" class="btn btn-success"><i class="fas fa-store"></i> Browse Products</a>
        </div>

        <div class="row g-4">
          @forelse($favorites ?? [] as $fav)
            @if($fav->product)
            <div class="col-md-6 col-xl-4">
              <div class="card border-0 shadow-sm rounded-3 h-100 overflow-hidden">
                <div class="position-relative">
                  <img src="{{ $fav->product->imageUrl() }}" class="card-img-top" alt="Product" style="height: 180px; object-fit: cover;">
                  <span class="badge bg-success position-absolute top-0 start-0 m-2">{{ $fav->product->category }}</span>
                </div>
                <div class="card-body">
                  <h6 class="fw-bold mb-1">{{ $fav->product->name }}</h6>
                  <div class="small text-muted mb-2">
                    <i class="fas fa-store me-1"></i>{{ $fav->product->farmer ? $fav->product->farmer->displayName() : 'Farmer' }}
                  </div>
                  <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="fw-bold text-success">PKR {{ number_format($fav->product->price, 0) }} <small class="text-muted fw-normal">/ {{ $fav->product->unit }}</small></span>
                    @if($fav->product->stock > 0 && $fav->product->is_available)
                      <span class="badge bg-success">In Stock</span>
                    @else
                      <span class="badge bg-secondary">Unavailable</span>
                    @endif
                  </div>
                  <div class="d-flex gap-2">
                    <a href="/product-details?id={{ $fav->product->id }}" class="btn btn-outline-success btn-sm flex-grow-1"><i class="fas fa-eye me-1"></i> View</a>
                    <form action="/favorites/toggle" method="POST" class="flex-grow-1 d-grid">
                      @csrf
                      <input type="hidden" name="product_id" value="{{ $fav->product->id }}">
                      <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-heart-broken me-1"></i> Remove</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            @endif
          @empty
            <div class="col-12">
              <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body text-center py-5 text-muted">
                  <i class="fas fa-heart fa-2x mb-3 d-block"></i>
                  No favorites yet. Tap the <i class="fas fa-heart text-danger"></i> on any product to save it here.
                  <div class="mt-3"><a href="/products" class="btn btn-success">Browse Products</a></div>
                </div>
              </div>
            </div>
          @endforelse
        </div>

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
    });
  </script>
@endpush

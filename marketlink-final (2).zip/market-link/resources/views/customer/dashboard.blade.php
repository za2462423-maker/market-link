@extends('layouts.dashboard')

@section('title', 'Customer Dashboard - MarketLink')

@section('content')
<div class="ml-dashboard-wrapper d-flex">
  
  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="/" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">{{ auth()->user()->name }}</div>
        <div class="ml-sidebar-role">Customer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="/customer-dashboard" class="ml-sidebar-link active"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="/customer-favorites" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
      <a href="/customer-favorites#markets" class="ml-sidebar-link"><i class="fas fa-map-marker-alt"></i> Saved Markets</a>
      <a href="/customer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications <span class="ml-sidebar-badge badge bg-danger rounded-pill">3</span></a>
      <hr class="ml-sidebar-divider">
      <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
    
    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">Dashboard</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="/products" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <div class="ml-topbar-notif position-relative" id="notifBtn" style="cursor:pointer;">
          <i class="fas fa-bell fa-lg text-secondary"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">3</span>
        </div>
        <img src="https://picsum.photos/36/36?random=99" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">
      
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1 class="h3 mb-1 fw-bold">Good morning, John! 🌱</h1>
          <p class="text-muted mb-0">Here's your farming dashboard.</p>
        </div>
      </div>

      <div class="row g-4 mb-4">
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-success border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Total Orders</h6>
                  <h3 class="mb-0 fw-bold">12</h3>
                </div>
                <div class="bg-success bg-opacity-10 p-3 rounded text-success">
                  <i class="fas fa-shopping-bag fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-warning border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Pending Orders</h6>
                  <h3 class="mb-0 fw-bold">3</h3>
                </div>
                <div class="bg-warning bg-opacity-10 p-3 rounded text-warning">
                  <i class="fas fa-clock fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-info border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Ready for Pickup</h6>
                  <h3 class="mb-0 fw-bold">2</h3>
                </div>
                <div class="bg-info bg-opacity-10 p-3 rounded text-info">
                  <i class="fas fa-store fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-success border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Completed</h6>
                  <h3 class="mb-0 fw-bold">7</h3>
                </div>
                <div class="bg-success bg-opacity-10 p-3 rounded text-success">
                  <i class="fas fa-check fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4 d-flex gap-3 flex-wrap">
        <a href="/products" class="btn btn-outline-success"><i class="fas fa-search"></i> Browse Products</a>
        <a href="/markets" class="btn btn-outline-success"><i class="fas fa-map-marker-alt"></i> Find Markets</a>
        <a href="/customer-orders" class="btn btn-outline-success"><i class="fas fa-list"></i> View Orders</a>
      </div>

      <div class="row g-4 mb-4">
        <div class="col-lg-8">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
              <h5 class="mb-0 fw-bold">Recent Orders</h5>
              <a href="/customer-orders" class="text-decoration-none small text-success">View All</a>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover align-middle">
                  <thead>
                    <tr class="text-secondary">
                      <th>Order ID</th>
                      <th>Farmer</th>
                      <th>Products</th>
                      <th>Pickup Date</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="fw-medium">#ORD-001</td>
                      <td>Green Valley Farm</td>
                      <td class="text-truncate" style="max-width: 150px;">Tomatoes, Carrots</td>
                      <td>Oct 15, 2026</td>
                      <td><span class="badge bg-secondary">Placed</span></td>
                      <td><a href="/order-details" class="btn btn-sm btn-outline-secondary">View</a></td>
                    </tr>
                    <tr>
                      <td class="fw-medium">#ORD-002</td>
                      <td>Sunny Acres</td>
                      <td class="text-truncate" style="max-width: 150px;">Organic Eggs (x2)</td>
                      <td>Oct 14, 2026</td>
                      <td><span class="badge bg-primary">Accepted</span></td>
                      <td><a href="/order-details" class="btn btn-sm btn-outline-secondary">View</a></td>
                    </tr>
                    <tr>
                      <td class="fw-medium">#ORD-003</td>
                      <td>River Fresh Market</td>
                      <td class="text-truncate" style="max-width: 150px;">Apples, Honey</td>
                      <td>Oct 12, 2026</td>
                      <td><span class="badge bg-warning text-dark">Ready for Pickup</span></td>
                      <td><a href="/order-details" class="btn btn-sm btn-outline-secondary">View</a></td>
                    </tr>
                    <tr>
                      <td class="fw-medium">#ORD-004</td>
                      <td>Local Roots</td>
                      <td class="text-truncate" style="max-width: 150px;">Potatoes</td>
                      <td>Oct 10, 2026</td>
                      <td><span class="badge bg-success">Completed</span></td>
                      <td><a href="/order-details" class="btn btn-sm btn-outline-secondary">View</a></td>
                    </tr>
                    <tr>
                      <td class="fw-medium">#ORD-005</td>
                      <td>Green Valley Farm</td>
                      <td class="text-truncate" style="max-width: 150px;">Lettuce</td>
                      <td>Oct 05, 2026</td>
                      <td><span class="badge bg-danger">Cancelled</span></td>
                      <td><a href="/order-details" class="btn btn-sm btn-outline-secondary">View</a></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 pt-4 pb-0">
              <h5 class="mb-0 fw-bold">Upcoming Pickups</h5>
            </div>
            <div class="card-body">
              <div class="d-flex mb-3 border-start border-success border-3 ps-3">
                <div class="me-3 text-center" style="min-width: 45px;">
                  <div class="h5 mb-0 text-success fw-bold">12</div>
                  <small class="text-muted fw-semibold">OCT</small>
                </div>
                <div>
                  <h6 class="mb-1 fw-bold">River Fresh Market</h6>
                  <small class="text-muted d-block"><i class="fas fa-clock me-1"></i> 9:00 AM - 12:00 PM</small>
                  <small class="text-muted"><i class="fas fa-user me-1"></i> River Fresh Market</small>
                </div>
              </div>
              <div class="d-flex border-start border-success border-3 ps-3">
                <div class="me-3 text-center" style="min-width: 45px;">
                  <div class="h5 mb-0 text-success fw-bold">14</div>
                  <small class="text-muted fw-semibold">OCT</small>
                </div>
                <div>
                  <h6 class="mb-1 fw-bold">Sunny Acres</h6>
                  <small class="text-muted d-block"><i class="fas fa-clock me-1"></i> 10:00 AM - 2:00 PM</small>
                  <small class="text-muted"><i class="fas fa-user me-1"></i> Sunny Acres</small>
                </div>
              </div>
            </div>
          </div>

          <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4 pb-0">
              <h5 class="mb-0 fw-bold">Notifications</h5>
            </div>
            <div class="card-body">
              <div class="d-flex mb-3">
                <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                  <i class="fas fa-bell small"></i>
                </div>
                <div>
                  <p class="mb-1 small">Your order <strong class="text-dark">#ORD-003</strong> is ready for pickup.</p>
                  <small class="text-muted">2 hours ago</small>
                </div>
              </div>
              <div class="d-flex mb-3">
                <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                  <i class="fas fa-bell small"></i>
                </div>
                <div>
                  <p class="mb-1 small"><strong class="text-dark">Sunny Acres</strong> accepted your order #ORD-002.</p>
                  <small class="text-muted">5 hours ago</small>
                </div>
              </div>
              <div class="d-flex">
                <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                  <i class="fas fa-bell small"></i>
                </div>
                <div>
                  <p class="mb-1 small">New seasonal products available at <strong class="text-dark">Downtown Market</strong>.</p>
                  <small class="text-muted">1 day ago</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="mb-0 fw-bold">Favorite Farmers</h5>
          <a href="/customer-favorites#farmers" class="text-decoration-none small text-success">View All</a>
        </div>
        <div class="d-flex gap-3 overflow-auto pb-2" style="white-space: nowrap;">
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 250px;">
            <div class="card-body d-flex align-items-center">
              <img src="https://picsum.photos/50/50?random=1" class="rounded-circle me-3" alt="Farmer">
              <div>
                <h6 class="mb-0 fw-bold">Green Valley Farm</h6>
                <small class="text-muted">Organic Veggies</small>
              </div>
            </div>
          </div>
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 250px;">
            <div class="card-body d-flex align-items-center">
              <img src="https://picsum.photos/50/50?random=2" class="rounded-circle me-3" alt="Farmer">
              <div>
                <h6 class="mb-0 fw-bold">Sunny Acres</h6>
                <small class="text-muted">Dairy & Eggs</small>
              </div>
            </div>
          </div>
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 250px;">
            <div class="card-body d-flex align-items-center">
              <img src="https://picsum.photos/50/50?random=3" class="rounded-circle me-3" alt="Farmer">
              <div>
                <h6 class="mb-0 fw-bold">River Fresh Market</h6>
                <small class="text-muted">Fruits & Honey</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="mb-0 fw-bold">Favorite Products</h5>
          <a href="/customer-favorites#products" class="text-decoration-none small text-success">View All</a>
        </div>
        <div class="d-flex gap-3 overflow-auto pb-2" style="white-space: nowrap;">
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 200px;">
            <img src="https://picsum.photos/200/120?random=4" class="card-img-top object-fit-cover" style="height:120px" alt="Product">
            <div class="card-body p-3">
              <h6 class="mb-1 text-truncate fw-bold">Organic Tomatoes</h6>
              <div class="text-success fw-bold">$4.50/lb</div>
            </div>
          </div>
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 200px;">
            <img src="https://picsum.photos/200/120?random=5" class="card-img-top object-fit-cover" style="height:120px" alt="Product">
            <div class="card-body p-3">
              <h6 class="mb-1 text-truncate fw-bold">Fresh Honey</h6>
              <div class="text-success fw-bold">$8.00/jar</div>
            </div>
          </div>
          <div class="card border-0 shadow-sm d-inline-block" style="min-width: 200px;">
            <img src="https://picsum.photos/200/120?random=6" class="card-img-top object-fit-cover" style="height:120px" alt="Product">
            <div class="card-body p-3">
              <h6 class="mb-1 text-truncate fw-bold">Free Range Eggs</h6>
              <div class="text-success fw-bold">$6.00/doz</div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </main>
</div>
@endsection

@push('scripts')
<script>
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
</script>
@endpush

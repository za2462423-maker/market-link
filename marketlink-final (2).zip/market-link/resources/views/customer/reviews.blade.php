@extends('layouts.dashboard')

@section('title', 'MarketLink - My Reviews')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-customer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Customer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Customer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/products" class="ml-sidebar-link"><i class="fas fa-store"></i> Browse Products</a>
        <a href="/customer-favorites" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-reviews" class="ml-sidebar-link active"><i class="fas fa-star"></i> My Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <a href="/cart" class="btn btn-light position-relative"><i class="fas fa-shopping-cart"></i></a>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="mb-4">
          <h2 class="h4 fw-bold mb-0">My Reviews</h2>
          <p class="text-muted mb-0 small">Farmers you rated after completed pickups.</p>
        </div>

        @forelse($reviews ?? [] as $r)
          <div class="card border-0 shadow-sm rounded-3 mb-3 p-4">
            <div class="d-flex gap-3">
              <img src="{{ $r->farmer ? $r->farmer->avatarUrl() : 'https://via.placeholder.com/50' }}" class="rounded-circle flex-shrink-0" width="50" height="50" alt="F" style="object-fit: cover;">
              <div class="flex-grow-1">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                  <div>
                    <div class="fw-bold">{{ $r->farmer ? $r->farmer->displayName() : 'Farmer' }}</div>
                    <div class="small text-muted">{{ $r->created_at->diffForHumans() }}@if($r->order) &bull; Order {{ $r->order->code() }}@endif</div>
                  </div>
                  <div class="d-flex align-items-center gap-2">
                    <div class="text-warning">
                      @for($i = 1; $i <= 5; $i++)
                        <i class="fas fa-star {{ $i <= $r->rating ? '' : 'text-muted opacity-25' }}"></i>
                      @endfor
                    </div>
                    <form action="/reviews/{{ $r->id }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this review?')">
                      @csrf
                      @method('DELETE')
                      <button type="submit" class="btn btn-sm btn-light border text-danger" title="Delete review"><i class="fas fa-trash"></i></button>
                    </form>
                  </div>
                </div>
                @if($r->comment)
                  <p class="mt-2 mb-0">{{ $r->comment }}</p>
                @endif
              </div>
            </div>
          </div>
        @empty
          <div class="card border-0 shadow-sm rounded-3 mb-3">
            <div class="card-body text-center py-5 text-muted">
              <i class="fas fa-star fa-2x mb-3 d-block"></i>
              You have not written any reviews yet. Completed orders can be reviewed from <a href="/customer-orders" class="text-success fw-medium">My Orders</a>.
            </div>
          </div>
        @endforelse

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
    });
  </script>
@endpush

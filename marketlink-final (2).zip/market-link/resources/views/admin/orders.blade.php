@extends('layouts.dashboard')

@section('title', 'Admin Orders - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link active"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Manage Orders</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-shopping-bag"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3>{{ $statTotal ?? '3,582' }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-clock"></i></div>
              <div class="admin-stat-info">
                <p>Pending</p>
                <h3>{{ $statPending ?? 145 }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info">
                <p>Completed</p>
                <h3>{{ $statCompleted ?? '3,310' }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon" style="background:#f8d7da; color:#721c24"><i class="fas fa-times-circle"></i></div>
              <div class="admin-stat-info">
                <p>Cancelled</p>
                <h3>{{ $statCancelled ?? 127 }}</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <input type="text" class="form-control" placeholder="Search by Order ID..." style="max-width: 300px;">
            <select class="form-select w-auto">
              <option value="">All Statuses</option>
              <option>Pending</option>
              <option>Completed</option>
              <option>Cancelled</option>
            </select>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Farmer</th>
                  <th>Products</th>
                  <th>Pickup Date</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @forelse($orders ?? [] as $o)
                @php($bmap = ['pending' => 'badge-pending', 'confirmed' => 'badge-active', 'ready' => 'badge-active', 'completed' => 'badge-approved', 'cancelled' => 'badge-removed'])
                <tr>
                  <td><strong>{{ $o->code() }}</strong></td>
                  <td>{{ $o->customer ? $o->customer->name : '—' }}</td>
                  <td>{{ $o->farmer ? $o->farmer->displayName() : '—' }}</td>
                  <td title="{{ $o->itemsSummary() }}">{{ $o->items->count() }} item(s)</td>
                  <td>{{ $o->pickup_date ?? '—' }}</td>
                  <td>PKR {{ number_format($o->subtotal, 0) }}</td>
                  <td><span class="badge {{ $bmap[$o->status] ?? 'badge-pending' }}">{{ $o->statusLabel() }}</span></td>
                  <td><button class="btn btn-sm btn-light order-details-btn" data-bs-toggle="modal" data-bs-target="#orderModal" data-code="{{ $o->code() }}" data-status="{{ $o->statusLabel() }}" data-customer="{{ $o->customer ? $o->customer->name : '—' }}" data-farmer="{{ $o->farmer ? $o->farmer->displayName() : '—' }}" data-date="{{ $o->pickup_date ?? '—' }} {{ $o->pickup_slot ?? '' }}" data-total="PKR {{ number_format($o->subtotal, 0) }}" data-items="{{ $o->items->map(fn($i) => $i->qty . ' x ' . $i->name . ' — PKR ' . number_format($i->price * $i->qty, 0))->implode('|') }}"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                @empty
                <tr>
                  <td><strong>#ORD-8902</strong></td>
                  <td>Fatima Ali</td>
                  <td>Green Valley Farms</td>
                  <td>3 items</td>
                  <td>Sep 25, 2026</td>
                  <td>PKR 1,250</td>
                  <td><span class="badge badge-pending">Pending</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8901</strong></td>
                  <td>Usman Tariq</td>
                  <td>Ahmad's Organics</td>
                  <td>5 items</td>
                  <td>Sep 24, 2026</td>
                  <td>PKR 3,400</td>
                  <td><span class="badge badge-active">Completed</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8900</strong></td>
                  <td>Aisha Khan</td>
                  <td>Fresh Dairy Co.</td>
                  <td>1 items</td>
                  <td>Sep 24, 2026</td>
                  <td>PKR 850</td>
                  <td><span class="badge badge-active">Completed</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8899</strong></td>
                  <td>Bilal Qureshi</td>
                  <td>Green Fields</td>
                  <td>8 items</td>
                  <td>Sep 26, 2026</td>
                  <td>PKR 5,100</td>
                  <td><span class="badge badge-pending">Pending</span></td>
                  <td><button class="btn btn-sm btn-light"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8898</strong></td>
                  <td>Sana Hameed</td>
                  <td>Organic Veggies</td>
                  <td>2 items</td>
                  <td>Sep 23, 2026</td>
                  <td>PKR 2,200</td>
                  <td><span class="badge badge-removed">Cancelled</span></td>
                  <td><button class="btn btn-sm btn-light"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                @endforelse
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- Order Modal -->
  <div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="orderModalTitle">Order</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p><strong>Customer:</strong> <span id="omCustomer"></span></p>
          <p><strong>Farmer:</strong> <span id="omFarmer"></span></p>
          <p><strong>Status:</strong> <span id="omStatus"></span></p>
          <p><strong>Pickup:</strong> <span id="omDate"></span></p>
          <hr>
          <h6>Items:</h6>
          <ul class="list-group mb-3" id="omItems"></ul>
          <div class="d-flex justify-content-between fw-bold">
            <span>Total</span>
            <span id="omTotal"></span>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.order-details-btn');
      if (!btn) return;
      const d = btn.dataset;
      document.getElementById('orderModalTitle').textContent = 'Order ' + (d.code || '#ORD-8902');
      document.getElementById('omCustomer').textContent = d.customer || 'Fatima Ali';
      document.getElementById('omFarmer').textContent = d.farmer || 'Green Valley Farms';
      document.getElementById('omStatus').textContent = d.status || 'Pending';
      document.getElementById('omDate').textContent = d.date || 'Sep 25, 2026';
      document.getElementById('omTotal').textContent = d.total || 'PKR 1,250';
      const ul = document.getElementById('omItems');
      ul.innerHTML = '';
      const items = (d.items || '2 x Organic Tomatoes — PKR 300|3 x Fresh Potatoes — PKR 250|1 x Desi Eggs — PKR 700').split('|');
      items.forEach(t => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = t;
        ul.appendChild(li);
      });
    });
  </script>
@endpush

@extends('layouts.dashboard')

@section('title', 'Admin Reviews - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Review Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <select class="form-select w-auto">
              <option value="">All Reviews</option>
              <option>Pending</option>
              <option>Flagged</option>
              <option>Removed</option>
            </select>
          </div>
        </div>

        <div class="row g-4">
          @forelse($reviews ?? [] as $r)
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="{{ $r->customer ? $r->customer->avatarUrl() : 'https://via.placeholder.com/40' }}" class="rounded-circle" style="width:40px;height:40px;object-fit:cover;">
                  <div>
                    <strong>{{ $r->customer ? $r->customer->name : 'Customer' }}</strong><br>
                    <small class="text-muted">Reviewed: {{ $r->farmer ? $r->farmer->displayName() : 'Farmer' }}</small>
                  </div>
                </div>
              </div>
              <div class="text-warning mb-2">
                @for($i = 1; $i <= 5; $i++)
                  <i class="{{ $i <= $r->rating ? 'fas' : 'far' }} fa-star"></i>
                @endfor
              </div>
              <p class="mb-3 text-muted">&quot;{{ $r->comment ?? 'No comment.' }}&quot;</p>
              <small class="text-muted d-block mb-1">{{ $r->created_at->format('M d, Y') }}</small>
              @if($r->order)<small class="text-muted d-block">Order {{ $r->order->code() }}</small>@endif
            </div>
          </div>
          @empty
          <!-- Review Card -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=61" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Fatima Ali</strong><br>
                    <small class="text-muted">Reviewed: Organic Tomatoes</small>
                  </div>
                </div>
                <span class="badge badge-active">Approved</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"Excellent quality and very fresh. Will definitely buy again from this farmer!"</p>
              <small class="text-muted d-block mb-3">Sep 24, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-danger flex-grow-1"><i class="fas fa-trash"></i> Remove</button>
                <button class="btn btn-sm btn-outline-warning flex-grow-1"><i class="fas fa-flag"></i> Flag</button>
              </div>
            </div>
          </div>

          <!-- Review Card Flagged -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3 border-warning">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=62" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Usman Tariq</strong><br>
                    <small class="text-muted">Reviewed: Fresh Milk</small>
                  </div>
                </div>
                <span class="badge badge-flagged">Flagged</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"Milk smelled weird and was sour. Contains spam text: buy cheap followers at www.spam.com"</p>
              <small class="text-muted d-block mb-3">Sep 23, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-success flex-grow-1"><i class="fas fa-check"></i> Approve</button>
                <button class="btn btn-sm btn-outline-danger flex-grow-1"><i class="fas fa-trash"></i> Remove</button>
              </div>
            </div>
          </div>
          
          <!-- Review Card Removed -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3 opacity-75">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=63" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Unknown User</strong><br>
                    <small class="text-muted">Reviewed: Apples</small>
                  </div>
                </div>
                <span class="badge badge-removed">Removed</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"[Inappropriate Content Removed]"</p>
              <small class="text-muted d-block mb-3">Sep 22, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-success w-100"><i class="fas fa-undo"></i> Restore</button>
              </div>
            </div>
          </div>
          @endforelse
        </div>

      </div>
    </main>
  </div>
@endsection

@extends('layouts.app')

@section('title', 'Admin Login - MarketLink')

@section('no-navbar', '1')

@section('content')
<div class="admin-login-wrapper">
    <div class="admin-login-left">
      <i class="fas fa-shield-alt"></i>
      <h2>Admin Portal</h2>
      <p class="mt-3">Authorized personnel only. Please ensure you are on a secure connection before proceeding.</p>
    </div>
    
    <div class="admin-login-right">
      <div class="admin-login-form">
        <h3 class="mb-4 fw-bold">Admin Login</h3>
        <form action="/admin-login" method="POST">
          @csrf
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" placeholder="admin@marketlink.com" required>
            @error('email')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
          </div>
          <button type="submit" class="btn btn-success w-100 py-2">Secure Login</button>
        </form>
        <div class="text-center mt-5 text-muted small">
          &copy; 2026 MarketLink Admin. All rights reserved.
        </div>
      </div>
    </div>
  </div>
@endsection

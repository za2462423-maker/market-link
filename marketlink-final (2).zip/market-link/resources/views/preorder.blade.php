@extends('layouts.app')

@section('title', 'Pre-Order - MarketLink')

@section('no-navbar', '1')

@section('content')
<!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-success" href="/"><i class="fas fa-leaf me-2"></i>MarketLink</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Place Your Pre-Order</h2>
        </div>

        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step completed">
                <div class="step-icon"><i class="fas fa-check"></i></div>
                <span>Cart</span>
            </div>
            <div class="step-line bg-success"></div>
            <div class="step active" id="step2-indicator">
                <div class="step-icon">2</div>
                <span>Pre-Order Details</span>
            </div>
            <div class="step-line"></div>
            <div class="step" id="step3-indicator">
                <div class="step-icon">3</div>
                <span>My Orders</span>
            </div>
        </div>

        <div class="row" id="main-content">
            <!-- Left: Form -->
            <div class="col-lg-7 mb-4">
                <form id="preorder-form" action="/preorder" method="POST" class="card border-0 shadow-sm p-4">
                    @csrf
                    <input type="hidden" name="items_json" id="items-json" value="[]">

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Customer Information</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="{{ auth()->user()->name }}" readonly title="From your profile">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" value="{{ auth()->user()->phone }}" readonly title="From your profile">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="{{ auth()->user()->email }}" readonly title="From your profile">
                        </div>
                    </div>

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Pickup Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-12">
                            <label class="form-label">Select Pickup Market</label>
                            <select class="form-select @error('market') is-invalid @enderror" name="market">
                                <option value="" selected disabled>Choose a market...</option>
                                <option value="Downtown Farmers Market" {{ old('market') === 'Downtown Farmers Market' ? 'selected' : '' }}>Downtown Farmers Market</option>
                                <option value="Westside Weekend Market" {{ old('market') === 'Westside Weekend Market' ? 'selected' : '' }}>Westside Weekend Market</option>
                                <option value="Northgate Market" {{ old('market') === 'Northgate Market' ? 'selected' : '' }}>Northgate Market</option>
                                <option value="Eastside Market" {{ old('market') === 'Eastside Market' ? 'selected' : '' }}>Eastside Market</option>
                            </select>
                            @error('market')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Pickup Date *</label>
                            <input type="date" class="form-control @error('pickup_date') is-invalid @enderror" id="pickup-date" name="pickup_date" value="{{ old('pickup_date') }}" required>
                            @error('pickup_date')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Time Slot</label>
                            <select class="form-select @error('pickup_slot') is-invalid @enderror" name="pickup_slot">
                                <option value="" selected disabled>Choose time...</option>
                                <option value="8:00 AM - 9:00 AM" {{ old('pickup_slot') === '8:00 AM - 9:00 AM' ? 'selected' : '' }}>8:00 AM - 9:00 AM</option>
                                <option value="9:00 AM - 10:00 AM" {{ old('pickup_slot') === '9:00 AM - 10:00 AM' ? 'selected' : '' }}>9:00 AM - 10:00 AM</option>
                                <option value="10:00 AM - 11:00 AM" {{ old('pickup_slot') === '10:00 AM - 11:00 AM' ? 'selected' : '' }}>10:00 AM - 11:00 AM</option>
                                <option value="11:00 AM - 12:00 PM" {{ old('pickup_slot') === '11:00 AM - 12:00 PM' ? 'selected' : '' }}>11:00 AM - 12:00 PM</option>
                            </select>
                            @error('pickup_slot')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Notes (Optional)</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="e.g., I will send my brother to pick up.">{{ old('notes') }}</textarea>
                        </div>
                    </div>

                    <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
                        <i class="fas fa-wallet fs-4 me-3"></i>
                        <div>
                            <strong>Payment Notice:</strong> Payment will be made in person at the pickup location directly to the farmer. No online payment required.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 fw-bold" id="place-order-btn">Place Pre-Order</button>
                </form>
            </div>

            <!-- Right: Summary -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm sticky-top" style="top: 90px;">
                    <div class="card-body p-4 bg-light rounded">
                        <h4 class="fw-bold mb-4">Order Summary</h4>

                        <div id="order-items-list" class="mb-4">
                            <!-- Items from your real cart -->
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span class="fw-medium" id="summary-subtotal">Rs 0</span>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total to Pay at Pickup</span>
                            <span class="fw-bold fs-4 text-success" id="summary-total">Rs 0</span>
                        </div>

                        <div class="p-3 bg-white border rounded">
                            <h6 class="fw-bold mb-2"><i class="fas fa-box me-2 text-success"></i>Pre-Order Info</h6>
                            <ul class="list-unstyled small text-muted mb-0">
                                <li class="mb-1">&bull; Items from different stalls become separate orders.</li>
                                <li class="mb-1">&bull; Bring order ID to the market.</li>
                                <li>&bull; Pay directly at each farmer's stall.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
        // Set min date for date picker to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('pickup-date').setAttribute('min', today);

        // Render REAL cart items (from localStorage cart)
        const cart = (window.getCart && window.getCart()) || [];
        const list = document.getElementById('order-items-list');
        const fmtRs = (n) => 'Rs ' + (parseFloat(n) || 0).toLocaleString('en-PK', {maximumFractionDigits: 0});
        if (!cart.length) {
            list.innerHTML = '<div class="text-center py-4"><i class="fas fa-basket-shopping fa-2x text-muted mb-2"></i>' +
                '<p class="text-muted mb-2">Your cart is empty.</p>' +
                '<a href="/products" class="btn btn-sm btn-success">Browse Products</a></div>';
            document.getElementById('place-order-btn').disabled = true;
        } else {
            let total = 0;
            cart.forEach(item => {
                const sub = (parseFloat(item.price) || 0) * (item.quantity || 0);
                total += sub;
                const div = document.createElement('div');
                div.className = 'd-flex justify-content-between mb-3 border-bottom pb-2';
                div.innerHTML =
                    '<div><h6 class="mb-0 fw-bold">' + (item.quantity || 0) + 'x ' + item.name + '</h6></div>' +
                    '<span class="fw-medium">' + fmtRs(sub) + '</span>';
                list.appendChild(div);
            });
            document.getElementById('summary-subtotal').textContent = fmtRs(total);
            document.getElementById('summary-total').textContent = fmtRs(total);
        }

        // Attach cart items to the real form submit
        document.getElementById('preorder-form').addEventListener('submit', function(e) {
            const items = (window.getCart && window.getCart()) || [];
            if (!items.length) {
                e.preventDefault();
                if (window.showToast) window.showToast('Your cart is empty.', 'info');
                return;
            }
            document.getElementById('items-json').value = JSON.stringify(items.map(i => ({id: i.id, qty: i.quantity})));
        });
    </script>
@endpush

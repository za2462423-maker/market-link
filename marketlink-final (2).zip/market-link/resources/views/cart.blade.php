@extends('layouts.app')

@section('title', 'Your Cart - MarketLink')

@section('content')
<div class="container py-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cart</li>
            </ol>
        </nav>

        <div class="d-flex align-items-center mb-4">
            <h1 class="fw-bold mb-0 me-3">Your Cart</h1>
            <span class="badge bg-success rounded-pill fs-6" id="cart-item-count">3 items</span>
        </div>

        <!-- Info Box -->
        <div class="alert alert-success d-flex align-items-center mb-4" role="alert">
            <i class="fas fa-info-circle fs-4 me-3"></i>
            <div>
                <strong>No online payment required!</strong> You will pay in person at the pickup location when you collect your items.
            </div>
        </div>

        <div class="row" id="cart-container">
            <!-- Left: Cart Items -->
            <div class="col-lg-8 mb-4">
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" id="cart-table">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" class="ps-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="select-all" checked>
                                            </div>
                                        </th>
                                        <th scope="col">Product</th>
                                        <th scope="col">Price</th>
                                        <th scope="col" style="width: 150px;">Quantity</th>
                                        <th scope="col">Subtotal</th>
                                        <th scope="col" class="pe-4 text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Dynamic Rows -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <button class="btn btn-outline-danger btn-sm me-2" onclick="removeSelected()"><i class="fas fa-trash me-1"></i>Remove Selected</button>
                        <button class="btn btn-outline-secondary btn-sm" onclick="clearCart()">Clear Cart</button>
                    </div>
                    <a href="/products" class="text-success text-decoration-none fw-medium"><i class="fas fa-arrow-left me-1"></i>Continue Shopping</a>
                </div>
                
                <!-- Empty State (Hidden by default) -->
                <div id="empty-cart-state" class="text-center py-5 d-none bg-white rounded shadow-sm">
                    <i class="fas fa-shopping-basket fa-4x text-muted mb-3"></i>
                    <h3 class="fw-bold text-dark">Your cart is empty</h3>
                    <p class="text-muted mb-4">Looks like you haven't added any fresh produce yet.</p>
                    <a href="/products" class="btn btn-success btn-lg px-5">Browse Products</a>
                </div>
            </div>

            <!-- Right: Order Summary -->
            <div class="col-lg-4" id="order-summary-col">
                <div class="card border-0 shadow-sm sticky-top" style="top: 90px;">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-4">Order Summary</h4>
                        
                        <div id="summary-items" class="mb-4">
                            <!-- Populated via JS -->
                        </div>

                        <hr>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span class="fw-medium" id="summary-subtotal">Rs 0</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Service Fee</span>
                            <span class="text-success fw-bold">FREE</span>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total Estimate</span>
                            <span class="fw-bold fs-4 text-success" id="summary-total">Rs 0</span>
                        </div>

                        <div class="alert alert-warning py-2 small mb-4">
                            <i class="fas fa-exclamation-triangle me-1"></i> Items from multiple farmers will be organized as separate pre-orders.
                        </div>

                        <a href="/preorder" class="btn btn-success btn-lg w-100 fw-bold">Proceed to Pre-Order</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

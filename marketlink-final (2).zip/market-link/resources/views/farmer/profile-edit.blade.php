@extends('layouts.dashboard')

@section('title', 'Edit Stall Profile — MarketLink')

@section('content')
<div class="dashboard-layout">
    @include('includes.sidebar-farmer', ['active' => 'profile'])

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Edit Stall Profile</h1>
            <div class="d-flex align-items-center gap-2">
                <a href="/farmer-profile" class="btn btn-sm btn-outline-success"><i class="fas fa-eye me-1"></i>View Public Profile</a>
            </div>
        </div>

        <div class="dashboard-content">
            <form action="/farmer-profile" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Business info -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-store me-2 text-success"></i>Business Information</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="stall_name">Stall / Business Name *</label>
                                <input type="text" name="stall_name" id="stall_name" value="{{ old('stall_name', $user->farmer->stall_name ?? $user->name) }}" class="form-control @error('stall_name') is-invalid @enderror" required>
                                @error('stall_name')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="contact_person">Contact Person *</label>
                                <input type="text" name="contact_person" id="contact_person" value="{{ old('contact_person', $user->farmer->contact_person ?? $user->name) }}" class="form-control @error('contact_person') is-invalid @enderror" required>
                                @error('contact_person')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="phone">Contact Number *</label>
                                <input type="text" name="phone" id="phone" value="{{ old('phone', $user->phone) }}" class="form-control @error('phone') is-invalid @enderror" required>
                                @error('phone')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="email">Email Address *</label>
                                <input type="email" name="email" id="email" value="{{ old('email', $user->email) }}" class="form-control @error('email') is-invalid @enderror" required>
                                @error('email')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="address">Farm / Business Address *</label>
                                <input type="text" name="address" id="address" value="{{ old('address', $user->address) }}" class="form-control @error('address') is-invalid @enderror" required>
                                @error('address')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="description">About the Farm</label>
                                <textarea name="description" id="description" rows="3" class="form-control @error('description') is-invalid @enderror" placeholder="Tell customers about your farm, practices and specialties...">{{ old('description', $user->farmer->description ?? '') }}</textarea>
                                @error('description')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="avatar">Stall / Profile Photo</label>
                                <input type="file" name="avatar" id="avatar" accept="image/*" class="form-control @error('avatar') is-invalid @enderror">
                                @error('avatar')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Markets + days + categories -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-map-marked-alt me-2 text-success"></i>Markets & Schedule</h5>
                        @php
                            $myMarkets = old('markets', $user->farmer->markets ?? []);
                            $myDays = old('operating_days', $user->farmer->operating_days ?? []);
                            $myCats = old('categories', $user->farmer->categories ?? []);
                            $allMarkets = ['Downtown Farmers Market', 'Westside Weekend Market', 'Community Farm Stand', 'Riverside Organic Market', 'Eastside Community Market'];
                            $allDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                            $allCats = ['Vegetables', 'Fruits', 'Dairy & Eggs', 'Meat & Poultry', 'Baked Goods', 'Honey & Preserves'];
                        @endphp
                        <label class="form-label fw-medium small">Markets you sell at</label>
                        <div class="row g-2 mb-4">
                            @foreach($allMarkets as $market)
                                <div class="col-md-6">
                                    <div class="form-check border rounded p-2">
                                        <input class="form-check-input ms-1" type="checkbox" name="markets[]" value="{{ $market }}" id="mkt-{{ $loop->index }}" {{ in_array($market, $myMarkets) ? 'checked' : '' }}>
                                        <label class="form-check-label ms-2" for="mkt-{{ $loop->index }}">{{ $market }}</label>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <label class="form-label fw-medium small">Operating days</label>
                        <div class="d-flex flex-wrap gap-2 mb-4">
                            @foreach($allDays as $day)
                                <div class="m-0">
                                    <input class="btn-check" type="checkbox" name="operating_days[]" value="{{ $day }}" id="day-{{ $day }}" autocomplete="off" {{ in_array($day, $myDays) ? 'checked' : '' }}>
                                    <label class="btn btn-outline-success btn-sm" for="day-{{ $day }}">{{ $day }}</label>
                                </div>
                            @endforeach
                        </div>

                        <label class="form-label fw-medium small">Product categories</label>
                        <div class="d-flex flex-wrap gap-3">
                            @foreach($allCats as $cat)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="categories[]" value="{{ $cat }}" id="cat-{{ $loop->index }}" {{ in_array($cat, $myCats) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="cat-{{ $loop->index }}">{{ $cat }}</label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- Pickup windows -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-clock me-2 text-success"></i>Pickup Time Windows</h5>
                        <p class="text-muted small mb-3">e.g. "Sat 8:00 AM - 1:00 PM". Customers can only pre-order inside these windows.</p>
                        <div id="pickupWindows">
                            @forelse(old('pickup_windows', $user->farmer->pickup_windows ?? ['']) as $window)
                                <div class="input-group mb-2 pickup-row">
                                    <span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>
                                    <input type="text" name="pickup_windows[]" value="{{ $window }}" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">
                                    <button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>
                                </div>
                            @empty
                                <div class="input-group mb-2 pickup-row">
                                    <span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>
                                    <input type="text" name="pickup_windows[]" value="" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">
                                    <button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>
                                </div>
                            @endforelse
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-success" id="addWindow"><i class="fas fa-plus me-1"></i>Add Window</button>
                    </div>
                </div>

                <!-- Map pin -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-map-pin me-2 text-success"></i>Map Pin (OpenStreetMap)</h5>
                        <p class="text-muted small mb-3">Drop your stall location so customers can find and navigate to you.</p>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="latitude">Latitude</label>
                                <input type="number" step="0.00000001" name="latitude" id="latitude" value="{{ old('latitude', $user->farmer->latitude ?? '') }}" class="form-control @error('latitude') is-invalid @enderror" placeholder="33.68440000">
                                @error('latitude')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="longitude">Longitude</label>
                                <input type="number" step="0.00000001" name="longitude" id="longitude" value="{{ old('longitude', $user->farmer->longitude ?? '') }}" class="form-control @error('longitude') is-invalid @enderror" placeholder="73.04790000">
                                @error('longitude')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2 mb-5">
                    <button type="submit" class="btn ml-btn-primary"><i class="fas fa-save me-2"></i>Save Profile</button>
                    <a href="/farmer-profile" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>

            <!-- Password -->
            <div class="card border-0 shadow-sm rounded-4 mb-5">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-key me-2 text-success"></i>Change Password</h5>
                    <form action="/farmer-password" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="current_password">Current Password</label>
                                <input type="password" name="current_password" id="current_password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password">New Password</label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password_confirmation">Confirm New</label>
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-success mt-3">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.getElementById('addWindow')?.addEventListener('click', function () {
        const wrap = document.getElementById('pickupWindows');
        const row = document.createElement('div');
        row.className = 'input-group mb-2 pickup-row';
        row.innerHTML = '<span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>' +
            '<input type="text" name="pickup_windows[]" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">' +
            '<button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>';
        wrap.appendChild(row);
    });
    document.getElementById('pickupWindows')?.addEventListener('click', function (e) {
        const btn = e.target.closest('.remove-window');
        if (btn && this.querySelectorAll('.pickup-row').length > 1) {
            btn.closest('.pickup-row').remove();
        }
    });
</script>
@endpush

@extends('layouts.app')

@section('title', 'Green Valley Farms - MarketLink')

@section('content')
<!-- Profile Header -->
    <section class="profile-header">
        <div class="profile-overlay">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-md-auto text-center text-md-start mb-3 mb-md-0">
                        @if(!empty($farmer))
                            <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ $farmer->stall_name }}" class="profile-avatar shadow">
                        @else
                            <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Farmer" class="profile-avatar shadow">
                        @endif
                    </div>
                    <div class="col-md">
                        <h1 class="fw-bold mb-1">{{ $farmer->stall_name ?? 'Green Valley Farms' }}</h1>
                        <p class="fs-5 text-light mb-2">{{ $farmer->contact_person ?? 'John Smith' }} &bull; <i class="fa-solid fa-location-dot ms-1"></i> {{ $farmer->address ?? 'Based in Westside' }}</p>
                        <div class="d-flex align-items-center mb-0 gap-3">
                            <span class="text-warning">
                                <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                                <span class="text-light ms-1">4.8 (120 reviews)</span>
                            </span>
                            <span class="badge bg-success">Organic Certified</span>
                        </div>
                    </div>
                    <div class="col-md-auto mt-3 mt-md-0 d-flex gap-2 justify-content-center">
                        @if(!empty($farmer))
                            <a href="/farmer-profile/edit" class="btn btn-warning"><i class="fas fa-pen me-2"></i>Edit Profile</a>
                            <a href="/farmer-dashboard" class="btn btn-outline-light"><i class="fas fa-chart-pie me-2"></i>Dashboard</a>
                        @else
                            <button class="btn btn-outline-light"><i class="fa-regular fa-heart me-2"></i>Favorite</button>
                            <button class="btn btn-success"><i class="fa-solid fa-basket-shopping me-2"></i>Pre-Order</button>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/farmers" class="text-success text-decoration-none">Farmers</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Green Valley Farms</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column -->
            <div class="col-lg-8">
                
                <!-- About -->
                <div class="mb-5">
                    <h3 class="fw-bold mb-3">About the Farm</h3>
                    <p class="text-muted mb-4" style="line-height: 1.8;">
                        {{ $farmer->description ?? 'Green Valley Farms has been family-owned and operated for over three generations. We are committed to sustainable agriculture and growing the most nutritious, flavorful produce possible without the use of synthetic pesticides or fertilizers. Our 50-acre farm located just outside the city allows us to bring fresh, seasonal vegetables straight from our fields to your table.' }}
                    </p>
                    <div>
                        <h6 class="fw-bold mb-2">Specialties</h6>
                        @if(!empty($farmer) && !empty($farmer->categories))
                            @foreach($farmer->categories as $cat)<span class="tag-pill">{{ $cat }}</span> @endforeach
                        @else
                            <span class="tag-pill">Heirloom Tomatoes</span>
                            <span class="tag-pill">Root Vegetables</span>
                            <span class="tag-pill">Fresh Herbs</span>
                            <span class="tag-pill">Leafy Greens</span>
                        @endif
                    </div>
                </div>

                <!-- Products -->
                <div class="mb-5">
                    <h3 class="fw-bold mb-4">Current Weekly Stock</h3>
                    <div class="mb-4">
                        <span class="cat-chip active">All</span>
                        <span class="cat-chip">Vegetables</span>
                        <span class="cat-chip">Herbs</span>
                        <span class="cat-chip">Root Veg</span>
                    </div>
                    
                    <div class="row g-4">
                        <!-- Product 1 -->
                        <div class="col-md-4 col-sm-6">
                            <div class="product-card">
                                <div class="product-img">
                                    <img src="https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=300&h=300" class="w-100 h-100 object-fit-cover" alt="Tomatoes">
                                    <span class="qty-badge">15 in stock</span>
                                    <i class="fa-regular fa-heart fav-icon"></i>
                                </div>
                                <div class="product-body">
                                    <h5 class="fw-bold mb-1">Heirloom Tomatoes</h5>
                                    <p class="text-muted small mb-2">Organic, vine-ripened</p>
                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <span class="fw-bold text-success fs-5">$4.99<small class="text-muted fs-6">/lb</small></span>
                                        <button class="btn btn-sm btn-outline-success"><i class="fa-solid fa-cart-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Product 2 -->
                        <div class="col-md-4 col-sm-6">
                            <div class="product-card">
                                <div class="product-img">
                                    <img src="https://images.unsplash.com/photo-1622383563227-04401ab4e5ea?auto=format&fit=crop&q=80&w=300&h=300" class="w-100 h-100 object-fit-cover" alt="Carrots">
                                    <span class="qty-badge">30 in stock</span>
                                    <i class="fa-regular fa-heart fav-icon"></i>
                                </div>
                                <div class="product-body">
                                    <h5 class="fw-bold mb-1">Rainbow Carrots</h5>
                                    <p class="text-muted small mb-2">Fresh bunch with tops</p>
                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <span class="fw-bold text-success fs-5">$3.50<small class="text-muted fs-6">/bunch</small></span>
                                        <button class="btn btn-sm btn-outline-success"><i class="fa-solid fa-cart-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Product 3 -->
                        <div class="col-md-4 col-sm-6">
                            <div class="product-card">
                                <div class="product-img">
                                    <img src="https://images.unsplash.com/photo-1512621843614-b4e8c116d47b?auto=format&fit=crop&q=80&w=300&h=300" class="w-100 h-100 object-fit-cover" alt="Kale">
                                    <span class="qty-badge">20 in stock</span>
                                    <i class="fa-regular fa-heart fav-icon"></i>
                                </div>
                                <div class="product-body">
                                    <h5 class="fw-bold mb-1">Dinosaur Kale</h5>
                                    <p class="text-muted small mb-2">Crisp and nutritious</p>
                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <span class="fw-bold text-success fs-5">$2.99<small class="text-muted fs-6">/bunch</small></span>
                                        <button class="btn btn-sm btn-outline-success"><i class="fa-solid fa-cart-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Reviews -->
                <div>
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h3 class="fw-bold mb-0">Customer Reviews</h3>
                        <button class="btn btn-outline-success">Write a Review</button>
                    </div>

                    <div class="row mb-4 align-items-center">
                        <div class="col-md-4 text-center border-end">
                            <div class="display-4 fw-bold">4.8</div>
                            <div class="text-warning mb-1">
                                <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                            </div>
                            <div class="text-muted small">Based on 120 reviews</div>
                        </div>
                        <div class="col-md-8 px-4">
                            <div class="d-flex align-items-center mb-2">
                                <span class="small me-2" style="width: 25px;">5 <i class="fa-solid fa-star text-warning"></i></span>
                                <div class="rating-bar flex-grow-1"><div class="rating-fill" style="width: 85%;"></div></div>
                                <span class="small ms-2 text-muted" style="width: 30px;">102</span>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <span class="small me-2" style="width: 25px;">4 <i class="fa-solid fa-star text-warning"></i></span>
                                <div class="rating-bar flex-grow-1"><div class="rating-fill" style="width: 10%;"></div></div>
                                <span class="small ms-2 text-muted" style="width: 30px;">12</span>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <span class="small me-2" style="width: 25px;">3 <i class="fa-solid fa-star text-warning"></i></span>
                                <div class="rating-bar flex-grow-1"><div class="rating-fill" style="width: 3%;"></div></div>
                                <span class="small ms-2 text-muted" style="width: 30px;">4</span>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <span class="small me-2" style="width: 25px;">2 <i class="fa-solid fa-star text-warning"></i></span>
                                <div class="rating-bar flex-grow-1"><div class="rating-fill" style="width: 1%;"></div></div>
                                <span class="small ms-2 text-muted" style="width: 30px;">1</span>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="small me-2" style="width: 25px;">1 <i class="fa-solid fa-star text-warning"></i></span>
                                <div class="rating-bar flex-grow-1"><div class="rating-fill" style="width: 1%;"></div></div>
                                <span class="small ms-2 text-muted" style="width: 30px;">1</span>
                            </div>
                        </div>
                    </div>

                    <!-- Review List -->
                    <div class="review-card">
                        <div class="d-flex justify-content-between mb-2">
                            <div class="d-flex align-items-center">
                                <img src="https://randomuser.me/api/portraits/women/65.jpg" alt="User" class="review-avatar me-3">
                                <div>
                                    <h6 class="fw-bold mb-0">Emily R.</h6>
                                    <div class="text-warning small"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                                </div>
                            </div>
                            <span class="text-muted small">Oct 12, 2026</span>
                        </div>
                        <p class="text-muted mt-2 mb-0">The heirloom tomatoes from Green Valley are incredible! I bought some last weekend at the Downtown market and made the best Caprese salad. Highly recommend!</p>
                        
                        <div class="reply-box">
                            <div class="fw-bold small mb-1"><i class="fa-solid fa-reply me-2"></i>Green Valley Farms replied:</div>
                            <p class="small text-muted mb-0">Thank you Emily! We're so glad you enjoyed them. We'll have plenty more at the market this weekend!</p>
                        </div>
                    </div>

                    <div class="review-card">
                        <div class="d-flex justify-content-between mb-2">
                            <div class="d-flex align-items-center">
                                <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="User" class="review-avatar me-3">
                                <div>
                                    <h6 class="fw-bold mb-0">David T.</h6>
                                    <div class="text-warning small"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i></div>
                                </div>
                            </div>
                            <span class="text-muted small">Sep 28, 2026</span>
                        </div>
                        <p class="text-muted mt-2 mb-0">Great quality root veggies. A bit pricy but the taste makes up for it. Will be back for more carrots.</p>
                    </div>

                </div>

            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                
                <!-- Stats Card -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <div class="row text-center g-3">
                            <div class="col-4 border-end">
                                <h4 class="fw-bold text-success mb-0">24</h4>
                                <span class="small text-muted">Products</span>
                            </div>
                            <div class="col-4 border-end">
                                <h4 class="fw-bold text-success mb-0">120</h4>
                                <span class="small text-muted">Reviews</span>
                            </div>
                            <div class="col-4">
                                <h4 class="fw-bold text-success mb-0">3</h4>
                                <span class="small text-muted">Markets</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Markets Card -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-store text-success me-2"></i>Where to find us</h5>
                        @if(!empty($farmer) && !empty($farmer->markets))
                            <ul class="list-group list-group-flush">
                                @foreach($farmer->markets as $market)
                                <li class="list-group-item px-0">
                                    <a href="/market-details" class="fw-bold text-dark text-decoration-none hover-success">{{ $market }}</a>
                                </li>
                                @endforeach
                            </ul>
                        @else
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item px-0 border-bottom-0 pb-1">
                                    <a href="/market-details" class="fw-bold text-dark text-decoration-none hover-success">Downtown Farmers Market</a>
                                </li>
                                <li class="list-group-item px-0 pt-0 text-muted small border-bottom mb-2">
                                    <i class="fa-regular fa-calendar me-1"></i> Saturday, Sunday (Stall #12)
                                </li>
                                <li class="list-group-item px-0 border-bottom-0 pb-1">
                                    <a href="/market-details" class="fw-bold text-dark text-decoration-none hover-success">Westside Community Market</a>
                                </li>
                                <li class="list-group-item px-0 pt-0 text-muted small border-bottom mb-2">
                                    <i class="fa-regular fa-calendar me-1"></i> Wednesday (Stall #4)
                                </li>
                            </ul>
                        @endif
                    </div>
                </div>

                <!-- Pickup Windows -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-box-open text-success me-2"></i>Farm Pickup Hours</h5>
                        <p class="small text-muted mb-3">Pre-order online and pick up directly at our farm.</p>
                        @if(!empty($farmer) && !empty($farmer->pickup_windows))
                            @foreach($farmer->pickup_windows as $window)
                            <div class="d-flex justify-content-between mb-2 small">
                                <span class="fw-semibold"><i class="fa-regular fa-clock text-success me-1"></i>{{ $window }}</span>
                            </div>
                            @endforeach
                        @else
                            <div class="d-flex justify-content-between mb-2 small">
                                <span class="fw-semibold">Tuesday & Thursday</span>
                                <span>3:00 PM - 6:00 PM</span>
                            </div>
                            <div class="d-flex justify-content-between small">
                                <span class="fw-semibold">Friday</span>
                                <span>10:00 AM - 2:00 PM</span>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Location & Contact -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-map-location-dot text-success me-2"></i>Location</h5>
                        <div class="small-map mb-3">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                        @if(!empty($farmer))
                            <p class="small text-muted mb-2">{{ $farmer->address }}</p>
                            @if($farmer->latitude && $farmer->longitude)
                                <p class="small mb-3"><a class="text-success text-decoration-none" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat={{ $farmer->latitude }}&mlon={{ $farmer->longitude }}#map=15/{{ $farmer->latitude }}/{{ $farmer->longitude }}"><i class="fa-solid fa-map-pin me-1"></i>View map pin ({{ $farmer->latitude }}, {{ $farmer->longitude }})</a></p>
                            @endif
                        @else
                            <p class="small text-muted mb-3">4500 Valley Road<br>Westside, State 12345</p>
                        @endif
                        <button class="btn btn-outline-success w-100 mb-2"><i class="fa-regular fa-envelope me-2"></i>Contact Farmer</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection

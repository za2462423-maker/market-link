@extends('layouts.dashboard')

@section('title', 'MarketLink - Add Product')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link active"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="/farmer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative" type="button">
            <i class="fas fa-bell"></i>
          </button>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="mb-4">
          <a href="/farmer-products" class="text-decoration-none text-muted mb-2 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Products</a>
          <h2 class="h4 mb-0 fw-bold">Add New Product</h2>
        </div>

        <form action="/farmer-products" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate id="addProductForm">
          @csrf
          <div class="row g-4">
            <!-- Left Column: Product Details -->
            <div class="col-lg-8">
              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Basic Information</h5>

                  <div class="mb-3">
                    <label for="productName" class="form-label fw-medium">Product Name *</label>
                    <input type="text" class="form-control @error('name') is-invalid @enderror" id="productName" name="name" value="{{ old('name') }}" placeholder="e.g. Fresh Red Tomatoes" required>
                    @error('name')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                    <div class="invalid-feedback">Please provide a product name.</div>
                  </div>

                  <div class="mb-3">
                    <label for="productDesc" class="form-label fw-medium">Description</label>
                    <textarea class="form-control @error('description') is-invalid @enderror" id="productDesc" name="description" rows="4" placeholder="Describe the product, how it was grown, its taste, etc.">{{ old('description') }}</textarea>
                    @error('description')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                  </div>

                  <div class="row g-3 mb-3">
                    <div class="col-md-6">
                      <label for="category" class="form-label fw-medium">Category *</label>
                      <select class="form-select @error('category') is-invalid @enderror" id="category" name="category" required>
                        <option value="" selected disabled>Select a category</option>
                        @foreach($categories as $cat)
                          <option value="{{ $cat }}" {{ old('category') === $cat ? 'selected' : '' }}>{{ $cat }}</option>
                        @endforeach
                      </select>
                      @error('category')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                      <div class="invalid-feedback">Please select a category.</div>
                    </div>
                  </div>

                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Pricing & Inventory</h5>

                  <div class="row g-3">
                    <div class="col-md-4">
                      <label for="price" class="form-label fw-medium">Price (PKR) *</label>
                      <div class="input-group">
                        <span class="input-group-text">Rs.</span>
                        <input type="number" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}" min="0" step="1" placeholder="0" required>
                        @error('price')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        <div class="invalid-feedback">Valid price required.</div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <label for="unit" class="form-label fw-medium">Per Unit *</label>
                      <select class="form-select @error('unit') is-invalid @enderror" id="unit" name="unit" required>
                        <option value="" selected disabled>Select unit</option>
                        @foreach($units as $u)
                          <option value="{{ $u }}" {{ old('unit') === $u ? 'selected' : '' }}>{{ $u }}</option>
                        @endforeach
                      </select>
                      @error('unit')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                      <div class="invalid-feedback">Please select a unit.</div>
                    </div>
                    <div class="col-md-4">
                      <label for="quantity" class="form-label fw-medium">Available Quantity *</label>
                      <input type="number" class="form-control @error('stock') is-invalid @enderror" id="quantity" name="stock" value="{{ old('stock') }}" min="0" placeholder="0" required>
                      @error('stock')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                      <div class="invalid-feedback">Quantity required.</div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Availability</h5>

                  <div class="mb-4">
                    <label class="form-label fw-medium d-block">Available at Markets</label>
                    @foreach($markets as $mkt)
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="market-{{ $loop->index }}" name="markets[]" value="{{ $mkt }}" {{ in_array($mkt, old('markets', [])) ? 'checked' : '' }}>
                        <label class="form-check-label" for="market-{{ $loop->index }}">{{ $mkt }}</label>
                      </div>
                    @endforeach
                  </div>

                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="isAvailable" name="is_available" value="1" {{ old('is_available', true) ? 'checked' : '' }}>
                    <label class="form-check-label fw-medium" for="isAvailable">List this product immediately</label>
                  </div>
                  <small class="text-muted">Pickup time windows are set on your <a href="/farmer-profile/edit" class="text-success">profile page</a>.</small>
                </div>
              </div>

            </div>

            <!-- Right Column: Media -->
            <div class="col-lg-4">

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-3">Product Image</h5>
                  <div id="uploadContent" class="border rounded-3 p-4 text-center bg-light" style="cursor:pointer;" onclick="document.getElementById('productImage').click()">
                    <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-2"></i>
                    <p class="mb-1 fw-medium">Click to upload</p>
                    <small class="text-muted">JPG, PNG or WEBP (max 2MB)</small>
                  </div>
                  <div id="imagePreviewContainer" style="display:none;" class="text-center">
                    <img id="imagePreview" src="" alt="Preview" class="img-fluid rounded-3 mb-2">
                    <button type="button" id="removeImageBtn" class="btn btn-sm btn-outline-danger">Remove</button>
                  </div>
                  <input type="file" id="productImage" name="image" accept="image/*" class="d-none">
                  @error('image')<div class="text-danger small mt-2">{{ $message }}</div>@enderror
                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4 d-grid gap-2">
                  <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-plus me-2"></i>Add Product</button>
                  <a href="/farmer-products" class="btn btn-light border">Cancel</a>
                </div>
              </div>

            </div>
          </div>
        </form>

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));

      // Form validation
      const form = document.getElementById('addProductForm');
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);

      // Image Upload Preview
      const fileInput = document.getElementById('productImage');
      const uploadContent = document.getElementById('uploadContent');
      const previewContainer = document.getElementById('imagePreviewContainer');
      const imagePreview = document.getElementById('imagePreview');
      const removeBtn = document.getElementById('removeImageBtn');

      fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function(e) {
            imagePreview.src = e.target.result;
            uploadContent.style.display = 'none';
            previewContainer.style.display = 'block';
          };
          reader.readAsDataURL(file);
        }
      });
      removeBtn.addEventListener('click', () => {
        fileInput.value = '';
        previewContainer.style.display = 'none';
        uploadContent.style.display = 'block';
      });
    });
  </script>
@endpush

@extends('layouts.dashboard')

@section('title', 'MarketLink - Farmer Dashboard')

@section('content')
<div class="dashboard-layout">
  <!-- Sidebar -->
  <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="{{ auth()->user()->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
        <div class="ml-sidebar-role">Farmer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="/farmer-dashboard" class="ml-sidebar-link active"><i class="fas fa-chart-pie"></i> Dashboard</a>
      <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
      <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
      <a href="/farmer-add-product" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
      <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
      <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
      <a href="/farmer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
      <hr class="ml-sidebar-divider">
      <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
  </aside>

  <!-- Main Content -->
  <div class="dashboard-main">
    <div class="dashboard-topbar">
      <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="d-flex align-items-center gap-3">
        <button class="btn btn-light position-relative">
          <i class="fas fa-bell"></i>
          <span
            class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle">
            <span class="visually-hidden">New alerts</span>
          </span>
        </button>
        <a href="/farmer-add-product" class="btn btn-success"><i class="fas fa-plus"></i> <span
            class="d-none d-sm-inline">Add Product</span></a>
      </div>
    </div>

    <div class="dashboard-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0 fw-bold">Dashboard Overview</h2>
        <span class="text-muted text-sm">Last updated: Today, 10:30 AM</span>
      </div>

      <!-- Stat Cards -->
      <div class="row g-4 mb-4">
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="fas fa-shopping-basket"></i></div>
            <div class="stat-title">Total Orders (This Month)</div>
            <div class="stat-value">{{ $totalOrders ?? 28 }}</div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="fas fa-clock"></i></div>
            <div class="stat-title">Pending Orders</div>
            <div class="stat-value">{{ $pendingOrders ?? 5 }}</div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-info bg-opacity-10 text-info"><i class="fas fa-box-open"></i></div>
            <div class="stat-title">Ready for Pickup</div>
            <div class="stat-value">{{ $readyOrders ?? 3 }}</div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="fas fa-wallet"></i></div>
            <div class="stat-title">Total Revenue</div>
            <div class="stat-value">PKR {{ $revenueFmt ?? '45,800' }}</div>
          </div>
        </div>
      </div>

      <div class="row g-4 mb-4">
        <!-- Main Area (Chart & Orders) -->
        <div class="col-lg-8">
          <!-- Weekly Sales Chart -->
          <div class="chart-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h3 class="card-header-title">Weekly Sales (PKR)</h3>
              <select class="form-select form-select-sm w-auto">
                <option>This Week</option>
                <option>Last Week</option>
              </select>
            </div>
            <div class="css-chart">
              <div class="css-bar-container">
                <div class="css-bar" style="height: 40%;">
                  <div class="css-bar-tooltip">2,400</div>
                </div>
                <div class="css-bar-label">Mon</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 60%;">
                  <div class="css-bar-tooltip">3,600</div>
                </div>
                <div class="css-bar-label">Tue</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 45%;">
                  <div class="css-bar-tooltip">2,700</div>
                </div>
                <div class="css-bar-label">Wed</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 80%;">
                  <div class="css-bar-tooltip">4,800</div>
                </div>
                <div class="css-bar-label">Thu</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 75%;">
                  <div class="css-bar-tooltip">4,500</div>
                </div>
                <div class="css-bar-label">Fri</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 100%;">
                  <div class="css-bar-tooltip">6,000</div>
                </div>
                <div class="css-bar-label">Sat</div>
              </div>
              <div class="css-bar-container">
                <div class="css-bar" style="height: 90%;">
                  <div class="css-bar-tooltip">5,400</div>
                </div>
                <div class="css-bar-label">Sun</div>
              </div>
            </div>
          </div>

          <!-- Recent Orders -->
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
              <h3 class="card-header-title">Recent Orders</h3>
              <a href="/farmer-orders" class="btn btn-sm btn-outline-success">View All</a>
            </div>
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Products</th>
                    <th>Pickup Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><span class="fw-medium">#ORD-1045</span></td>
                    <td>Ali Khan</td>
                    <td>Tomatoes (2kg), Onions...</td>
                    <td>Oct 24, 10:00 AM</td>
                    <td><span class="badge bg-warning text-dark">Pending</span></td>
                    <td>
                      <button class="btn btn-sm btn-success" title="Accept"><i class="fas fa-check"></i></button>
                      <button class="btn btn-sm btn-danger" title="Decline"><i class="fas fa-times"></i></button>
                    </td>
                  </tr>
                  <tr>
                    <td><span class="fw-medium">#ORD-1044</span></td>
                    <td>Sara Ahmed</td>
                    <td>Fresh Milk (3L)</td>
                    <td>Oct 24, 11:30 AM</td>
                    <td><span class="badge bg-primary">Accepted</span></td>
                    <td>
                      <button class="btn btn-sm btn-info text-white" title="Mark Ready"><i class="fas fa-box"></i>
                        Ready</button>
                    </td>
                  </tr>
                  <tr>
                    <td><span class="fw-medium">#ORD-1043</span></td>
                    <td>Zainab R.</td>
                    <td>Organic Eggs (1 Dozen)</td>
                    <td>Oct 24, 09:00 AM</td>
                    <td><span class="badge bg-info text-dark">Ready</span></td>
                    <td>
                      <button class="btn btn-sm btn-light border" title="View"><i class="fas fa-eye"></i></button>
                    </td>
                  </tr>
                  <tr>
                    <td><span class="fw-medium">#ORD-1042</span></td>
                    <td>Usman M.</td>
                    <td>Carrots, Potatoes...</td>
                    <td>Oct 23, 04:00 PM</td>
                    <td><span class="badge bg-success">Completed</span></td>
                    <td>
                      <button class="btn btn-sm btn-light border" title="View"><i class="fas fa-eye"></i></button>
                    </td>
                  </tr>
                  <tr>
                    <td><span class="fw-medium">#ORD-1041</span></td>
                    <td>Fatima S.</td>
                    <td>Honey (500g)</td>
                    <td>Oct 23, 02:00 PM</td>
                    <td><span class="badge bg-success">Completed</span></td>
                    <td>
                      <button class="btn btn-sm btn-light border" title="View"><i class="fas fa-eye"></i></button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Right Sidebar -->
        <div class="col-lg-4">

          <!-- Quick Actions -->
          <div class="card border-0 shadow-sm rounded-3 mb-4">
            <div class="card-header bg-white border-bottom p-3">
              <h3 class="card-header-title">Quick Actions</h3>
            </div>
            <div class="card-body p-0">
              <div class="list-group list-group-flush rounded-bottom">
                <a href="/farmer-add-product"
                  class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3"><i class="fas fa-plus"></i>
                  </div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Add New Product</h6>
                    <small class="text-muted">List a new item for sale</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
                <a href="/farmer-orders"
                  class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3"><i
                      class="fas fa-clipboard-list"></i></div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Manage Orders</h6>
                    <small class="text-muted">Review and process orders</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
                <a href="/farmer-products"
                  class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-warning bg-opacity-10 text-warning rounded-circle p-2 me-3"><i
                      class="fas fa-boxes"></i></div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Update Inventory</h6>
                    <small class="text-muted">Adjust stock levels and prices</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
              </div>
            </div>
          </div>

          <!-- Stock Alerts -->
          <div class="card border-0 shadow-sm rounded-3 mb-4">
            <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
              <h3 class="card-header-title">Stock Alerts</h3>
              <span class="badge bg-danger rounded-pill">2</span>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush rounded-bottom">
                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                  <div class="d-flex align-items-center gap-3">
                    <img src="https://picsum.photos/50/50?random=101" class="product-img-sm" alt="Tomatoes">
                    <div>
                      <h6 class="mb-0">Fresh Tomatoes</h6>
                      <small class="text-muted">Only 2 kg left</small>
                    </div>
                  </div>
                  <span class="badge bg-warning text-dark">Low Stock</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                  <div class="d-flex align-items-center gap-3">
                    <img src="https://picsum.photos/50/50?random=102" class="product-img-sm" alt="Cabbage">
                    <div>
                      <h6 class="mb-0">Organic Cabbage</h6>
                      <small class="text-muted">0 heads left</small>
                    </div>
                  </div>
                  <span class="badge bg-danger">Out of Stock</span>
                </li>
                <li class="list-group-item py-2 text-center bg-light">
                  <a href="/farmer-products" class="text-decoration-none text-success small fw-semibold">Manage
                    Inventory</a>
                </li>
              </ul>
            </div>
          </div>

          <!-- Best Selling Products -->
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-header bg-white border-bottom p-3">
              <h3 class="card-header-title">Top Products</h3>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush rounded-bottom">
                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                  <div class="d-flex align-items-center gap-3">
                    <div class="fw-bold text-muted">1</div>
                    <img src="https://picsum.photos/50/50?random=103" class="product-img-sm" alt="Potatoes">
                    <div>
                      <h6 class="mb-0">Red Potatoes</h6>
                      <small class="text-success">PKR 12,500 total</small>
                    </div>
                  </div>
                  <div class="text-end">
                    <span class="fw-bold d-block">125</span>
                    <small class="text-muted">kg sold</small>
                  </div>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                  <div class="d-flex align-items-center gap-3">
                    <div class="fw-bold text-muted">2</div>
                    <img src="https://picsum.photos/50/50?random=104" class="product-img-sm" alt="Milk">
                    <div>
                      <h6 class="mb-0">Fresh Cow Milk</h6>
                      <small class="text-success">PKR 9,600 total</small>
                    </div>
                  </div>
                  <div class="text-end">
                    <span class="fw-bold d-block">48</span>
                    <small class="text-muted">L sold</small>
                  </div>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                  <div class="d-flex align-items-center gap-3">
                    <div class="fw-bold text-muted">3</div>
                    <img src="https://picsum.photos/50/50?random=105" class="product-img-sm" alt="Eggs">
                    <div>
                      <h6 class="mb-0">Organic Eggs</h6>
                      <small class="text-success">PKR 7,200 total</small>
                    </div>
                  </div>
                  <div class="text-end">
                    <span class="fw-bold d-block">30</span>
                    <small class="text-muted">dz sold</small>
                  </div>
                </li>
              </ul>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>
@endsection

@push('scripts')
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');

    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.add('show');
    });

    sidebarClose.addEventListener('click', () => {
      sidebar.classList.remove('show');
    });
  });
</script>
@endpush

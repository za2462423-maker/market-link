@extends('layouts.dashboard')

@section('title', 'MarketLink - Farmer Products')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link active"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="/farmer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative" type="button">
            <i class="fas fa-bell"></i>
          </button>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <h2 class="h4 mb-0 fw-bold">Products & Inventory</h2>
          <a href="/farmer-add-product" class="btn btn-success"><i class="fas fa-plus"></i> Add New Product</a>
        </div>

        <div class="stats-bar">
          <div class="stat-item">
            <span class="stat-label">Total Products</span>
            <span class="stat-value">{{ $statTotal ?? 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-success">In Stock</span>
            <span class="stat-value text-success">{{ $statIn ?? 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-warning">Low Stock</span>
            <span class="stat-value text-warning">{{ $statLow ?? 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-danger">Out of Stock</span>
            <span class="stat-value text-danger">{{ $statOut ?? 0 }}</span>
          </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3">
          <div class="card-body border-bottom p-3">
            <form method="GET" action="/farmer-products" class="row g-3">
              <div class="col-md-4">
                <div class="input-group">
                  <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                  <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Search products..." value="{{ $fSearch ?? '' }}">
                </div>
              </div>
              <div class="col-md-3">
                <select class="form-select" name="category" onchange="this.form.submit()">
                  <option value="">All Categories</option>
                  @foreach($categories as $cat)
                    <option value="{{ $cat }}" {{ ($fCategory ?? '') === $cat ? 'selected' : '' }}>{{ $cat }}</option>
                  @endforeach
                </select>
              </div>
              <div class="col-md-3">
                <select class="form-select" name="status" id="status-filter" onchange="this.form.submit()">
                  <option value="">All Statuses</option>
                  <option value="in">In Stock</option>
                  <option value="low">Low Stock</option>
                  <option value="out">Out of Stock</option>
                </select>
              </div>
              <div class="col-md-2">
                <a href="/farmer-products" class="btn btn-outline-secondary w-100">Reset</a>
              </div>
            </form>
          </div>

          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th scope="col" class="ps-4">#</th>
                  <th scope="col">Product</th>
                  <th scope="col">Category</th>
                  <th scope="col">Price</th>
                  <th scope="col">Stock</th>
                  <th scope="col">Status</th>
                  <th scope="col" class="text-end pe-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                @forelse($products ?? [] as $p)
                <tr class="{{ $p->stockState() === 'low' ? 'low-stock-row' : ($p->stockState() === 'out' ? 'out-stock-row' : '') }}">
                  <td class="ps-4 text-muted">{{ $loop->iteration }}</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="{{ $p->imageUrl() }}" class="product-img" alt="Product" width="50" height="50">
                      <span class="fw-medium">{{ $p->name }}</span>
                    </div>
                  </td>
                  <td>{{ $p->category }}</td>
                  <td>PKR {{ number_format($p->price, 0) }} / {{ $p->unit }}</td>
                  <td>
                    @if($p->stock <= 0)
                      <span class="fw-bold text-danger">0</span> {{ $p->unit }}
                    @elseif($p->stock < 5)
                      <span class="fw-bold text-warning">{{ $p->stock }}</span> {{ $p->unit }}
                    @else
                      <span class="fw-medium">{{ $p->stock }}</span> {{ $p->unit }}
                    @endif
                  </td>
                  <td>
                    <form action="/farmer-products/{{ $p->id }}/toggle" method="POST" class="d-inline">
                      @csrf
                      <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" {{ $p->is_available && $p->stock > 0 ? 'checked' : '' }} onchange="this.form.submit()" title="Toggle availability">
                        <label class="form-check-label small {{ $p->is_available && $p->stock > 0 ? 'text-success' : 'text-muted' }}">{{ $p->is_available && $p->stock > 0 ? 'Available' : 'Sold Out' }}</label>
                      </div>
                    </form>
                  </td>
                  <td class="text-end pe-4">
                    <a href="/farmer-products/{{ $p->id }}/edit" class="btn btn-sm btn-light border text-primary me-1" title="Edit"><i class="fas fa-pen"></i></a>
                    <form action="/farmer-products/{{ $p->id }}" method="POST" class="d-inline" onsubmit="return confirm('Delete {{ addslashes($p->name) }}? This cannot be undone.')">
                      @csrf
                      @method('DELETE')
                      <button type="submit" class="btn btn-sm btn-light border text-danger" title="Delete"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
                @empty
                <tr>
                  <td colspan="7" class="text-center py-5 text-muted">
                    <i class="fas fa-box-open fa-2x mb-3 d-block"></i>
                    No products yet. <a href="/farmer-add-product" class="text-success fw-medium">Add your first product</a>
                  </td>
                </tr>
                @endforelse
              </tbody>
            </table>
          </div>

          <div class="card-footer bg-white border-top p-3">
            <span class="text-muted small">Showing {{ $productsCount ?? 0 }} product(s)</span>
          </div>
        </div>

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));

      var sf = document.getElementById('status-filter');
      if (sf) sf.value = new URLSearchParams(window.location.search).get('status') || '';
    });
  </script>
@endpush

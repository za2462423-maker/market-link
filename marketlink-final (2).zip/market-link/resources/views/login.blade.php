@extends('layouts.app')

@section('title', 'Login — MarketLink')

@section('content')
<div class="container-fluid p-0">
        <div class="row g-0 auth-split-layout">
            <!-- Left Branding Panel -->
            <div class="col-lg-5 d-none d-lg-flex auth-panel-brand flex-column justify-content-center align-items-center p-5 text-center position-relative">
                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" style="background: url('https://images.unsplash.com/photo-1542838132-92c53300491e?w=800') center/cover;"></div>

                <div class="position-relative z-1">
                    <a href="/" class="text-white text-decoration-none d-inline-block mb-4">
                        <h1 class="display-4 fw-bold"><i class="fas fa-seedling me-2"></i>MarketLink</h1>
                    </a>
                    <h3 class="fw-light mb-3">Freshness delivered to your local market.</h3>
                    <p class="text-white-50 px-4">Sign in to your account to pre-order seasonal produce, support local farmers, and manage your favorites.</p>
                </div>

                <div class="position-absolute bottom-0 start-0 w-100 p-4 text-center z-1">
                    <p class="small text-white-50 mb-0">&copy; 2026 MarketLink. All rights reserved.</p>
                </div>
            </div>

            <!-- Right Form Panel -->
            <div class="col-lg-7 d-flex align-items-center justify-content-center p-4 p-md-5">
                <div class="w-100" style="max-width: 450px;">

                    <!-- Mobile Brand Header -->
                    <div class="text-center d-lg-none mb-4">
                        <a href="/" class="text-decoration-none d-inline-block">
                            <h2 class="fw-bold ml-text-green"><i class="fas fa-seedling me-2"></i>MarketLink</h2>
                        </a>
                    </div>

                    <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                        <div class="mb-4">
                            <h3 class="fw-bold mb-1">Welcome Back!</h3>
                            <p class="text-muted small">Please enter your details to sign in.</p>
                        </div>

                        <form action="/login" method="POST">
                            @csrf
                            <div class="mb-3">
                                <label for="email" class="form-label fw-medium small">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="far fa-envelope text-muted"></i></span>
                                    <input type="email" name="email" value="{{ old('email') }}" class="form-control bg-light border-start-0 ps-0 @error('email') is-invalid @enderror" id="email" placeholder="name@example.com" required>
                                </div>
                                @error('email')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label fw-medium small">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                                    <input type="password" name="password" class="form-control bg-light border-start-0 ps-0 border-end-0 @error('password') is-invalid @enderror" id="password" placeholder="••••••••" required>
                                    <button class="btn btn-light border border-start-0 text-muted" type="button" data-toggle-password="password"><i class="far fa-eye"></i></button>
                                </div>
                                @error('password')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="rememberMe" {{ old('remember') ? 'checked' : '' }}>
                                    <label class="form-check-label small text-muted" for="rememberMe">Remember me</label>
                                </div>
                                <a href="#" class="small text-success text-decoration-none fw-medium">Forgot password?</a>
                            </div>

                            <button type="submit" class="btn ml-btn-primary w-100 py-2 mb-4">Sign In</button>

                            <div class="position-relative mb-4 text-center">
                                <hr class="text-muted">
                                <span class="position-absolute top-50 start-50 translate-middle bg-white px-3 small text-muted">Or continue with</span>
                            </div>

                            <div class="row g-2 mb-4">
                                <div class="col-6">
                                    <button type="button" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2">
                                        <i class="fab fa-google text-danger"></i> Google
                                    </button>
                                </div>
                                <div class="col-6">
                                    <button type="button" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2">
                                        <i class="fab fa-facebook-f text-primary"></i> Facebook
                                    </button>
                                </div>
                            </div>

                            <p class="text-center small text-muted mb-0">Don't have an account? <a href="/register" class="text-success text-decoration-none fw-bold">Sign Up</a></p>
                            <p class="text-center small text-muted mt-3 mb-0 border-top pt-3"><a href="/farmer-login" class="text-secondary text-decoration-none">Are you a farmer? Log in here</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

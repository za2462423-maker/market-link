@extends('layouts.app')

@section('title', 'Product Details - MarketLink')

@section('content')
<!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none">Products</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none">Vegetables</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Organic Tomatoes</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Section -->
    <div class="container py-5">
        <div class="row mb-5">
            <!-- Left: Images -->
            <div class="col-md-7 mb-4 mb-md-0">
                <div class="main-img-container mb-3 shadow-sm" id="img-container">
                    <img src="https://picsum.photos/800/600?random=1" id="main-product-image" class="main-img" alt="Product Image">
                </div>
                <div class="row g-2">
                    <div class="col-4">
                        <img src="https://picsum.photos/800/600?random=1" class="img-fluid rounded thumbnail active" onclick="changeImage(this)" alt="Thumb 1">
                    </div>
                    <div class="col-4">
                        <img src="https://picsum.photos/800/600?random=2" class="img-fluid rounded thumbnail" onclick="changeImage(this)" alt="Thumb 2">
                    </div>
                    <div class="col-4">
                        <img src="https://picsum.photos/800/600?random=3" class="img-fluid rounded thumbnail" onclick="changeImage(this)" alt="Thumb 3">
                    </div>
                </div>
            </div>

            <!-- Right: Details -->
            <div class="col-md-5">
                <span class="badge bg-success mb-2 px-3 py-2">Vegetables</span>
                <h1 class="fw-bold mb-2">Organic Heirloom Tomatoes</h1>
                
                <div class="d-flex align-items-center mb-3">
                    <div class="text-warning me-2">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#reviews-tab" class="text-muted text-decoration-none small" onclick="document.getElementById('nav-reviews-tab').click()">(24 Reviews)</a>
                </div>

                <div class="d-flex align-items-center mb-4 p-3 bg-light rounded border">
                    <img src="https://picsum.photos/50/50?random=farmer" class="rounded-circle me-3" alt="Farmer">
                    <div>
                        <p class="mb-0 fw-bold"><a href="/farmer-profile" class="text-dark text-decoration-none">Green Acres Farm</a></p>
                        <span class="badge bg-secondary">Downtown Market</span>
                    </div>
                </div>

                <div class="mb-3">
                    <span class="display-5 fw-bold text-success">Rs 350</span>
                    <span class="text-muted fs-5">/ kg</span>
                </div>
                
                <p class="text-success small fw-bold mb-4"><i class="fas fa-check-circle me-1"></i> In Stock (50 kg available)</p>

                <p class="text-muted mb-4">Our heirloom tomatoes are organically grown without any synthetic pesticides. Hand-picked at peak ripeness for maximum flavor. Perfect for fresh salads, sandwiches, or making your own pasta sauce.</p>

                <div class="d-flex align-items-center mb-4">
                    <div class="input-group me-3" style="width: 130px;">
                        <button class="btn btn-outline-secondary" type="button" id="btn-minus">-</button>
                        <input type="number" class="form-control text-center" id="qty-input" value="1" min="1" max="50">
                        <button class="btn btn-outline-secondary" type="button" id="btn-plus">+</button>
                    </div>
                </div>

                <div class="d-grid gap-2 d-md-flex mb-4">
                    <button class="btn btn-success btn-lg flex-grow-1" id="pdp-add-cart"><i class="fas fa-shopping-cart me-2"></i>Add to Cart</button>
                    <button class="btn btn-outline-danger btn-lg px-4" id="fav-btn" onclick="toggleFav()"><i class="far fa-heart"></i></button>
                </div>

                <div class="card bg-light border-0">
                    <div class="card-body">
                        <div class="d-flex">
                            <i class="fas fa-store text-success fs-3 me-3 mt-1"></i>
                            <div>
                                <h6 class="fw-bold mb-1">Available for pickup at Downtown Market</h6>
                                <p class="text-muted small mb-0">Saturday: 8:00 AM - 1:00 PM</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="row mb-5">
            <div class="col-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active text-success fw-bold" id="nav-desc-tab" data-bs-toggle="tab" data-bs-target="#nav-desc" type="button" role="tab">Description</button>
                        <button class="nav-link text-dark fw-bold" id="nav-pickup-tab" data-bs-toggle="tab" data-bs-target="#nav-pickup" type="button" role="tab">Pickup Info</button>
                        <button class="nav-link text-dark fw-bold" id="nav-reviews-tab" data-bs-toggle="tab" data-bs-target="#nav-reviews" type="button" role="tab">Reviews (24)</button>
                    </div>
                </nav>
                <div class="tab-content p-4 border border-top-0 rounded-bottom bg-white" id="nav-tabContent">
                    <!-- Description -->
                    <div class="tab-pane fade show active" id="nav-desc" role="tabpanel">
                        <h5 class="fw-bold">Product Information</h5>
                        <p>These heirloom tomatoes are grown using sustainable, organic farming practices. We do not use any synthetic fertilizers or pesticides, ensuring you get the cleanest and most natural product possible.</p>
                        <ul>
                            <li>100% Organic certified</li>
                            <li>Harvested within 24 hours of market</li>
                            <li>Varieties include: Brandywine, Cherokee Purple, and Yellow Pear</li>
                        </ul>
                    </div>
                    
                    <!-- Pickup Info -->
                    <div class="tab-pane fade" id="nav-pickup" role="tabpanel">
                        <h5 class="fw-bold mb-3">Pickup Locations & Times</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Market Name</th>
                                        <th>Address</th>
                                        <th>Days</th>
                                        <th>Hours</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Downtown Market</td>
                                        <td>123 Main St, City Plaza</td>
                                        <td>Saturday</td>
                                        <td>8:00 AM - 1:00 PM</td>
                                    </tr>
                                    <tr>
                                        <td>Westside Weekend</td>
                                        <td>456 West Ave, Park</td>
                                        <td>Sunday</td>
                                        <td>9:00 AM - 2:00 PM</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Reviews -->
                    <div class="tab-pane fade" id="nav-reviews" role="tabpanel">
                        <div class="row">
                            <!-- Summary -->
                            <div class="col-md-4 text-center mb-4 border-end">
                                <h1 class="display-3 fw-bold text-dark mb-0">4.8</h1>
                                <div class="text-warning fs-5 mb-2">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                                </div>
                                <p class="text-muted">Based on 24 reviews</p>
                                
                                <div class="text-start px-4">
                                    <div class="d-flex align-items-center small mb-1">
                                        <span class="me-2">5 <i class="fas fa-star text-warning"></i></span>
                                        <div class="progress flex-grow-1" style="height: 8px;">
                                            <div class="progress-bar bg-warning" style="width: 80%"></div>
                                        </div>
                                    </div>
                                    <!-- Add more bars if needed -->
                                </div>
                            </div>
                            
                            <!-- Review List & Form -->
                            <div class="col-md-8">
                                <h5 class="fw-bold mb-4">Write a Review</h5>
                                <form class="mb-5 bg-light p-4 rounded">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Your Rating</label>
                                        <div class="star-rating fs-4" id="review-stars">
                                            <i class="fas fa-star" data-rating="5"></i>
                                            <i class="fas fa-star" data-rating="4"></i>
                                            <i class="fas fa-star" data-rating="3"></i>
                                            <i class="fas fa-star" data-rating="2"></i>
                                            <i class="fas fa-star" data-rating="1"></i>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Your Review</label>
                                        <textarea class="form-control" rows="3" placeholder="What did you like about this product?"></textarea>
                                    </div>
                                    <button type="button" class="btn btn-success">Submit Review</button>
                                </form>

                                <h5 class="fw-bold mb-4">Customer Reviews</h5>
                                <!-- Review Item -->
                                <div class="d-flex mb-4 border-bottom pb-3">
                                    <img src="https://ui-avatars.com/api/?name=Sarah+J" class="rounded-circle me-3" style="width: 50px; height: 50px;" alt="Sarah">
                                    <div>
                                        <h6 class="fw-bold mb-1">Sarah Jenkins <span class="text-muted fw-normal small ms-2">2 days ago</span></h6>
                                        <div class="text-warning small mb-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                        </div>
                                        <p class="mb-0">Absolutely delicious! The flavor is incredible compared to store-bought tomatoes. Made the best caprese salad.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <h3 class="fw-bold mb-4">Similar Products</h3>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <img src="https://picsum.photos/300/200?random=11" class="card-img-top" alt="Cherry Tomatoes">
                    <div class="card-body">
                        <h6 class="card-title fw-bold"><a href="#" class="text-dark text-decoration-none">Cherry Tomatoes</a></h6>
                        <p class="text-success mb-0">$3.50 / pint</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <img src="https://picsum.photos/300/200?random=12" class="card-img-top" alt="Bell Peppers">
                    <div class="card-body">
                        <h6 class="card-title fw-bold"><a href="#" class="text-dark text-decoration-none">Organic Bell Peppers</a></h6>
                        <p class="text-success mb-0">$2.99 / lb</p>
                    </div>
                </div>
            </div>
            <!-- More related items -->
        </div>
    </div>

    <!-- Toast -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="cartToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Added to cart!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    /* Real catalogue injection (same block as products page). */
    (function () {
      var realProducts = [
        @foreach($products ?? [] as $p)
        {id: {{ $p->id }}, name: {!! json_encode($p->name) !!}, farmerId: {{ $p->farmer_id ?? 0 }}, farmer: {!! json_encode($p->farmer ? $p->farmer->displayName() : 'Local Farm') !!}, price: {{ $p->price }}, unit: {!! json_encode($p->unit) !!}, category: {!! json_encode($p->category) !!}, rating: {{ $p->rating ?? 0 }}, stock: {{ $p->stock }}, image: {!! json_encode($p->imageUrl()) !!}, description: {!! json_encode($p->description ?? '') !!}, markets: {!! json_encode($p->markets ?? []) !!}},
        @endforeach
      ];
      if (window.ML) window.ML.products = realProducts;
    })();
    /* Render ?id= product into the page (works with live data + preview mocks). */
    (function () {
      var id = new URLSearchParams(window.location.search).get('id');
      if (!id) return;
      var ML = window.ML || {};
      var list = ML.products || [];
      var p = null;
      for (var i = 0; i < list.length; i++) {
        if (String(list[i].id) === String(id)) { p = list[i]; break; }
      }
      if (!p) return;
      var farmer = p.farmer;
      if (!farmer && ML.farmers) {
        for (var j = 0; j < ML.farmers.length; j++) {
          if (String(ML.farmers[j].id) === String(p.farmerId)) { farmer = ML.farmers[j].stallName; break; }
        }
      }
      farmer = farmer || 'Local Farm';
      var setText = function (sel, txt) {
        var el = document.querySelector(sel);
        if (el) el.textContent = txt;
      };
      var priceTxt = 'Rs ' + Number(p.price).toLocaleString('en-PK');
      setText('.breadcrumb .breadcrumb-item:nth-child(3)', p.category || 'Products');
      setText('.breadcrumb .breadcrumb-item.active', p.name);
      setText('.col-md-5 > .badge', p.category || 'Product');
      setText('.col-md-5 h1', p.name);
      setText('.display-5', priceTxt);
      setText('.display-5 + .text-muted', '/ ' + (p.unit || 'item'));
      var stockEl = document.querySelector('.col-md-5 p.text-success.small, .col-md-5 p.text-success');
      if (stockEl && p.stock != null) {
        stockEl.textContent = p.stock > 0 ? 'In Stock (' + p.stock + ' ' + (p.unit || '') + ' available)' : 'Out of stock';
      }
      if (p.description) setText('.col-md-5 > p.text-muted.mb-4', p.description);
      var main = document.getElementById('main-product-image');
      if (main && p.image) main.src = p.image;
      document.querySelectorAll('.thumbnail').forEach(function (t) { if (p.image) t.src = p.image; });
      var farmerBox = document.querySelector('.col-md-5 .bg-light.rounded.border');
      if (farmerBox) {
        var fl = farmerBox.querySelector('a');
        if (fl) fl.textContent = farmer;
        var mb = farmerBox.querySelector('.badge');
        if (mb && p.markets && p.markets.length) mb.textContent = p.markets[0];
      }
      var qty = document.getElementById('qty-input');
      if (qty && p.stock != null) { qty.max = Math.max(p.stock, 1); if (parseInt(qty.value, 10) > p.stock) qty.value = Math.max(p.stock, 1); }
      var add = document.getElementById('pdp-add-cart');
      if (add) {
        add.setAttribute('data-id', p.id);
        if (p.stock != null && p.stock <= 0) { add.disabled = true; add.innerHTML = 'Out of Stock'; }
      }
      var fav = document.getElementById('fav-btn');
      if (fav) fav.setAttribute('data-product-id', p.id);
    })();
</script>
@endpush

@extends('layouts.app')

@section('title', 'Downtown Farmers Market - MarketLink')

@section('content')
<!-- Market Hero -->
    <section class="market-hero">
        <div class="market-hero-overlay text-white">
            <div class="container">
                <div class="d-flex flex-wrap justify-content-between align-items-end">
                    <div>
                        <div class="badge bg-success mb-2">Open Today</div>
                        <h1 class="display-4 fw-bold mb-2">Downtown Farmers Market</h1>
                        <p class="fs-5 mb-0"><i class="fa-solid fa-location-dot me-2"></i>100 Main St, Downtown &nbsp;&bull;&nbsp; <i class="fa-regular fa-clock me-2"></i>Sat-Sun 8am-2pm</p>
                    </div>
                    <div class="text-end mt-3 mt-md-0">
                        <div class="bg-white text-dark rounded px-3 py-2 d-inline-block">
                            <div class="text-warning fs-5">
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star-half-stroke"></i>
                            </div>
                            <span class="fw-bold">4.8</span> (124 reviews)
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 mb-4 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/markets" class="text-success text-decoration-none">Markets</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Downtown Farmers Market</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column (Tabs Content) -->
            <div class="col-lg-8">
                <!-- Tabs Nav -->
                <ul class="nav nav-tabs mb-4 border-bottom-0 shadow-sm rounded-top" id="marketTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab">Overview</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="farmers-tab" data-bs-toggle="tab" data-bs-target="#farmers" type="button" role="tab">Farmers (45)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="products-tab" data-bs-toggle="tab" data-bs-target="#products" type="button" role="tab">Products</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="location-tab" data-bs-toggle="tab" data-bs-target="#location" type="button" role="tab">Location</button>
                    </li>
                </ul>

                <!-- Tabs Content -->
                <div class="tab-content" id="marketTabsContent">
                    
                    <!-- Overview Tab -->
                    <div class="tab-pane fade show active" id="overview" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3 class="fw-bold mb-0">About This Market</h3>
                            <button class="btn btn-outline-danger"><i class="fa-regular fa-heart me-2"></i>Save to Favorites</button>
                        </div>
                        <p class="lead text-muted mb-4">The Downtown Farmers Market is the city's oldest and most vibrant outdoor market, operating since 1985. We feature over 45 local farmers, artisans, and food vendors every weekend rain or shine.</p>
                        
                        <div class="info-grid mb-5">
                            <div class="info-item">
                                <i class="fa-solid fa-map-location-dot"></i>
                                <h5 class="fw-bold">Address</h5>
                                <p class="mb-0 text-muted">100 Main St, City Center<br>Downtown, State 12345</p>
                            </div>
                            <div class="info-item">
                                <i class="fa-regular fa-clock"></i>
                                <h5 class="fw-bold">Hours</h5>
                                <p class="mb-0 text-muted">Saturday: 8:00 AM - 2:00 PM<br>Sunday: 9:00 AM - 1:00 PM</p>
                            </div>
                            <div class="info-item">
                                <i class="fa-solid fa-phone"></i>
                                <h5 class="fw-bold">Contact</h5>
                                <p class="mb-0 text-muted">(555) 123-4567<br>hello@downtownmarket.org</p>
                            </div>
                            <div class="info-item">
                                <i class="fa-solid fa-calendar-days"></i>
                                <h5 class="fw-bold">Season</h5>
                                <p class="mb-0 text-muted">Year-round<br>Special holiday hours apply</p>
                            </div>
                        </div>

                        <h4 class="fw-bold mb-3">Amenities</h4>
                        <ul class="list-unstyled row g-2 text-muted">
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>Wheelchair Accessible</li>
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>Restrooms Available</li>
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>Street Parking</li>
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>SNAP/EBT Accepted</li>
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>Live Music</li>
                            <li class="col-md-6"><i class="fa-solid fa-check text-success me-2"></i>Pet Friendly (Leashed)</li>
                        </ul>
                    </div>

                    <!-- Farmers Tab -->
                    <div class="tab-pane fade" id="farmers" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3 class="fw-bold mb-0">Meet the Farmers</h3>
                            <div class="input-group w-50">
                                <span class="input-group-text bg-white"><i class="fa-solid fa-search"></i></span>
                                <input type="text" class="form-control border-start-0" placeholder="Search farmers...">
                            </div>
                        </div>
                        
                        <div class="row g-4">
                            <!-- Farmer 1 -->
                            <div class="col-md-6">
                                <div class="farmer-card">
                                    <div class="farmer-img-container">
                                        <img src="https://images.unsplash.com/photo-1595856752766-3d601d36d8d9?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                                        <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Avatar" class="farmer-avatar">
                                    </div>
                                    <div class="farmer-body">
                                        <h4 class="fw-bold mb-1 mt-2">Green Valley Farms</h4>
                                        <p class="text-muted mb-2">John Smith • Stall #12</p>
                                        <div class="text-warning mb-3">
                                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                                            <span class="text-muted ms-1">(45)</span>
                                        </div>
                                        <p class="small text-muted mb-3">Organic vegetables, seasonal fruits, and herbs.</p>
                                        <div class="mt-auto">
                                            <a href="/farmer-profile" class="btn btn-outline-success w-100">View Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Farmer 2 -->
                            <div class="col-md-6">
                                <div class="farmer-card">
                                    <div class="farmer-img-container">
                                        <img src="https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                                        <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Avatar" class="farmer-avatar">
                                    </div>
                                    <div class="farmer-body">
                                        <h4 class="fw-bold mb-1 mt-2">Sunny Dairy</h4>
                                        <p class="text-muted mb-2">Sarah Jenkins • Stall #05</p>
                                        <div class="text-warning mb-3">
                                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                            <span class="text-muted ms-1">(89)</span>
                                        </div>
                                        <p class="small text-muted mb-3">Artisan cheeses, fresh milk, and farm eggs.</p>
                                        <div class="mt-auto">
                                            <a href="/farmer-profile" class="btn btn-outline-success w-100">View Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Products Tab -->
                    <div class="tab-pane fade" id="products" role="tabpanel">
                        <h3 class="fw-bold mb-4">Available Products</h3>
                        
                        <div class="mb-4">
                            <span class="cat-chip active">All Products</span>
                            <span class="cat-chip">Vegetables</span>
                            <span class="cat-chip">Fruits</span>
                            <span class="cat-chip">Dairy</span>
                            <span class="cat-chip">Baked Goods</span>
                            <span class="cat-chip">Honey & Jams</span>
                        </div>
                        
                        <div class="row g-4">
                            <!-- Product 1 -->
                            <div class="col-md-4">
                                <div class="product-card">
                                    <img src="https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&q=80&w=300&h=300" class="product-img" alt="Potatoes">
                                    <div class="product-body">
                                        <h5 class="fw-bold mb-1">Organic Potatoes</h5>
                                        <p class="text-muted small mb-2">Green Valley Farms</p>
                                        <div class="d-flex justify-content-between align-items-center mt-auto">
                                            <span class="fw-bold text-success fs-5">$4.50<small class="text-muted fs-6">/lb</small></span>
                                            <button class="btn btn-sm btn-success rounded-circle"><i class="fa-solid fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Product 2 -->
                            <div class="col-md-4">
                                <div class="product-card">
                                    <img src="https://images.unsplash.com/photo-1529312266912-b33cfce2eefd?auto=format&fit=crop&q=80&w=300&h=300" class="product-img" alt="Strawberries">
                                    <div class="product-body">
                                        <h5 class="fw-bold mb-1">Fresh Strawberries</h5>
                                        <p class="text-muted small mb-2">Berry Good Co.</p>
                                        <div class="d-flex justify-content-between align-items-center mt-auto">
                                            <span class="fw-bold text-success fs-5">$6.00<small class="text-muted fs-6">/box</small></span>
                                            <button class="btn btn-sm btn-success rounded-circle"><i class="fa-solid fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Product 3 -->
                            <div class="col-md-4">
                                <div class="product-card">
                                    <img src="https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?auto=format&fit=crop&q=80&w=300&h=300" class="product-img" alt="Cheddar Cheese">
                                    <div class="product-body">
                                        <h5 class="fw-bold mb-1">Aged Cheddar</h5>
                                        <p class="text-muted small mb-2">Sunny Dairy</p>
                                        <div class="d-flex justify-content-between align-items-center mt-auto">
                                            <span class="fw-bold text-success fs-5">$8.50<small class="text-muted fs-6">/block</small></span>
                                            <button class="btn btn-sm btn-success rounded-circle"><i class="fa-solid fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Location Tab -->
                    <div class="tab-pane fade" id="location" role="tabpanel">
                        <h3 class="fw-bold mb-4">Location & Directions</h3>
                        <div class="location-map">
                            <i class="fa-solid fa-location-dot position-relative" style="z-index: 2; transform: translateY(-10px);"></i>
                            <div class="pin-shadow"></div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5 class="fw-bold">Downtown Farmers Market</h5>
                                <p class="text-muted mb-0">100 Main St, City Center<br>Located in the plaza across from City Hall.</p>
                            </div>
                            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                                <a href="https://maps.google.com/?q=40.7128,-74.0060" target="_blank" class="btn btn-success"><i class="fa-solid fa-diamond-turn-right me-2"></i>Get Directions</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Right Column (Aside) -->
            <div class="col-lg-4">
                <!-- Market Hours -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-regular fa-clock text-success me-2"></i>Market Hours</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <span>Monday - Friday</span>
                                <span class="text-danger fw-semibold">Closed</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <span class="fw-bold">Saturday</span>
                                <span class="text-success fw-bold">8:00 AM - 2:00 PM</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <span>Sunday</span>
                                <span>9:00 AM - 1:00 PM</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Upcoming Events -->
                <div class="card border-0 shadow-sm mb-4 bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-calendar-star me-2"></i>Upcoming Events</h5>
                        <div class="mb-3 border-bottom border-light pb-2">
                            <div class="fw-bold">Fall Harvest Festival</div>
                            <div class="small text-white-50">Oct 15 • 10:00 AM - 2:00 PM</div>
                            <div class="small mt-1">Live music, pumpkin carving, and cider tasting!</div>
                        </div>
                        <div>
                            <div class="fw-bold">Chef Demo: Cooking with Squashes</div>
                            <div class="small text-white-50">Oct 22 • 11:00 AM</div>
                            <div class="small mt-1">Learn new recipes from Chef Maria.</div>
                        </div>
                    </div>
                </div>

                <!-- Share -->
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h6 class="fw-bold mb-3">Share this Market</h6>
                        <div class="d-flex justify-content-center gap-2">
                            <button class="btn btn-outline-primary"><i class="fa-brands fa-facebook-f"></i></button>
                            <button class="btn btn-outline-info"><i class="fa-brands fa-twitter"></i></button>
                            <button class="btn btn-outline-success"><i class="fa-brands fa-whatsapp"></i></button>
                            <button class="btn btn-outline-secondary"><i class="fa-solid fa-link"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

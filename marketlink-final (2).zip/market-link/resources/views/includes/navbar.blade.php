<!-- Navbar -->
<nav class="navbar navbar-expand-lg ml-navbar sticky-top">
    <div class="container">
        <a class="navbar-brand ml-brand" href="/">
            <i class="fas fa-seedling"></i> MarketLink
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link {{ request()->is('/') ? 'active' : '' }}" href="/">Home</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->is('markets*') ? 'active' : '' }}" href="/markets">Markets</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->is('farmers*') ? 'active' : '' }}" href="/farmers">Farmers</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->is('products*') ? 'active' : '' }}" href="/products">Products</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->is('about') ? 'active' : '' }}" href="/about">About</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->is('contact') ? 'active' : '' }}" href="/contact">Contact</a></li>
            </ul>
            <div class="d-flex align-items-center gap-2">
                <a href="/cart" class="ml-cart-btn" id="cartNavBtn" aria-label="Shopping Cart">
                    <i class="fas fa-shopping-basket"></i>
                    <span class="ml-cart-badge" id="cartBadge">0</span>
                </a>
                @guest
                    <div class="ml-auth-links">
                        <a href="/login" class="btn-login">Login</a>
                        <a href="/register" class="btn-register">Sign Up</a>
                    </div>
                @endguest
                @auth
                    <div class="dropdown">
                        <button class="btn ml-user-chip dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="{{ auth()->user()->avatarUrl() }}" alt="avatar" class="ml-user-chip-img">
                            <span class="d-none d-md-inline">{{ Str::limit(auth()->user()->displayName(), 14) }}</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li><h6 class="dropdown-header">{{ auth()->user()->displayName() }}<br><small class="text-muted">{{ ucfirst(auth()->user()->role) }}</small></h6></li>
                            <li><a class="dropdown-item" href="{{ auth()->user()->dashboardUrl() }}"><i class="fas fa-th-large me-2 text-success"></i>Dashboard</a></li>
                            @if(auth()->user()->isCustomer())
                                <li><a class="dropdown-item" href="/customer-profile"><i class="fas fa-user me-2 text-success"></i>My Profile</a></li>
                            @elseif(auth()->user()->isFarmer())
                                <li><a class="dropdown-item" href="/farmer-profile"><i class="fas fa-store me-2 text-success"></i>My Stall Profile</a></li>
                            @endif
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="/logout" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                @endauth
            </div>
        </div>
    </div>
</nav>

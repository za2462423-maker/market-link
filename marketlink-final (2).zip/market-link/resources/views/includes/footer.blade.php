<!-- Footer -->
<footer class="ml-footer">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="ml-footer-brand"><i class="fas fa-seedling"></i> MarketLink</div>
                <p>Connecting local farmers with customers. Fresh, seasonal, community-grown.</p>
                <div class="ml-social-links">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <h6>Quick Links</h6>
                <ul class="ml-footer-links list-unstyled">
                    <li><a href="/markets">Markets</a></li>
                    <li><a href="/farmers">Farmers</a></li>
                    <li><a href="/products">Products</a></li>
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/contact">Contact</a></li>
                    <li><a href="/sitemap">Sitemap</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <h6>For Farmers</h6>
                <ul class="ml-footer-links list-unstyled">
                    <li><a href="/farmer-login">Farmer Login</a></li>
                    <li><a href="/farmer-register">Join as Farmer</a></li>
                    <li><a href="/farmer-dashboard">Dashboard</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6">
                <h6>Newsletter</h6>
                <p class="ml-footer-text">Get updates on fresh arrivals and market events.</p>
                <form class="ml-newsletter-form" id="footerNewsletter" action="/newsletter" method="POST">
                    @csrf
                    <div class="input-group">
                        <input type="email" class="form-control" name="newsletter_email" placeholder="Your email" aria-label="Email address" required>
                        <button class="btn ml-btn-primary" type="submit">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
        <hr class="ml-footer-divider my-4">
        <div class="row align-items-center">
            <div class="col-md-6"><p class="ml-footer-copy mb-0">&copy; {{ date('Y') }} MarketLink. All rights reserved.</p></div>
            <div class="col-md-6 text-md-end"><p class="ml-footer-copy mb-0">Made with <i class="fas fa-heart text-danger"></i> for local farmers</p></div>
        </div>
    </div>
</footer>

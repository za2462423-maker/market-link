{{-- Customer sidebar. Pass ['active' => 'dashboard|orders|favorites|reviews|profile'] --}}
<aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="ml-sidebar-avatar">
        <div>
            <div class="ml-sidebar-username">{{ auth()->user()->name }}</div>
            <div class="ml-sidebar-role">Customer</div>
        </div>
    </div>
    <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link {{ ($active ?? '') === 'dashboard' ? 'active' : '' }}"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/customer-orders" class="ml-sidebar-link {{ ($active ?? '') === 'orders' ? 'active' : '' }}"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/customer-favorites" class="ml-sidebar-link {{ ($active ?? '') === 'favorites' ? 'active' : '' }}"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-profile" class="ml-sidebar-link {{ ($active ?? '') === 'profile' ? 'active' : '' }}"><i class="fas fa-user"></i> Profile</a>
        <a href="/customer-reviews" class="ml-sidebar-link {{ ($active ?? '') === 'reviews' ? 'active' : '' }}"><i class="fas fa-star"></i> Reviews</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
</aside>
<div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

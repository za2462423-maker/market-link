{{-- Farmer sidebar. Pass ['active' => 'dashboard|profile|products|add-product|orders|reviews'] --}}
<aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
    <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
        <div>
            <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
            <div class="ml-sidebar-role">Farmer</div>
        </div>
    </div>
    <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link {{ ($active ?? '') === 'dashboard' ? 'active' : '' }}"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link {{ ($active ?? '') === 'profile' ? 'active' : '' }}"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link {{ ($active ?? '') === 'products' ? 'active' : '' }}"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link {{ ($active ?? '') === 'add-product' ? 'active' : '' }}"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-orders" class="ml-sidebar-link {{ ($active ?? '') === 'orders' ? 'active' : '' }}"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/farmer-reviews" class="ml-sidebar-link {{ ($active ?? '') === 'reviews' ? 'active' : '' }}"><i class="fas fa-star"></i> Reviews</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
</aside>
<div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

@extends('layouts.app')

@section('title', 'Site Directory - MarketLink')


@section('content')
<header class="header-bg">
    <div class="container">
        <div class="d-flex align-items-center mb-2">
            <i class="fas fa-leaf fa-2x me-3"></i>
            <h1 class="mb-0 fw-bold">MarketLink</h1>
        </div>
        <p class="lead mb-0">Project Site Directory & Reference</p>
    </div>
</header>

<div class="container pb-5">
    <div class="row">

        <!-- Public Pages -->
        <div class="col-md-6">
            <div class="card directory-card">
                <div class="card-header text-success">
                    <i class="fas fa-globe me-2"></i>Public Pages
                </div>
                <div class="list-group list-group-flush">
                    <a href="/" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-home"></i></div>
                        <div class="page-details">
                            <h5>Home Page</h5>
                            <p>Landing page with hero, features, featured markets and products.</p>
                            <span class="page-filename">/ </span>
                        </div>
                    </a>
                    <a href="/markets" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-store"></i></div>
                        <div class="page-details">
                            <h5>Markets Directory</h5>
                            <p>List of all farmers markets with map view and filtering.</p>
                            <span class="page-filename">/markets</span>
                        </div>
                    </a>
                    <a href="/farmers" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-tractor"></i></div>
                        <div class="page-details">
                            <h5>Farmers Directory</h5>
                            <p>Browse verified local farmers, their specialties and ratings.</p>
                            <span class="page-filename">/farmers</span>
                        </div>
                    </a>
                    <a href="/products" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-carrot"></i></div>
                        <div class="page-details">
                            <h5>Products Catalog</h5>
                            <p>Browse all available fresh produce, dairy, and goods with filters.</p>
                            <span class="page-filename">/products</span>
                        </div>
                    </a>
                    <a href="/ai-assistant" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-robot"></i></div>
                        <div class="page-details">
                            <h5>AI Assistant</h5>
                            <p>Full-page chatbot interface for natural language queries.</p>
                            <span class="page-filename">/ai-assistant</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Customer Dashboard -->
        <div class="col-md-6">
            <div class="card directory-card">
                <div class="card-header text-success">
                    <i class="fas fa-user me-2"></i>Customer Pages
                </div>
                <div class="list-group list-group-flush">
                    <a href="/login" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-sign-in-alt"></i></div>
                        <div class="page-details">
                            <h5>Login</h5>
                            <p>User authentication page.</p>
                            <span class="page-filename">/login</span>
                        </div>
                    </a>
                    <a href="/register" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-user-plus"></i></div>
                        <div class="page-details">
                            <h5>Sign Up</h5>
                            <p>New user registration.</p>
                            <span class="page-filename">/signup</span>
                        </div>
                    </a>
                    <a href="/customer-dashboard" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-tachometer-alt"></i></div>
                        <div class="page-details">
                            <h5>Customer Dashboard</h5>
                            <p>User profile, recent orders, saved farmers, and settings.</p>
                            <span class="page-filename">/customer-dashboard</span>
                        </div>
                    </a>
                    <a href="/cart" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-shopping-cart"></i></div>
                        <div class="page-details">
                            <h5>Shopping Cart</h5>
                            <p>Review items, adjust quantities, and proceed to checkout.</p>
                            <span class="page-filename">/cart</span>
                        </div>
                    </a>
                    <a href="/cart" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-credit-card"></i></div>
                        <div class="page-details">
                            <h5>Checkout</h5>
                            <p>Payment details and order confirmation.</p>
                            <span class="page-filename">/checkout</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Farmer Pages -->
        <div class="col-md-6">
            <div class="card directory-card">
                <div class="card-header text-success">
                    <i class="fas fa-seedling me-2"></i>Farmer Pages
                </div>
                <div class="list-group list-group-flush">
                    <a href="/farmer-dashboard" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-chart-line"></i></div>
                        <div class="page-details">
                            <h5>Farmer Dashboard</h5>
                            <p>Sales overview, upcoming markets, and recent orders.</p>
                            <span class="page-filename">/farmer-dashboard</span>
                        </div>
                    </a>
                    <a href="/farmer-products" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-box-open"></i></div>
                        <div class="page-details">
                            <h5>Inventory Management</h5>
                            <p>Add, edit, or remove products and update stock levels.</p>
                            <span class="page-filename">/farmer-products</span>
                        </div>
                    </a>
                    <a href="/farmer-profile" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-id-card"></i></div>
                        <div class="page-details">
                            <h5>Public Profile View</h5>
                            <p>How customers see the farmer's store and details.</p>
                            <span class="page-filename">/farmer-profile</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Admin Pages -->
        <div class="col-md-6">
            <div class="card directory-card">
                <div class="card-header text-success">
                    <i class="fas fa-cog me-2"></i>Admin Pages
                </div>
                <div class="list-group list-group-flush">
                    <a href="/admin-dashboard" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-shield-alt"></i></div>
                        <div class="page-details">
                            <h5>Admin Dashboard</h5>
                            <p>Platform metrics, pending approvals, and system status.</p>
                            <span class="page-filename">/admin-dashboard</span>
                        </div>
                    </a>
                    <a href="/admin-customers" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-users-cog"></i></div>
                        <div class="page-details">
                            <h5>User Management</h5>
                            <p>Manage farmers, customers, and their account statuses.</p>
                            <span class="page-filename">/admin-users</span>
                        </div>
                    </a>
                    <a href="/admin-markets" class="page-link-item">
                        <div class="page-icon"><i class="fas fa-map-marked-alt"></i></div>
                        <div class="page-details">
                            <h5>Market Management</h5>
                            <p>Add or edit market locations, schedules, and details.</p>
                            <span class="page-filename">/admin-markets</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection

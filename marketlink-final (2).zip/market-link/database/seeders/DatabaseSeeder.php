<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\Farmer;
use App\Models\Favorite;
use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Demo accounts (see README for credentials):
     *  admin@marketlink.com / Admin@123
     *  farmer@marketlink.com / Farmer@123
     *  customer@marketlink.com / Customer@123
     */
    public function run(): void
    {
        // Admin
        User::updateOrCreate(
            ['email' => 'admin@marketlink.com'],
            [
                'name' => 'Super Admin',
                'password' => 'Admin@123',
                'role' => User::ROLE_ADMIN,
                'phone' => '0300 0000001',
                'address' => 'MarketLink HQ, Islamabad',
            ]
        );

        // Demo farmer
        $farmerUser = User::updateOrCreate(
            ['email' => 'farmer@marketlink.com'],
            [
                'name' => 'Ahmed Khan',
                'password' => 'Farmer@123',
                'role' => User::ROLE_FARMER,
                'phone' => '0300 1111111',
                'address' => 'Chak Shahzad Farms, Islamabad',
            ]
        );

        Farmer::updateOrCreate(
            ['user_id' => $farmerUser->id],
            [
                'stall_name' => 'Green Valley Farms',
                'contact_person' => 'Ahmed Khan',
                'phone' => '0300 1111111',
                'address' => 'Chak Shahzad Farms, Islamabad',
                'description' => 'Family-run organic farm growing seasonal vegetables and fresh herbs since 2015.',
                'markets' => ['Downtown Farmers Market', 'Westside Weekend Market'],
                'operating_days' => ['Sat', 'Sun'],
                'pickup_windows' => ['Sat 8:00 AM - 1:00 PM', 'Sun 9:00 AM - 12:00 PM'],
                'categories' => ['Vegetables', 'Fruits'],
                'latitude' => 33.6844,
                'longitude' => 73.0479,
            ]
        );

        // Demo customer
        $customerUser = User::updateOrCreate(
            ['email' => 'customer@marketlink.com'],
            [
                'name' => 'Sara Ahmed',
                'password' => 'Customer@123',
                'role' => User::ROLE_CUSTOMER,
                'phone' => '0300 2222222',
                'address' => 'House 12, Street 5, F-10/2, Islamabad',
            ]
        );

        Customer::updateOrCreate(
            ['user_id' => $customerUser->id],
            [
                'phone' => '0300 2222222',
                'address' => 'House 12, Street 5, F-10/2, Islamabad',
                'city' => 'Islamabad',
            ]
        );

        // Demo products for the demo farmer's stall.
        $demoProducts = [
            ['Fresh Red Tomatoes', 'Vegetables', 150, 'kg', 45, 'tomato', 4.5],
            ['Organic Onions', 'Vegetables', 120, 'kg', 30, 'onion', 4.4],
            ['Fresh Carrots', 'Vegetables', 80, 'kg', 4, 'carrot', 4.6],
            ['Sweet Apples', 'Fruits', 300, 'kg', 20, 'apple', 4.8],
            ['Farm Fresh Milk', 'Dairy', 200, 'litre', 15, 'milk', 4.9],
            ['Free Range Eggs', 'Dairy', 350, 'dozen', 12, 'eggs', 4.7],
            ['Desi Ghee', 'Dairy', 850, 'kg', 8, 'ghee', 5.0],
            ['Whole Wheat Flour', 'Baked Goods', 180, 'kg', 25, 'flour', 4.3],
            ['Fresh Spinach', 'Vegetables', 60, 'bunch', 0, 'spinach', 4.2],
            ['Seasonal Mangoes', 'Fruits', 400, 'kg', 18, 'mango', 4.9],
        ];
        foreach ($demoProducts as [$name, $cat, $price, $unit, $stock, $img, $rating]) {
            Product::updateOrCreate(
                ['farmer_id' => $farmerUser->id, 'name' => $name],
                [
                    'category' => $cat, 'price' => $price, 'unit' => $unit,
                    'stock' => $stock, 'rating' => $rating,
                    'description' => 'Fresh ' . strtolower($name) . ' from Green Valley Farms. Grown without harmful chemicals.',
                    'image' => 'https://picsum.photos/300/300?' . $img,
                    'markets' => ['Downtown Farmers Market'],
                    'is_available' => $stock > 0,
                ]
            );
        }

        // Demo orders (seeded once — never duplicated on re-seed).
        if (Order::count() === 0) {
            $p1 = Product::where('farmer_id', $farmerUser->id)->where('name', 'Fresh Red Tomatoes')->first();
            $p2 = Product::where('farmer_id', $farmerUser->id)->where('name', 'Farm Fresh Milk')->first();
            $p3 = Product::where('farmer_id', $farmerUser->id)->where('name', 'Free Range Eggs')->first();

            $o1 = Order::create([
                'customer_id' => $customerUser->id, 'farmer_id' => $farmerUser->id,
                'market' => 'Downtown Farmers Market', 'pickup_date' => now()->subDays(6)->toDateString(),
                'pickup_slot' => '9:00 AM - 12:00 PM', 'status' => Order::ST_COMPLETED,
                'subtotal' => 2 * 150 + 1 * 200, 'notes' => 'Please pack tomatoes separately.',
            ]);
            $o1->items()->createMany([
                ['product_id' => $p1->id, 'name' => $p1->name, 'unit' => $p1->unit, 'qty' => 2, 'price' => 150],
                ['product_id' => $p2->id, 'name' => $p2->name, 'unit' => $p2->unit, 'qty' => 1, 'price' => 200],
            ]);

            $o2 = Order::create([
                'customer_id' => $customerUser->id, 'farmer_id' => $farmerUser->id,
                'market' => 'Downtown Farmers Market', 'pickup_date' => now()->addDay()->toDateString(),
                'pickup_slot' => '8:00 AM - 9:00 AM', 'status' => Order::ST_READY,
                'subtotal' => 1 * 350,
            ]);
            $o2->items()->create(['product_id' => $p3->id, 'name' => $p3->name, 'unit' => $p3->unit, 'qty' => 1, 'price' => 350]);

            $o3 = Order::create([
                'customer_id' => $customerUser->id, 'farmer_id' => $farmerUser->id,
                'market' => 'Westside Weekend Market', 'pickup_date' => now()->addDays(2)->toDateString(),
                'pickup_slot' => '10:00 AM - 11:00 AM', 'status' => Order::ST_PENDING,
                'subtotal' => 3 * 80,
            ]);
            $p4 = Product::where('farmer_id', $farmerUser->id)->where('name', 'Fresh Carrots')->first();
            $o3->items()->create(['product_id' => $p4->id, 'name' => $p4->name, 'unit' => $p4->unit, 'qty' => 3, 'price' => 80]);

            Review::firstOrCreate(
                ['order_id' => $o1->id],
                ['customer_id' => $customerUser->id, 'farmer_id' => $farmerUser->id, 'rating' => 5,
                 'comment' => 'Excellent quality! Tomatoes were fresh and milk was pure. Highly recommended.']
            );
        }

        // Demo favorites for the demo customer.
        foreach (['Sweet Apples', 'Desi Ghee'] as $favName) {
            $fp = Product::where('farmer_id', $farmerUser->id)->where('name', $favName)->first();
            if ($fp) {
                Favorite::firstOrCreate(['customer_id' => $customerUser->id, 'product_id' => $fp->id]);
            }
        }
    }
}

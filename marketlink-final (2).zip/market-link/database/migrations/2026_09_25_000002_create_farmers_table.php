<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * SRS Farmer Registration & Profile Management:
     * stall/business name, contact person, contact number, email, address,
     * plus markets, operating days, pickup windows, lat/lng, description.
     */
    public function up(): void
    {
        Schema::create('farmers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('stall_name', 100);
            $table->string('contact_person', 100);
            $table->string('phone', 30);
            $table->string('address', 255);
            $table->text('description')->nullable();
            $table->json('markets')->nullable();
            $table->json('operating_days')->nullable();
            $table->json('pickup_windows')->nullable();
            $table->json('categories')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->string('avatar', 255)->nullable();
            $table->boolean('is_approved')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('farmers');
    }
};

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * SRS Role-Based Access Control: users may only access
 * features relevant to their role (customer / farmer / admin).
 *
 * Usage: ->middleware('role:farmer') or ->middleware('role:customer,farmer')
 */
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (! Auth::check()) {
            return redirect()->away('/login')
                ->with('error', 'Please log in to access that page.');
        }

        $user = $request->user();

        if (! $user->is_active) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->away('/login')
                ->with('error', 'Your account has been deactivated. Please contact support.');
        }

        if ($roles && ! $user->hasRole(...$roles)) {
            return redirect()->away($user->dashboardUrl())
                ->with('error', 'You are not authorized to view that page.');
        }

        return $next($request);
    }
}

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * Logged-in users visiting guest-only pages (login / register) are sent
 * to their OWN dashboard. Uses a RELATIVE Location header so it works
 * behind any proxy, on any domain or scheme (https/http/localhost).
 */
class RedirectIfAuthenticated
{
    public function handle(Request $request, Closure $next, string ...$guards): Response
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                $user = Auth::guard($guard)->user();
                $to = ($user && method_exists($user, 'dashboardUrl')) ? $user->dashboardUrl() : '/';

                return redirect()->away($to);
            }
        }

        return $next($request);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class CustomerController extends Controller
{
    public function dashboard(): View
    {
        $user = request()->user();

        return view('customer.dashboard', [
            'ordersCount' => $user->customerOrders()->count(),
            'favoritesCount' => $user->favorites()->count(),
            'reviewsCount' => $user->reviewsGiven()->count(),
        ]);
    }

    public function orders(): View
    {
        $user = request()->user();
        $q = $user->customerOrders()->with(['farmer', 'items.product', 'review'])->latest();

        if (request()->filled('status')) {
            $q->where('status', request()->input('status'));
        }
        if (request()->filled('search')) {
            $q->where('id', request()->input('search'));
        }
        if (request()->filled('date')) {
            $q->whereDate('pickup_date', request()->input('date'));
        }

        $base = $user->customerOrders();

        return view('customer.orders', [
            'orders' => $q->get(),
            'countsAll' => (clone $base)->count(),
            'countsPending' => (clone $base)->where('status', \App\Models\Order::ST_PENDING)->count(),
            'countsConfirmed' => (clone $base)->where('status', \App\Models\Order::ST_CONFIRMED)->count(),
            'countsReady' => (clone $base)->where('status', \App\Models\Order::ST_READY)->count(),
            'countsCompleted' => (clone $base)->where('status', \App\Models\Order::ST_COMPLETED)->count(),
            'countsCancelled' => (clone $base)->where('status', \App\Models\Order::ST_CANCELLED)->count(),
            'status' => request()->input('status', ''),
            'search' => request()->input('search', ''),
            'date' => request()->input('date', ''),
        ]);
    }

    /** Single order (?id=) with items, timeline, cancel + review actions. */
    public function orderDetails(Request $request): Response
    {
        $id = $request->query('id');
        $user = $request->user();
        $isFarmer = $user->isFarmer();

        if (!$id) {
            return redirect()->away($isFarmer ? '/farmer-orders' : '/customer-orders');
        }

        $order = $isFarmer
            ? $user->farmerOrders()->with(['customer', 'items.product', 'review'])->findOrFail($id)
            : $user->customerOrders()->with(['farmer', 'items.product', 'review'])->findOrFail($id);

        return response()->view('order-details', [
            'order' => $order,
            'backUrl' => $isFarmer ? '/farmer-orders' : '/customer-orders',
            'canReview' => !$isFarmer && $order->status === \App\Models\Order::ST_COMPLETED && !$order->review,
            'canCancel' => !$isFarmer && $order->status === \App\Models\Order::ST_PENDING,
        ]);
    }

    public function favorites(): View
    {
        return view('customer.favorites', [
            'favorites' => request()->user()->favorites()->with('product.farmer')->latest()->get(),
        ]);
    }

    public function reviews(): View
    {
        return view('customer.reviews', [
            'reviews' => request()->user()->reviewsGiven()->with(['farmer', 'order'])->latest()->get(),
        ]);
    }

    /** Customer profile (view + edit on one page). */
    public function profile(): View
    {
        return view('customer.profile', [
            'user' => request()->user()->load('customer'),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email,' . $user->id,
            'address' => 'required|string|max:255',
            'city' => 'nullable|string|max:100',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $user->update([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
            'avatar' => $data['avatar'] ?? $user->avatar,
        ]);

        $user->customer()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'phone' => $data['phone'],
                'address' => $data['address'],
                'city' => $data['city'] ?? null,
            ]
        );

        return back()->with('success', 'Profile updated successfully.');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $request->user()->update(['password' => $request->input('password')]);

        return back()->with('success', 'Password changed successfully.');
    }
}

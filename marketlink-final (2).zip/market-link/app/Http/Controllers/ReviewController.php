<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Review;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    /** Customer rates a farmer after a completed pickup. */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'order_id' => 'required|exists:orders,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $order = $request->user()->customerOrders()->findOrFail($data['order_id']);

        if ($order->status !== Order::ST_COMPLETED) {
            return back()->with('error', 'You can review this order once it is completed.');
        }
        if ($order->review) {
            return back()->with('error', 'You have already reviewed this order.');
        }
        if (!$order->farmer_id) {
            return back()->with('error', 'This order has no farmer attached.');
        }

        Review::create([
            'customer_id' => $request->user()->id,
            'farmer_id' => $order->farmer_id,
            'order_id' => $order->id,
            'rating' => $data['rating'],
            'comment' => $data['comment'] ?? null,
        ]);

        return back()->with('success', 'Thank you! Your review was submitted.');
    }

    public function destroy(Request $request, $id): RedirectResponse
    {
        $review = Review::where('customer_id', $request->user()->id)->findOrFail($id);
        $review->delete();

        return back()->with('success', 'Review deleted.');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class FarmerProductController extends Controller
{
    /** Farmer's own products + live stats + filters. */
    public function index(Request $request): View
    {
        $user = $request->user();
        $all = $user->products()->latest()->get();

        $q = $user->products()->latest();
        if ($request->filled('search')) {
            $q->where('name', 'like', '%' . $request->input('search') . '%');
        }
        if ($request->filled('category')) {
            $q->where('category', $request->input('category'));
        }
        if ($request->filled('status')) {
            match ($request->input('status')) {
                'in' => $q->where('is_available', true)->where('stock', '>', 0),
                'low' => $q->where('is_available', true)->where('stock', '>', 0)->where('stock', '<', 5),
                'out' => $q->where(fn ($w) => $w->where('is_available', false)->orWhere('stock', '<=', 0)),
                default => null,
            };
        }

        $products = $q->get();

        return view('farmer.products', [
            'products' => $products,
            'productsCount' => $products->count(),
            'statTotal' => $all->count(),
            'statIn' => $all->where('is_available', true)->where('stock', '>', 0)->count(),
            'statLow' => $all->where('is_available', true)->where('stock', '>', 0)->where('stock', '<', 5)->count(),
            'statOut' => $all->filter(fn ($p) => !$p->is_available || $p->stock <= 0)->count(),
            'fSearch' => $request->input('search', ''),
            'fCategory' => $request->input('category', ''),
            'fStatus' => $request->input('status', ''),
            'categories' => Product::CATEGORIES,
        ]);
    }

    public function create(): View
    {
        return view('farmer.add-product', [
            'categories' => Product::CATEGORIES,
            'units' => Product::UNITS,
            'markets' => ['Downtown Farmers Market', 'Westside Weekend Market', 'Northgate Market', 'Eastside Market'],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:150',
            'category' => 'required|string|in:' . implode(',', Product::CATEGORIES),
            'price' => 'required|numeric|min:0|max:1000000',
            'unit' => 'required|string|in:' . implode(',', Product::UNITS),
            'stock' => 'required|integer|min:0|max:1000000',
            'description' => 'nullable|string|max:2000',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'markets' => 'nullable|array',
            'markets.*' => 'string|max:100',
            'is_available' => 'nullable|boolean',
        ]);

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }
        $data['farmer_id'] = $request->user()->id;
        $data['is_available'] = $request->boolean('is_available', true);

        Product::create($data);

        return redirect()->away('/farmer-products')->with('success', 'Product "' . $data['name'] . '" added to your stall!');
    }

    public function edit(Request $request, $id): View
    {
        return view('farmer.edit-product', [
            'product' => $request->user()->products()->findOrFail($id),
            'categories' => Product::CATEGORIES,
            'units' => Product::UNITS,
            'markets' => ['Downtown Farmers Market', 'Westside Weekend Market', 'Northgate Market', 'Eastside Market'],
        ]);
    }

    public function update(Request $request, $id): RedirectResponse
    {
        $product = $request->user()->products()->findOrFail($id);

        $data = $request->validate([
            'name' => 'required|string|max:150',
            'category' => 'required|string|in:' . implode(',', Product::CATEGORIES),
            'price' => 'required|numeric|min:0|max:1000000',
            'unit' => 'required|string|in:' . implode(',', Product::UNITS),
            'stock' => 'required|integer|min:0|max:1000000',
            'description' => 'nullable|string|max:2000',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'markets' => 'nullable|array',
            'markets.*' => 'string|max:100',
            'is_available' => 'nullable|boolean',
        ]);

        if ($request->hasFile('image')) {
            $this->deleteImageFile($product->image);
            $data['image'] = $request->file('image')->store('products', 'public');
        }
        $data['is_available'] = $request->boolean('is_available', true);

        $product->update($data);

        return redirect()->away('/farmer-products')->with('success', 'Product updated successfully.');
    }

    public function destroy(Request $request, $id): RedirectResponse
    {
        $product = $request->user()->products()->findOrFail($id);
        $this->deleteImageFile($product->image);
        $name = $product->name;
        $product->delete();

        return redirect()->away('/farmer-products')->with('success', 'Product "' . $name . '" deleted.');
    }

    public function toggle(Request $request, $id): RedirectResponse
    {
        $product = $request->user()->products()->findOrFail($id);
        $product->update(['is_available' => !$product->is_available]);

        return redirect()->away('/farmer-products')->with(
            'success',
            $product->is_available ? 'Product is now available.' : 'Product marked as sold out.'
        );
    }

    private function deleteImageFile(?string $path): void
    {
        if ($path && !str_starts_with($path, 'http')) {
            Storage::disk('public')->delete($path);
        }
    }
}

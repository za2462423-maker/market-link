<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class FarmerOrderController extends Controller
{
    public function index(Request $request): View
    {
        $q = $request->user()->farmerOrders()->with(['customer', 'items'])->latest();

        if ($request->filled('status')) {
            $q->where('status', $request->input('status'));
        }
        if ($request->filled('search')) {
            $s = $request->input('search');
            $q->where(function ($w) use ($s) {
                $w->where('id', $s)
                    ->orWhereHas('customer', fn ($c) => $c->where('name', 'like', "%{$s}%"));
            });
        }
        if ($request->filled('date')) {
            $q->whereDate('pickup_date', $request->input('date'));
        }

        $base = $request->user()->farmerOrders();

        return view('farmer.orders', [
            'orders' => $q->get(),
            'countsAll' => (clone $base)->count(),
            'countsPending' => (clone $base)->where('status', Order::ST_PENDING)->count(),
            'countsConfirmed' => (clone $base)->where('status', Order::ST_CONFIRMED)->count(),
            'countsReady' => (clone $base)->where('status', Order::ST_READY)->count(),
            'countsCompleted' => (clone $base)->where('status', Order::ST_COMPLETED)->count(),
            'countsCancelled' => (clone $base)->where('status', Order::ST_CANCELLED)->count(),
            'status' => $request->input('status', ''),
            'search' => $request->input('search', ''),
            'date' => $request->input('date', ''),
            'filters' => $request->only(['search', 'status', 'date']),
        ]);
    }

    /** Farmer moves an order along: confirm -> ready -> complete (or cancel). */
    public function updateStatus(Request $request, $id): RedirectResponse
    {
        $order = $request->user()->farmerOrders()->with('items.product')->findOrFail($id);

        $data = $request->validate([
            'status' => 'required|string|in:' . implode(',', [
                Order::ST_CONFIRMED, Order::ST_READY, Order::ST_COMPLETED, Order::ST_CANCELLED,
            ]),
        ]);

        if (in_array($order->status, [Order::ST_COMPLETED, Order::ST_CANCELLED], true)) {
            return back()->with('error', 'This order is already ' . $order->statusLabel() . '.');
        }

        if ($data['status'] === Order::ST_CANCELLED) {
            foreach ($order->items as $item) {
                if ($item->product) {
                    $item->product->increment('stock', $item->qty);
                }
            }
        }

        $order->update(['status' => $data['status']]);

        return back()->with('success', 'Order ' . $order->code() . ' marked as ' . $order->statusLabel() . '.');
    }
}

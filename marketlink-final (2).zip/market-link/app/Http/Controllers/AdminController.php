<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class AdminController extends Controller
{
    /** SRS: dashboard summarizes total farmers, customers, markets, orders. */
    public function dashboard(): View
    {
        return view('admin.dashboard', [
            'totalFarmers' => User::where('role', User::ROLE_FARMER)->count(),
            'totalCustomers' => User::where('role', User::ROLE_CUSTOMER)->count(),
            // Markets module is UI-prototype; show live zero meanwhile.
            'totalMarkets' => 0,
            'totalOrders' => Order::count(),
            'totalProducts' => Product::count(),
        ]);
    }

    public function farmers(): View
    {
        $farmers = User::where('role', User::ROLE_FARMER)->with('farmer')->withCount(['products', 'farmerOrders'])->latest()->get();

        return view('admin.farmers', [
            'farmers' => $farmers,
            'statTotal' => $farmers->count(),
            'statApproved' => $farmers->where('is_active', true)->count(),
            'statProducts' => $farmers->sum('products_count'),
            'statSuspended' => $farmers->where('is_active', false)->count(),
        ]);
    }

    public function customers(): View
    {
        $customers = User::where('role', User::ROLE_CUSTOMER)->with('customer')->withCount('customerOrders')->latest()->get();

        return view('admin.customers', [
            'customers' => $customers,
            'statTotal' => $customers->count(),
            'statActive' => $customers->where('is_active', true)->count(),
            'statInactive' => $customers->where('is_active', false)->count(),
        ]);
    }

    public function markets(): View
    {
        return view('admin.markets');
    }

    public function products(): View
    {
        return view('admin.products', [
            'products' => Product::with('farmer')->latest()->get(),
        ]);
    }

    public function orders(): View
    {
        $orders = Order::with(['customer', 'farmer', 'items'])->latest()->get();

        return view('admin.orders', [
            'orders' => $orders,
            'statTotal' => $orders->count(),
            'statPending' => $orders->where('status', Order::ST_PENDING)->count(),
            'statCompleted' => $orders->where('status', Order::ST_COMPLETED)->count(),
            'statCancelled' => $orders->where('status', Order::ST_CANCELLED)->count(),
        ]);
    }

    public function reviews(): View
    {
        return view('admin.reviews', [
            'reviews' => Review::with(['customer', 'farmer', 'order'])->latest()->get(),
        ]);
    }

    public function reports(): View
    {
        return view('admin.reports', [
            'totalFarmers' => User::where('role', User::ROLE_FARMER)->count(),
            'totalCustomers' => User::where('role', User::ROLE_CUSTOMER)->count(),
            'totalOrders' => Order::count(),
            'totalProducts' => Product::count(),
        ]);
    }

    public function toggleFarmer(User $user): RedirectResponse
    {
        abort_unless($user->isFarmer(), 404);
        $user->update(['is_active' => !$user->is_active]);

        return back()->with('success', $user->is_active ? 'Farmer activated.' : 'Farmer suspended.');
    }

    public function destroyFarmer(User $user): RedirectResponse
    {
        abort_unless($user->isFarmer(), 404);
        foreach ($user->products as $product) {
            $this->deletePublicFile($product->image);
        }
        $this->deletePublicFile($user->avatar);
        $name = $user->name;
        $user->delete();

        return back()->with('success', 'Farmer "' . $name . '" and all their products removed.');
    }

    public function toggleCustomer(User $user): RedirectResponse
    {
        abort_unless($user->isCustomer(), 404);
        $user->update(['is_active' => !$user->is_active]);

        return back()->with('success', $user->is_active ? 'Customer activated.' : 'Customer suspended.');
    }

    public function destroyCustomer(User $user): RedirectResponse
    {
        abort_unless($user->isCustomer(), 404);
        $this->deletePublicFile($user->avatar);
        $name = $user->name;
        $user->delete();

        return back()->with('success', 'Customer "' . $name . '" and all their data removed.');
    }

    private function deletePublicFile(?string $path): void
    {
        if ($path && !str_starts_with($path, 'http')) {
            Storage::disk('public')->delete($path);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PreorderController extends Controller
{
    /**
     * Place pre-order(s). Cart items arrive as JSON, are grouped per
     * farmer (one order per stall), stock is decremented.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'market' => 'nullable|string|max:150',
            'pickup_date' => 'required|date|after_or_equal:today',
            'pickup_slot' => 'nullable|string|max:100',
            'notes' => 'nullable|string|max:1000',
            'items_json' => 'required|string',
        ]);

        $items = json_decode($data['items_json'], true);
        if (!is_array($items) || count($items) === 0) {
            return back()->with('error', 'Your cart is empty. Add some products first.');
        }

        $ids = array_values(array_unique(array_filter(array_map(
            fn ($i) => is_numeric($i['id'] ?? null) ? (int) $i['id'] : null, $items
        ))));
        $dbProducts = Product::whereIn('id', $ids)->get()->keyBy('id');

        // Every cart item must exist in the live catalogue.
        foreach ($items as $i) {
            if (!isset($i['id']) || !$dbProducts->has((int) $i['id'])) {
                return back()->with('error', 'Some cart items are no longer available. Please re-add them from the Products page.');
            }
        }

        // Group items per farmer.
        $groups = [];
        foreach ($items as $i) {
            $p = $dbProducts[(int) $i['id']];
            $qty = max(1, (int) ($i['qty'] ?? $i['quantity'] ?? 1));
            if ($qty > $p->stock || !$p->is_available) {
                return back()->with('error', '"' . $p->name . '" only has ' . $p->stock . ' ' . $p->unit . ' left in stock.');
            }
            $groups[$p->farmer_id][] = ['product' => $p, 'qty' => $qty, 'price' => (float) $p->price];
        }

        $count = 0;
        foreach ($groups as $farmerId => $lines) {
            $subtotal = 0;
            foreach ($lines as $l) {
                $subtotal += $l['price'] * $l['qty'];
            }
            $order = Order::create([
                'customer_id' => $request->user()->id,
                'farmer_id' => $farmerId,
                'market' => $data['market'] ?? null,
                'pickup_date' => $data['pickup_date'],
                'pickup_slot' => $data['pickup_slot'] ?? null,
                'status' => Order::ST_PENDING,
                'subtotal' => $subtotal,
                'notes' => $data['notes'] ?? null,
            ]);
            foreach ($lines as $l) {
                $order->items()->create([
                    'product_id' => $l['product']->id,
                    'name' => $l['product']->name,
                    'unit' => $l['product']->unit,
                    'qty' => $l['qty'],
                    'price' => $l['price'],
                ]);
                $l['product']->decrement('stock', $l['qty']);
            }
            $count++;
        }

        // Tell the next page (one-time flash) to clear the browser cart.
        session()->flash('ml_cart_clear', true);

        return redirect()->away('/customer-orders')->with(
            'success',
            $count > 1 ? $count . ' pre-orders placed (one per stall)!' : 'Pre-order placed successfully!'
        );
    }

    /** Customer cancels their own pending/confirmed order; stock is restored. */
    public function cancel(Request $request, $id): RedirectResponse
    {
        $order = $request->user()->customerOrders()->with('items.product')->findOrFail($id);

        if (!$order->canBeCancelledByCustomer()) {
            return back()->with('error', 'This order can no longer be cancelled.');
        }

        foreach ($order->items as $item) {
            if ($item->product) {
                $item->product->increment('stock', $item->qty);
            }
        }
        $order->update(['status' => Order::ST_CANCELLED]);

        return back()->with('success', 'Order ' . $order->code() . ' cancelled.');
    }
}

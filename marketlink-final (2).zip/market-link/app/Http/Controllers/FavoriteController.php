<?php

namespace App\Http\Controllers;

use App\Models\Favorite;
use App\Models\Product;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class FavoriteController extends Controller
{
    /** Toggle a product in the customer's favorites (works via form + AJAX). */
    public function toggle(Request $request): Response
    {
        $data = $request->validate(['product_id' => 'required|exists:products,id']);
        $product = Product::findOrFail($data['product_id']);

        $existing = Favorite::where('customer_id', $request->user()->id)
            ->where('product_id', $product->id)
            ->first();

        if ($existing) {
            $existing->delete();
            $favorited = false;
            $message = 'Removed from favorites.';
        } else {
            Favorite::create(['customer_id' => $request->user()->id, 'product_id' => $product->id]);
            $favorited = true;
            $message = 'Added to favorites!';
        }

        if ($request->expectsJson() || $request->ajax()) {
            return response()->json([
                'favorited' => $favorited,
                'message' => $message,
                'count' => Favorite::where('customer_id', $request->user()->id)->count(),
            ]);
        }

        return redirect()->away('/customer-favorites')->with('success', $message);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Farmer;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthController extends Controller
{
    /* -------------------- Login forms -------------------- */

    public function showLogin(): View
    {
        return view('login');
    }

    public function showFarmerLogin(): View
    {
        return view('farmer.login');
    }

    public function showAdminLogin(): View
    {
        return view('admin.login');
    }

    /* -------------------- Registration forms -------------------- */

    public function showRegister(): View
    {
        return view('register');
    }

    public function showFarmerRegister(): View
    {
        return view('farmer.register');
    }

    /* -------------------- Customer registration (SRS) -------------------- */
    public function registerCustomer(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email',
            'address' => 'required|string|max:255',
            'city' => 'nullable|string|max:100',
            'password' => 'required|string|min:8|confirmed',
            'terms' => 'accepted',
        ]);

        $user = User::create([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
            'password' => $data['password'], // 'hashed' cast
            'role' => User::ROLE_CUSTOMER,
        ]);

        Customer::create([
            'user_id' => $user->id,
            'phone' => $data['phone'],
            'address' => $data['address'],
            'city' => $data['city'] ?? null,
        ]);

        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->away('/customer-dashboard')
            ->with('success', 'Welcome to MarketLink, ' . $user->name . '! Your account is ready.');
    }

    /* -------------------- Farmer registration (SRS) -------------------- */
    public function registerFarmer(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'stall_name' => 'required|string|max:100',
            'contact_person' => 'required|string|max:100',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email',
            'address' => 'required|string|max:255',
            'markets' => 'nullable|array',
            'markets.*' => 'string|max:100',
            'operating_days' => 'nullable|array',
            'operating_days.*' => 'string|max:10',
            'categories' => 'nullable|array',
            'categories.*' => 'string|max:50',
            'password' => 'required|string|min:8|confirmed',
            'terms' => 'accepted',
        ]);

        $user = User::create([
            'name' => $data['contact_person'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
            'password' => $data['password'],
            'role' => User::ROLE_FARMER,
        ]);

        Farmer::create([
            'user_id' => $user->id,
            'stall_name' => $data['stall_name'],
            'contact_person' => $data['contact_person'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'markets' => $data['markets'] ?? [],
            'operating_days' => $data['operating_days'] ?? [],
            'categories' => $data['categories'] ?? [],
        ]);

        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->away('/farmer-dashboard')
            ->with('success', 'Stall "' . $data['stall_name'] . '" created! Complete your profile to start selling.');
    }

    /* -------------------- Login (role-aware) -------------------- */

    public function loginCustomer(Request $request): RedirectResponse
    {
        return $this->attemptLogin($request, User::ROLE_CUSTOMER, 'customer');
    }

    public function loginFarmer(Request $request): RedirectResponse
    {
        return $this->attemptLogin($request, User::ROLE_FARMER, 'farmer');
    }

    public function loginAdmin(Request $request): RedirectResponse
    {
        return $this->attemptLogin($request, User::ROLE_ADMIN, 'admin');
    }

    protected function attemptLogin(Request $request, string $role, string $label): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $credentials['email'])->first();

        if (! $user || $user->role !== $role) {
            return back()->withInput($request->only('email'))->withErrors([
                'email' => "No {$label} account found with this email address.",
            ]);
        }

        if (! $user->is_active) {
            return back()->withInput($request->only('email'))->withErrors([
                'email' => 'This account has been deactivated. Please contact support.',
            ]);
        }

        if (! Auth::attempt($credentials, $request->boolean('remember'))) {
            return back()->withInput($request->only('email'))->withErrors([
                'email' => 'The provided credentials do not match our records.',
            ]);
        }

        $request->session()->regenerate();

        return redirect()->away(session()->pull('url.intended', $user->dashboardUrl()))
            ->with('success', 'Welcome back, ' . $user->displayName() . '!');
    }

    /* -------------------- Logout -------------------- */

    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->away('/')->with('success', 'You have been logged out.');
    }
}

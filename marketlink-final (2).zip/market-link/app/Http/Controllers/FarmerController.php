<?php

namespace App\Http\Controllers;

use App\Models\Farmer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class FarmerController extends Controller
{
    public function dashboard(): View
    {
        $user = request()->user();
        $revenue = (float) $user->farmerOrders()->where('status', \App\Models\Order::ST_COMPLETED)->sum('subtotal');

        return view('farmer.dashboard', [
            'productsCount' => $user->products()->count(),
            'pendingOrders' => $user->farmerOrders()->where('status', \App\Models\Order::ST_PENDING)->count(),
            'readyOrders' => $user->farmerOrders()->where('status', \App\Models\Order::ST_READY)->count(),
            'totalOrders' => $user->farmerOrders()->count(),
            'revenue' => $revenue,
            'revenueFmt' => number_format($revenue, 0),
        ]);
    }

    public function reviews(): View
    {
        $user = request()->user();

        $reviews = $user->reviewsReceived()->with(['customer', 'order'])->latest()->get();
        $dist = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
        foreach ($reviews as $r) {
            if (isset($dist[$r->rating])) $dist[$r->rating]++;
        }
        $total = $reviews->count();
        $avg = $user->averageRating();
        $pct = fn ($s) => $total > 0 ? round(($dist[$s] ?? 0) * 100 / $total) : 0;

        return view('farmer.reviews', [
            'reviews' => $reviews,
            'avg' => $avg,
            'avgFmt' => number_format($avg, 1),
            'total' => $total,
            'dist' => $dist,
            'posPct' => $total > 0 ? round((($dist[4] ?? 0) + ($dist[5] ?? 0)) * 100 / $total) : 0,
            'pct5' => $pct(5), 'pct4' => $pct(4), 'pct3' => $pct(3),
            'pct2' => $pct(2), 'pct1' => $pct(1),
            'n5' => $dist[5], 'n4' => $dist[4], 'n3' => $dist[3],
            'n2' => $dist[2], 'n1' => $dist[1],
        ]);
    }

    /**
     * Public farmer profile. Guests see a demo profile; logged-in
     * farmers see their own live data with an "Edit Profile" button.
     */
    public function profile(): View
    {
        $farmer = null;
        if (Auth::check() && Auth::user()->isFarmer()) {
            $farmer = Auth::user()->load('farmer')->farmer;
        }

        return view('farmer.profile', ['farmer' => $farmer]);
    }

    /** SRS: enhance profile — markets, days, pickup windows, map pin. */
    public function editProfile(): View
    {
        return view('farmer.profile-edit', [
            'user' => request()->user()->load('farmer'),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'stall_name' => 'required|string|max:100',
            'contact_person' => 'required|string|max:100',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email,' . $user->id,
            'address' => 'required|string|max:255',
            'description' => 'nullable|string|max:2000',
            'markets' => 'nullable|array',
            'markets.*' => 'string|max:100',
            'operating_days' => 'nullable|array',
            'operating_days.*' => 'string|max:10',
            'pickup_windows' => 'nullable|array',
            'pickup_windows.*' => 'string|max:50',
            'categories' => 'nullable|array',
            'categories.*' => 'string|max:50',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $user->update([
            'name' => $data['contact_person'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
        ]);

        Farmer::updateOrCreate(
            ['user_id' => $user->id],
            [
                'stall_name' => $data['stall_name'],
                'contact_person' => $data['contact_person'],
                'phone' => $data['phone'],
                'address' => $data['address'],
                'description' => $data['description'] ?? null,
                'markets' => $data['markets'] ?? [],
                'operating_days' => $data['operating_days'] ?? [],
                'pickup_windows' => $data['pickup_windows'] ?? [],
                'categories' => $data['categories'] ?? [],
                'latitude' => $data['latitude'] ?? null,
                'longitude' => $data['longitude'] ?? null,
                'avatar' => $data['avatar'] ?? $user->farmer?->avatar,
            ]
        );

        return redirect()->away('/farmer-profile')->with('success', 'Profile updated successfully.');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $request->user()->update(['password' => $request->input('password')]);

        return back()->with('success', 'Password changed successfully.');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    public const ROLE_CUSTOMER = 'customer';
    public const ROLE_FARMER = 'farmer';
    public const ROLE_ADMIN = 'admin';

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
        'avatar',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
        ];
    }

    public function farmer(): HasOne
    {
        return $this->hasOne(Farmer::class);
    }

    public function customer(): HasOne
    {
        return $this->hasOne(Customer::class);
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class, 'farmer_id');
    }

    public function customerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'customer_id');
    }

    public function farmerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'farmer_id');
    }

    public function favorites(): HasMany
    {
        return $this->hasMany(Favorite::class, 'customer_id');
    }

    public function reviewsGiven(): HasMany
    {
        return $this->hasMany(Review::class, 'customer_id');
    }

    public function reviewsReceived(): HasMany
    {
        return $this->hasMany(Review::class, 'farmer_id');
    }

    public function averageRating(): ?float
    {
        $avg = $this->reviewsReceived()->avg('rating');

        return $avg === null ? null : round((float) $avg, 1);
    }

    public function hasRole(string ...$roles): bool
    {
        return in_array($this->role, $roles, true);
    }

    public function isCustomer(): bool
    {
        return $this->role === self::ROLE_CUSTOMER;
    }

    public function isFarmer(): bool
    {
        return $this->role === self::ROLE_FARMER;
    }

    public function isAdmin(): bool
    {
        return $this->role === self::ROLE_ADMIN;
    }

    /** Where to send the user right after login / registration. */
    public function dashboardUrl(): string
    {
        return match ($this->role) {
            self::ROLE_FARMER => '/farmer-dashboard',
            self::ROLE_ADMIN => '/admin-dashboard',
            default => '/customer-dashboard',
        };
    }

    /** Profile photo URL with a graceful fallback. */
    public function avatarUrl(): string
    {
        if ($this->avatar) {
            return '/storage/' . $this->avatar;
        }
        if ($this->isFarmer() && $this->farmer?->avatar) {
            return '/storage/' . $this->farmer->avatar;
        }
        return 'https://picsum.photos/100/100?user=' . $this->id;
    }

    /** Display name: stall name for farmers, full name otherwise. */
    public function displayName(): string
    {
        if ($this->isFarmer() && $this->farmer?->stall_name) {
            return $this->farmer->stall_name;
        }
        return $this->name;
    }
}

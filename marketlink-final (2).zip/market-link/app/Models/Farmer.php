<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Farmer extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'stall_name',
        'contact_person',
        'phone',
        'address',
        'description',
        'markets',
        'operating_days',
        'pickup_windows',
        'categories',
        'latitude',
        'longitude',
        'avatar',
        'is_approved',
    ];

    protected function casts(): array
    {
        return [
            'markets' => 'array',
            'operating_days' => 'array',
            'pickup_windows' => 'array',
            'categories' => 'array',
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'is_approved' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

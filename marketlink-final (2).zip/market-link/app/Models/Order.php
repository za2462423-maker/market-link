<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    public const ST_PENDING = 'pending';
    public const ST_CONFIRMED = 'confirmed';
    public const ST_READY = 'ready';
    public const ST_COMPLETED = 'completed';
    public const ST_CANCELLED = 'cancelled';

    public const STATUSES = [
        self::ST_PENDING => ['Placed', 'warning'],
        self::ST_CONFIRMED => ['Confirmed', 'primary'],
        self::ST_READY => ['Ready for Pickup', 'info'],
        self::ST_COMPLETED => ['Completed', 'success'],
        self::ST_CANCELLED => ['Cancelled', 'danger'],
    ];

    protected $fillable = [
        'customer_id', 'farmer_id', 'market', 'pickup_date',
        'pickup_slot', 'status', 'subtotal', 'notes',
    ];

    protected $casts = [
        'pickup_date' => 'date',
        'subtotal' => 'decimal:2',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function farmer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'farmer_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function review(): HasOne
    {
        return $this->hasOne(Review::class);
    }

    public function code(): string
    {
        return '#ML-' . str_pad((string) $this->id, 5, '0', STR_PAD_LEFT);
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status][0] ?? ucfirst((string) $this->status);
    }

    public function statusBadge(): string
    {
        return self::STATUSES[$this->status][1] ?? 'secondary';
    }

    public function itemsSummary(): string
    {
        return $this->items->map(fn ($i) => $i->qty . 'x ' . $i->name)->implode(', ');
    }

    public function canBeCancelledByCustomer(): bool
    {
        return in_array($this->status, [self::ST_PENDING, self::ST_CONFIRMED], true);
    }
}

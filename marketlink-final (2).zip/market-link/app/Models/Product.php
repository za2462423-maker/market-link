<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Product extends Model
{
    protected $fillable = [
        'farmer_id', 'name', 'category', 'price', 'unit', 'stock',
        'description', 'image', 'markets', 'is_available', 'rating',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'rating' => 'decimal:2',
        'is_available' => 'boolean',
        'markets' => 'array',
    ];

    public const CATEGORIES = ['Vegetables', 'Fruits', 'Dairy', 'Meat', 'Baked Goods', 'Other'];
    public const UNITS = ['kg', 'g', 'litre', 'dozen', 'piece', 'bunch', 'pack'];

    public function farmer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'farmer_id');
    }

    public function imageUrl(): string
    {
        if ($this->image) {
            if (str_starts_with($this->image, 'http')) {
                return $this->image;
            }
            return '/storage/' . $this->image;
        }
        return 'https://picsum.photos/300/300?product=' . $this->id;
    }

    public function stockState(): string
    {
        if (!$this->is_available || $this->stock <= 0) {
            return 'out';
        }
        return $this->stock < 5 ? 'low' : 'ok';
    }
}

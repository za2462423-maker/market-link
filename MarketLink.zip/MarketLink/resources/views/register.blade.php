@php
    $page_title = "Register - MarketLink";
    $current_page = "register";
@endphp

@include('includes.header')

<style>
    /* =========================================
       FULL PAGE
    ========================================= */

    html,
    body {
        margin: 0;
        padding: 0;
        min-height: 100%;
    }

    body {
        min-height: 100vh;

        /* Local image from public/images/img1.jpg */
        background-image:
            linear-gradient(
                rgba(0, 0, 0, 0.35),
                rgba(0, 0, 0, 0.35)
            ),
            url("{{ asset('images/img1.jpg') }}");

        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }


    /* =========================================
       REGISTER PAGE
    ========================================= */

    .register-page {
        min-height: 100vh;

        display: flex;
        justify-content: center;
        align-items: center;

        padding: 50px 20px;
    }


    /* =========================================
       GLASS / TRANSPARENT REGISTER BOX
    ========================================= */

    .register-box {
        width: 50%;
        max-width: 720px;
         
        background: rgba(235, 244, 238, 0.2);

        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);

        border: 1px solid rgba(255, 255, 255, 0.55);

        border-radius: 24px;

        padding: 42px;

        box-shadow:
            0 20px 50px rgba(0, 0, 0, 0.5);

        animation: registerFade 0.7s ease;
    }


    /* =========================================
       LOGO
    ========================================= */

    .marketlink-logo {
        color: #198754;
        text-decoration: none;
    }

    .marketlink-logo:hover {
        color: #146c43;
    }


    /* =========================================
       HEADINGS
    ========================================= */

    .register-title {
        color: #173b2b;
        font-weight: 700;
    }

    .register-subtitle {
        color: #555;
    }


    /* =========================================
       FORM LABELS
    ========================================= */

    .register-box .form-label {
        color: #24352d;
    }


    /* =========================================
       TRANSPARENT INPUT FIELDS
    ========================================= */

    .register-box .form-control {
        width: 100%;

        background: rgba(255, 255, 255, 0.50);

        border: 1px solid rgba(255, 255, 255, 0.80);

        border-radius: 11px;

        padding: 11px 14px;

        color: #222;

        transition: all 0.25s ease;
    }


    .register-box .form-control:hover {
        background: rgba(255, 255, 255, 0.65);
    }


    .register-box .form-control:focus {
        background: rgba(255, 255, 255, 0.88);

        border-color: #198754;

        box-shadow:
            0 0 0 3px rgba(25, 135, 84, 0.15);

        outline: none;
    }


    .register-box .form-control::placeholder {
        color: #777;
    }


    /* =========================================
       CHECKBOX
    ========================================= */

    .register-box .form-check-input {
        cursor: pointer;
    }

    .register-box .form-check-input:checked {
        background-color: #198754;
        border-color: #198754;
    }


    /* =========================================
       CREATE ACCOUNT BUTTON
    ========================================= */

    .register-btn {
        width: 100%;

        background: #198754;
        border: none;

        color: white;

        padding: 12px;

        border-radius: 11px;

        font-size: 16px;
        font-weight: 600;

        transition: 0.3s ease;
    }


    .register-btn:hover {
        background: #146c43;

        color: white;

        transform: translateY(-2px);

        box-shadow:
            0 8px 20px rgba(0, 0, 0, 0.20);
    }


    /* =========================================
       LINKS
    ========================================= */

    .register-box a.text-success {
        color: #198754 !important;
    }

    .register-box a.text-success:hover {
        color: #146c43 !important;
    }


    .farmer-link {
        color: #555 !important;
    }

    .farmer-link:hover {
        color: #198754 !important;
    }


    /* =========================================
       COPYRIGHT
    ========================================= */

    .copyright {
        color: white;

        text-shadow:
            0 2px 6px rgba(0, 0, 0, 0.7);
    }


    /* =========================================
       ANIMATION
    ========================================= */

    @keyframes registerFade {

        from {
            opacity: 0;
            transform: translateY(25px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }

    }


    /* =========================================
       MOBILE
    ========================================= */

    @media (max-width: 768px) {

        body {
            background-attachment: scroll;
        }

        .register-page {
            padding: 30px 15px;
        }

        .register-box {
            padding: 28px 20px;
            border-radius: 20px;
        }

        .register-title {
            font-size: 25px;
        }

    }


    @media (max-width: 576px) {

        .register-box {
            padding: 24px 17px;
        }

        .register-page {
            align-items: flex-start;
            padding-top: 25px;
        }

    }
</style>


<!-- =========================================
     REGISTER PAGE
========================================= -->

<div class="register-page">

    <div class="register-box">

        <!-- MarketLink Logo -->
        <div class="text-center mb-4">

            <a href="{{ url('/') }}"
               class="marketlink-logo d-inline-block mb-2">

                <h2 class="fw-bold mb-0">
                    <i class="fas fa-seedling me-2"></i>
                    MarketLink
                </h2>

            </a>

            <h3 class="register-title mt-3 mb-1">
                Create an Account
            </h3>

            <p class="register-subtitle small mb-0">
                Join our community and get started as a customer.
            </p>

        </div>


        <!-- =========================================
             REGISTRATION FORM
        ========================================== -->

        <form action="{{ url('/customer-dashboard') }}" method="POST">

            @csrf


            <!-- Full Name + Contact Number -->

            <div class="row g-3 mb-3">

                <div class="col-md-6">

                    <label for="fullName"
                           class="form-label fw-medium small">

                        Full Name
                        <span class="text-danger">*</span>

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="fullName"
                        name="fullName"
                        placeholder="John Doe"
                        required
                    >

                </div>


                <div class="col-md-6">

                    <label for="phone"
                           class="form-label fw-medium small">

                        Contact Number

                    </label>

                    <input
                        type="tel"
                        class="form-control"
                        id="phone"
                        name="phone"
                        placeholder="0300 1234567"
                    >

                </div>

            </div>


            <!-- Email -->

            <div class="mb-3">

                <label for="email"
                       class="form-label fw-medium small">

                    Email Address
                    <span class="text-danger">*</span>

                </label>

                <input
                    type="email"
                    class="form-control"
                    id="email"
                    name="email"
                    placeholder="name@example.com"
                    required
                >

            </div>


            <!-- Address -->

            <div class="mb-3">

                <label for="address"
                       class="form-label fw-medium small">

                    Home Address
                    <span class="text-muted">
                        (Optional)
                    </span>

                </label>

                <input
                    type="text"
                    class="form-control"
                    id="address"
                    name="address"
                    placeholder="Your home address"
                >

                <div class="form-text small">
                    Used to show you the closest farmers markets.
                </div>

            </div>


            <!-- Password + Confirm Password -->

            <div class="row g-3 mb-4">

                <div class="col-md-6">

                    <label for="password"
                           class="form-label fw-medium small">

                        Password
                        <span class="text-danger">*</span>

                    </label>

                    <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="password"
                        placeholder="••••••••"
                        required
                    >

                </div>


                <div class="col-md-6">

                    <label for="confirmPassword"
                           class="form-label fw-medium small">

                        Confirm Password
                        <span class="text-danger">*</span>

                    </label>

                    <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        name="confirmPassword"
                        placeholder="••••••••"
                        required
                    >

                </div>

            </div>


            <!-- Terms & Privacy -->

            <div class="mb-4">

                <div class="form-check">

                    <input
                        class="form-check-input"
                        type="checkbox"
                        id="termsCheck"
                        required
                    >

                    <label
                        class="form-check-label small text-muted"
                        for="termsCheck">

                        I agree to the

                        <a href="#"
                           class="text-success text-decoration-none">

                            Terms of Service

                        </a>

                        and

                        <a href="#"
                           class="text-success text-decoration-none">

                            Privacy Policy

                        </a>

                    </label>

                </div>

            </div>


            <!-- Create Account -->

            <button
                type="submit"
                class="btn register-btn mb-4">

                Create Account

            </button>


            <!-- Login -->

            <p class="text-center small text-muted mb-2">

                Already have an account?

                <a
                    href="{{ url('/login') }}"
                    class="text-success text-decoration-none fw-bold">

                    Sign In

                </a>

            </p>


            <!-- Farmer Register -->

            <p class="text-center small text-muted mt-3 mb-0 border-top pt-3">

                <a
                    href="{{ url('/farmer-register') }}"
                    class="farmer-link text-decoration-none">

                    <i class="fas fa-seedling me-1"></i>

                    Want to sell your produce?
                    Register as a Farmer

                </a>

            </p>

        </form>

    </div>

</div>


<!-- =========================================
     COPYRIGHT
========================================= -->

<div class="position-fixed bottom-0 start-0 w-100 text-center pb-2 d-none d-md-block">

    <p class="small copyright mb-0">

        &copy; 2026 MarketLink. All rights reserved.

    </p>

</div>


@include('includes.footer')


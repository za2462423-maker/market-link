    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg ml-navbar sticky-top">
      <div class="container">
        <a class="navbar-brand ml-brand" href="index.php">
          <i class="fas fa-seedling"></i> MarketLink
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'index') ? 'active' : ''; ?>" href="/">Home</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'markets') ? 'active' : ''; ?>" href="markets">Markets</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'farmers') ? 'active' : ''; ?>" href="farmers">Farmers</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'products') ? 'active' : ''; ?>" href="products">Products</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'about') ? 'active' : ''; ?>" href="about">About</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'contact') ? 'active' : ''; ?>" href="contact">Contact</a></li>
          </ul>
          <div class="d-flex align-items-center gap-2">
            <a href="cart.php" class="ml-cart-btn" id="cartNavBtn" aria-label="Shopping Cart">
              <i class="fas fa-shopping-basket"></i> 
              <span class="ml-cart-badge" id="cartBadge">0</span>
            </a>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'login') ? 'active' : ''; ?>" href="login">login</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'register') ? 'active' : ''; ?>" href="register">register</a></li>
          </div>
        </div>
      </div>
    </nav>

<?php
$page_title = "MarketLink - Add Product ";
$current_page = "farmer-add-product";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="index.php" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="https://picsum.photos/60/60?random=55" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">Green Valley Farm</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="farmer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="farmer-profile-edit.php" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="farmer-add-product.php" class="ml-sidebar-link active"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="farmer-orders.php" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="farmer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <a href="farmer-login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative">
            <i class="fas fa-bell"></i>
          </button>
          <img src="https://picsum.photos/40/40?random=55" alt="User" class="rounded-circle border">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="mb-4">
          <a href="farmer-products.php" class="text-decoration-none text-muted mb-2 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Products</a>
          <h2 class="h4 mb-0 fw-bold">Add New Product</h2>
        </div>

        <form action="farmer-products.php" class="needs-validation" novalidate id="addProductForm">
          <div class="row g-4">
            <!-- Left Column: Product Details -->
            <div class="col-lg-8">
              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Basic Information</h5>
                  
                  <div class="mb-3">
                    <label for="productName" class="form-label fw-medium">Product Name *</label>
                    <input type="text" class="form-control" id="productName" placeholder="e.g. Fresh Red Tomatoes" required>
                    <div class="invalid-feedback">Please provide a product name.</div>
                  </div>
                  
                  <div class="mb-3">
                    <label for="productDesc" class="form-label fw-medium">Description</label>
                    <textarea class="form-control" id="productDesc" rows="5" placeholder="Describe the product, how it was grown, its taste, etc."></textarea>
                  </div>
                  
                  <div class="row g-3 mb-3">
                    <div class="col-md-6">
                      <label for="category" class="form-label fw-medium">Category *</label>
                      <select class="form-select" id="category" required>
                        <option value="" selected disabled>Select a category</option>
                        <option value="veg">Vegetables</option>
                        <option value="fruit">Fruits</option>
                        <option value="dairy">Dairy & Eggs</option>
                        <option value="meat">Meat & Poultry</option>
                        <option value="baked">Baked Goods</option>
                        <option value="other">Other</option>
                      </select>
                      <div class="invalid-feedback">Please select a category.</div>
                    </div>
                  </div>
                  
                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Pricing & Inventory</h5>
                  
                  <div class="row g-3">
                    <div class="col-md-4">
                      <label for="price" class="form-label fw-medium">Price (PKR) *</label>
                      <div class="input-group">
                        <span class="input-group-text">Rs.</span>
                        <input type="number" class="form-control" id="price" min="0" step="1" placeholder="0" required>
                        <div class="invalid-feedback">Valid price required.</div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <label for="unit" class="form-label fw-medium">Per Unit *</label>
                      <select class="form-select" id="unit" required>
                        <option value="" selected disabled>Select unit</option>
                        <option value="kg">kg</option>
                        <option value="g">g</option>
                        <option value="litre">litre</option>
                        <option value="dozen">dozen</option>
                        <option value="piece">piece</option>
                        <option value="bunch">bunch</option>
                        <option value="lb">lb</option>
                      </select>
                      <div class="invalid-feedback">Please select a unit.</div>
                    </div>
                    <div class="col-md-4">
                      <label for="quantity" class="form-label fw-medium">Available Quantity *</label>
                      <input type="number" class="form-control" id="quantity" min="0" placeholder="0" required>
                      <div class="invalid-feedback">Quantity required.</div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-4">Availability & Pickup</h5>
                  
                  <div class="mb-4">
                    <label class="form-label fw-medium d-block">Available at Markets</label>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="checkbox" id="market1" value="market1" checked>
                      <label class="form-check-label" for="market1">Downtown Farmers Market</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="checkbox" id="market2" value="market2" checked>
                      <label class="form-check-label" for="market2">Westside Weekend Market</label>
                    </div>
                  </div>

                  <div class="mb-3">
                    <label class="form-label fw-medium">Pickup Time Windows</label>
                    <div class="row g-2 align-items-center mb-2">
                      <div class="col-auto">
                        <select class="form-select form-select-sm">
                          <option>Saturday</option>
                          <option>Sunday</option>
                        </select>
                      </div>
                      <div class="col-auto">
                        <input type="time" class="form-control form-control-sm" value="08:00">
                      </div>
                      <div class="col-auto">to</div>
                      <div class="col-auto">
                        <input type="time" class="form-control form-control-sm" value="14:00">
                      </div>
                      <div class="col-auto">
                        <button type="button" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                      </div>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary"><i class="fas fa-plus"></i> Add Time Window</button>
                  </div>
                </div>
              </div>

            </div>

            <!-- Right Column: Media & Status -->
            <div class="col-lg-4">
              
              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-3">Product Image</h5>
                  
                  <div class="file-upload-area" id="dropArea">
                    <input type="file" class="file-upload-input" id="productImage" accept="image/*">
                    <div id="uploadContent">
                      <i class="fas fa-cloud-upload-alt"></i>
                      <p class="mb-0 fw-medium">Click to upload or drag image here</p>
                      <small class="text-muted">JPG, PNG up to 5MB</small>
                    </div>
                    <div id="imagePreviewContainer">
                      <img src="" id="imagePreview" alt="Preview">
                      <button type="button" class="btn btn-sm btn-danger mt-2" id="removeImageBtn">Remove Image</button>
                    </div>
                  </div>
                </div>
              </div>

              <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-4">
                  <h5 class="fw-bold mb-3">Status</h5>
                  
                  <div class="form-check form-switch fs-5">
                    <input class="form-check-input" type="checkbox" role="switch" id="productStatus" checked>
                    <label class="form-check-label ms-2" for="productStatus" id="statusLabel">Available</label>
                  </div>
                  <small class="text-muted d-block mt-2">Toggle off if you want to save as draft or if product is out of season.</small>
                </div>
              </div>

              <div class="d-grid gap-2">
                <button type="submit" class="btn btn-success btn-lg fw-semibold">Save Product</button>
                <a href="farmer-products.php" class="btn btn-outline-secondary">Cancel</a>
              </div>

            </div>
          </div>
        </form>

      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');

      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.add('show');
      });

      sidebarClose.addEventListener('click', () => {
        sidebar.classList.remove('show');
      });

      // Form validation
      const form = document.getElementById('addProductForm');
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);

      // Image Upload Preview
      const fileInput = document.getElementById('productImage');
      const uploadContent = document.getElementById('uploadContent');
      const previewContainer = document.getElementById('imagePreviewContainer');
      const imagePreview = document.getElementById('imagePreview');
      const removeBtn = document.getElementById('removeImageBtn');

      fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function(e) {
            imagePreview.src = e.target.result;
            uploadContent.style.display = 'none';
            previewContainer.style.display = 'block';
          }
          reader.readAsDataURL(file);
        }
      });

      removeBtn.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent accidental form submit or parent clicks
        fileInput.value = '';
        imagePreview.src = '';
        uploadContent.style.display = 'block';
        previewContainer.style.display = 'none';
      });

      // Status Toggle
      const statusToggle = document.getElementById('productStatus');
      const statusLabel = document.getElementById('statusLabel');
      
      statusToggle.addEventListener('change', function() {
        if(this.checked) {
          statusLabel.textContent = "Available";
          statusLabel.classList.remove('text-muted');
          statusLabel.classList.add('text-success');
        } else {
          statusLabel.textContent = "Not Available";
          statusLabel.classList.remove('text-success');
          statusLabel.classList.add('text-muted');
        }
      });
      // trigger once on load
      statusToggle.dispatchEvent(new Event('change'));
    });
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

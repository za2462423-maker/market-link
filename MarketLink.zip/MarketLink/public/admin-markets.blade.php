<?php
$page_title = "Admin Markets - MarketLink ";
$current_page = "admin-markets";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link active"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Manage Markets</h4>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#marketModal"><i class="fas fa-plus"></i> Add Market</button>
      </div>

      <div class="ml-admin-content">
        
        <div class="row g-4">
          <!-- Market Card 1 -->
          <div class="col-md-6 col-lg-4">
            <div class="admin-card h-100">
              <img src="https://picsum.photos/400/200?random=41" alt="Market" class="card-img-top" style="height: 150px; object-fit: cover;">
              <div class="admin-card-body">
                <h5 class="fw-bold mb-2">F-8 Markaz Farmers Market</h5>
                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt"></i> F-8 Markaz, Islamabad</p>
                <p class="text-muted small mb-3"><i class="far fa-clock"></i> Sat, Sun | 08:00 AM - 02:00 PM</p>
                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                  <span class="badge bg-success bg-opacity-10 text-success"><i class="fas fa-tractor"></i> 12 Active Farmers</span>
                  <div>
                    <button class="btn btn-sm btn-light text-primary" data-bs-toggle="modal" data-bs-target="#marketModal"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Market Card 2 -->
          <div class="col-md-6 col-lg-4">
            <div class="admin-card h-100">
              <img src="https://picsum.photos/400/200?random=42" alt="Market" class="card-img-top" style="height: 150px; object-fit: cover;">
              <div class="admin-card-body">
                <h5 class="fw-bold mb-2">G-9 Karachi Company Market</h5>
                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt"></i> G-9 Markaz, Islamabad</p>
                <p class="text-muted small mb-3"><i class="far fa-clock"></i> Mon, Wed, Fri | 09:00 AM - 05:00 PM</p>
                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                  <span class="badge bg-success bg-opacity-10 text-success"><i class="fas fa-tractor"></i> 24 Active Farmers</span>
                  <div>
                    <button class="btn btn-sm btn-light text-primary" data-bs-toggle="modal" data-bs-target="#marketModal"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Market Card 3 -->
          <div class="col-md-6 col-lg-4">
            <div class="admin-card h-100">
              <img src="https://picsum.photos/400/200?random=43" alt="Market" class="card-img-top" style="height: 150px; object-fit: cover;">
              <div class="admin-card-body">
                <h5 class="fw-bold mb-2">Saddar Fresh Bazaar</h5>
                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt"></i> Saddar, Rawalpindi</p>
                <p class="text-muted small mb-3"><i class="far fa-clock"></i> Daily | 06:00 AM - 12:00 PM</p>
                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                  <span class="badge bg-success bg-opacity-10 text-success"><i class="fas fa-tractor"></i> 45 Active Farmers</span>
                  <div>
                    <button class="btn btn-sm btn-light text-primary" data-bs-toggle="modal" data-bs-target="#marketModal"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- Add/Edit Market Modal -->
  <div class="modal fade" id="marketModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Market Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form>
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label">Market Name</label>
                <input type="text" class="form-control" placeholder="e.g. F-8 Farmers Market">
              </div>
              <div class="col-md-6">
                <label class="form-label">City</label>
                <select class="form-select">
                  <option>Islamabad</option>
                  <option>Rawalpindi</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label">Map Link (Google Maps URL)</label>
                <input type="url" class="form-control" placeholder="https://maps.google.com/...">
              </div>
              <div class="col-md-12">
                <label class="form-label">Address</label>
                <input type="text" class="form-control" placeholder="Full address">
              </div>
              <div class="col-md-12">
                <label class="form-label">Operating Days</label>
                <div class="d-flex gap-3 flex-wrap">
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d1"><label class="form-check-label" for="d1">Mon</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d2"><label class="form-check-label" for="d2">Tue</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d3"><label class="form-check-label" for="d3">Wed</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d4"><label class="form-check-label" for="d4">Thu</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d5"><label class="form-check-label" for="d5">Fri</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d6"><label class="form-check-label" for="d6">Sat</label></div>
                  <div class="form-check"><input type="checkbox" class="form-check-input" id="d7"><label class="form-check-label" for="d7">Sun</label></div>
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label">Open Time</label>
                <input type="time" class="form-control">
              </div>
              <div class="col-md-6">
                <label class="form-label">Close Time</label>
                <input type="time" class="form-control">
              </div>
              <div class="col-md-12">
                <label class="form-label">Description</label>
                <textarea class="form-control" rows="3" placeholder="Market description..."></textarea>
              </div>
              <div class="col-md-12">
                <label class="form-label">Market Image</label>
                <input type="file" class="form-control" accept="image/*">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-success">Save Market</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "MarketLink - Manage Orders ";
$current_page = "farmer-orders";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="index.php" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="https://picsum.photos/60/60?random=55" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">Green Valley Farm</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="farmer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="farmer-profile-edit.php" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="farmer-add-product.php" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="farmer-orders.php" class="ml-sidebar-link active"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="farmer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <a href="farmer-login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative">
            <i class="fas fa-bell"></i>
          </button>
          <img src="https://picsum.photos/40/40?random=55" alt="User" class="rounded-circle border">
        </div>
      </div>

      <div class="dashboard-content">
        <h2 class="h4 mb-4 fw-bold">Manage Orders</h2>

        <div class="filter-bar">
          <div class="row g-3 align-items-end">
            <div class="col-md-4">
              <label class="form-label small text-muted mb-1">Search</label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i class="fas fa-search text-muted"></i></span>
                <input type="text" class="form-control" placeholder="Order ID, Customer...">
              </div>
            </div>
            <div class="col-md-3">
              <label class="form-label small text-muted mb-1">Status</label>
              <select class="form-select">
                <option value="all">All Orders</option>
                <option value="pending">Pending</option>
                <option value="accepted">Accepted</option>
                <option value="ready">Ready for Pickup</option>
                <option value="completed">Completed</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label small text-muted mb-1">Date</label>
              <input type="date" class="form-control">
            </div>
            <div class="col-md-2">
              <button class="btn btn-outline-secondary w-100">Reset</button>
            </div>
          </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="ps-4">Order ID</th>
                  <th>Customer</th>
                  <th>Products</th>
                  <th>Total</th>
                  <th>Pickup Info</th>
                  <th>Status</th>
                  <th class="text-end pe-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                <!-- Pending Order -->
                <tr id="row-1045">
                  <td class="ps-4"><span class="fw-medium text-primary">#1045</span></td>
                  <td>
                    <div class="fw-medium">Ali Khan</div>
                    <small class="text-muted">0300-1234567</small>
                  </td>
                  <td><div class="order-products" title="2x Tomatoes, 1x Onion, 1x Milk">2x Tomatoes, 1x Onion...</div></td>
                  <td class="fw-bold">Rs. 850</td>
                  <td>
                    <div>Today</div>
                    <small class="text-muted">10:00 AM - 11:00 AM</small>
                  </td>
                  <td><span class="badge bg-warning text-dark status-badge">Pending</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-success action-accept" data-id="1045" title="Accept"><i class="fas fa-check"></i></button>
                    <button class="btn btn-sm btn-danger action-decline" data-id="1045" title="Decline"><i class="fas fa-times"></i></button>
                    <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>

                <!-- Accepted Order -->
                <tr id="row-1044">
                  <td class="ps-4"><span class="fw-medium text-primary">#1044</span></td>
                  <td>
                    <div class="fw-medium">Sara Ahmed</div>
                    <small class="text-muted">0333-9876543</small>
                  </td>
                  <td><div class="order-products">3L Fresh Milk</div></td>
                  <td class="fw-bold">Rs. 600</td>
                  <td>
                    <div>Today</div>
                    <small class="text-muted">11:30 AM - 12:30 PM</small>
                  </td>
                  <td><span class="badge bg-primary status-badge">Accepted</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-info text-white action-ready" data-id="1044" title="Mark Ready"><i class="fas fa-box"></i> Ready</button>
                    <button class="btn btn-sm btn-light border text-primary ms-1" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>

                <!-- Ready Order -->
                <tr id="row-1043">
                  <td class="ps-4"><span class="fw-medium text-primary">#1043</span></td>
                  <td>
                    <div class="fw-medium">Zainab R.</div>
                    <small class="text-muted">0321-5554443</small>
                  </td>
                  <td><div class="order-products">1 Dozen Organic Eggs</div></td>
                  <td class="fw-bold">Rs. 350</td>
                  <td>
                    <div>Today</div>
                    <small class="text-muted">09:00 AM - 10:00 AM</small>
                  </td>
                  <td><span class="badge bg-info text-dark status-badge">Ready</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-success action-complete" data-id="1043" title="Mark Completed"><i class="fas fa-check-circle"></i></button>
                    <button class="btn btn-sm btn-light border text-primary ms-1" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>

                <!-- Completed Order -->
                <tr id="row-1042">
                  <td class="ps-4"><span class="fw-medium text-primary">#1042</span></td>
                  <td>
                    <div class="fw-medium">Usman M.</div>
                  </td>
                  <td><div class="order-products">Assorted Vegetables</div></td>
                  <td class="fw-bold">Rs. 1,200</td>
                  <td>
                    <div>Yesterday</div>
                    <small class="text-muted">04:00 PM</small>
                  </td>
                  <td><span class="badge bg-success status-badge">Completed</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>
                
                <!-- Completed Order 2 -->
                <tr id="row-1041">
                  <td class="ps-4"><span class="fw-medium text-primary">#1041</span></td>
                  <td>
                    <div class="fw-medium">Fatima S.</div>
                  </td>
                  <td><div class="order-products">Honey (500g)</div></td>
                  <td class="fw-bold">Rs. 1,500</td>
                  <td>
                    <div>Yesterday</div>
                    <small class="text-muted">02:00 PM</small>
                  </td>
                  <td><span class="badge bg-success status-badge">Completed</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>
                
                <!-- Declined Order -->
                <tr id="row-1040">
                  <td class="ps-4"><span class="fw-medium text-primary">#1040</span></td>
                  <td>
                    <div class="fw-medium">Bilal Q.</div>
                  </td>
                  <td><div class="order-products">Apples (5kg)</div></td>
                  <td class="fw-bold">Rs. 1,500</td>
                  <td>
                    <div>Yesterday</div>
                    <small class="text-muted">10:00 AM</small>
                  </td>
                  <td><span class="badge bg-danger status-badge">Declined</span></td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center">
            <span class="text-muted small">Showing 6 orders</span>
            <nav aria-label="Page navigation">
              <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">Next</a></li>
              </ul>
            </nav>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Order Detail Modal -->
  <div class="modal fade" id="orderDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fw-bold">Order Details <span class="text-primary">#1045</span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-0">
          <div class="p-4 bg-light border-bottom">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <h6 class="mb-0 fw-bold">Customer Info</h6>
              <span class="badge bg-warning text-dark">Pending</span>
            </div>
            <div class="d-flex align-items-center gap-3">
              <div class="bg-secondary bg-opacity-10 rounded-circle p-3"><i class="fas fa-user text-secondary"></i></div>
              <div>
                <div class="fw-medium">Ali Khan</div>
                <div class="text-muted small"><i class="fas fa-phone-alt"></i> 0300-1234567</div>
              </div>
            </div>
          </div>
          
          <div class="p-4 border-bottom">
            <h6 class="fw-bold mb-3">Pickup Information</h6>
            <div class="mb-2"><i class="far fa-calendar-alt text-muted me-2"></i> Date: <span class="fw-medium">Thursday, Oct 24, 2026</span></div>
            <div class="mb-2"><i class="far fa-clock text-muted me-2"></i> Time: <span class="fw-medium">10:00 AM - 11:00 AM</span></div>
            <div><i class="fas fa-map-marker-alt text-muted me-2"></i> Location: <span class="fw-medium">Downtown Farmers Market</span></div>
            
            <div class="mt-3 p-3 bg-warning bg-opacity-10 border border-warning rounded">
              <span class="fw-bold small d-block mb-1">Customer Note:</span>
              <span class="small">Please make sure the tomatoes are not too ripe. Thanks!</span>
            </div>
          </div>

          <div class="p-4">
            <h6 class="fw-bold mb-3">Order Items</h6>
            <ul class="list-group list-group-flush mb-3">
              <li class="list-group-item d-flex justify-content-between px-0">
                <div>
                  <span class="fw-medium">Fresh Red Tomatoes</span>
                  <div class="text-muted small">2 kg x Rs. 150</div>
                </div>
                <span>Rs. 300</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0">
                <div>
                  <span class="fw-medium">Organic Onions</span>
                  <div class="text-muted small">1 kg x Rs. 120</div>
                </div>
                <span>Rs. 120</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0">
                <div>
                  <span class="fw-medium">Farm Fresh Milk</span>
                  <div class="text-muted small">2 litre x Rs. 200</div>
                </div>
                <span>Rs. 400</span>
              </li>
            </ul>
            
            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
              <span class="fw-bold">Total Amount</span>
              <span class="fs-5 fw-bold text-success">Rs. 820</span>
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Decline Order</button>
          <button type="button" class="btn btn-success px-4">Accept Order</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');

      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.add('show');
      });

      sidebarClose.addEventListener('click', () => {
        sidebar.classList.remove('show');
      });

      // Interactive order status buttons
      document.querySelectorAll('.action-accept').forEach(btn => {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          const row = document.getElementById(`row-${id}`);
          const badge = row.querySelector('.status-badge');
          
          badge.className = 'badge bg-primary status-badge';
          badge.textContent = 'Accepted';
          
          const actionsTd = this.parentElement;
          actionsTd.innerHTML = `
            <button class="btn btn-sm btn-info text-white action-ready" data-id="${id}" title="Mark Ready"><i class="fas fa-box"></i> Ready</button>
            <button class="btn btn-sm btn-light border text-primary ms-1" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
          `;
          attachReadyListeners();
        });
      });

      document.querySelectorAll('.action-decline').forEach(btn => {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          const row = document.getElementById(`row-${id}`);
          const badge = row.querySelector('.status-badge');
          
          badge.className = 'badge bg-danger status-badge';
          badge.textContent = 'Declined';
          
          const actionsTd = this.parentElement;
          actionsTd.innerHTML = `
            <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
          `;
        });
      });

      function attachReadyListeners() {
        document.querySelectorAll('.action-ready').forEach(btn => {
          // avoid attaching multiple times
          btn.removeEventListener('click', markReady);
          btn.addEventListener('click', markReady);
        });
      }

      function markReady(e) {
        const btn = e.currentTarget;
        const id = btn.getAttribute('data-id');
        const row = document.getElementById(`row-${id}`);
        const badge = row.querySelector('.status-badge');
        
        badge.className = 'badge bg-info text-dark status-badge';
        badge.textContent = 'Ready';
        
        const actionsTd = btn.parentElement;
        actionsTd.innerHTML = `
          <button class="btn btn-sm btn-success action-complete" data-id="${id}" title="Mark Completed"><i class="fas fa-check-circle"></i></button>
          <button class="btn btn-sm btn-light border text-primary ms-1" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
        `;
        attachCompleteListeners();
      }

      function attachCompleteListeners() {
        document.querySelectorAll('.action-complete').forEach(btn => {
          btn.removeEventListener('click', markComplete);
          btn.addEventListener('click', markComplete);
        });
      }

      function markComplete(e) {
        const btn = e.currentTarget;
        const id = btn.getAttribute('data-id');
        const row = document.getElementById(`row-${id}`);
        const badge = row.querySelector('.status-badge');
        
        badge.className = 'badge bg-success status-badge';
        badge.textContent = 'Completed';
        
        const actionsTd = btn.parentElement;
        actionsTd.innerHTML = `
          <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#orderDetailModal" title="View"><i class="fas fa-eye"></i></button>
        `;
      }

      attachReadyListeners();
      attachCompleteListeners();
    });
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "My Reviews - MarketLink ";
$current_page = "customer-reviews";
require_once __DIR__ . '/includes/header.php';
?>


<div class="ml-dashboard-wrapper d-flex">
  
  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="index.php" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="https://picsum.photos/60/60?random=99" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">John Smith</div>
        <div class="ml-sidebar-role">Customer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="customer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="customer-orders.php" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="customer-favorites.php" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
      <a href="customer-favorites.php#markets" class="ml-sidebar-link"><i class="fas fa-map-marker-alt"></i> Saved Markets</a>
      <a href="customer-reviews.php" class="ml-sidebar-link active"><i class="fas fa-star"></i> Reviews</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications <span class="ml-sidebar-badge badge bg-danger rounded-pill">3</span></a>
      <hr class="ml-sidebar-divider">
      <a href="login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
    
    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">My Reviews</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="products.php" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <div class="ml-topbar-notif position-relative" id="notifBtn" style="cursor:pointer;">
          <i class="fas fa-bell fa-lg text-secondary"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">3</span>
        </div>
        <img src="https://picsum.photos/36/36?random=99" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">
      
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h4 mb-0 fw-bold">My Reviews</h1>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#writeReviewModal">
          <i class="fas fa-pen me-1"></i> Write a Review
        </button>
      </div>

      <div class="row g-4">
        <!-- Review Card 1 -->
        <div class="col-md-6 col-lg-12 col-xl-6">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex align-items-center">
                  <img src="https://picsum.photos/50/50?random=1" class="rounded me-3" alt="Farmer">
                  <div>
                    <h6 class="mb-0 fw-bold">Green Valley Farm</h6>
                    <span class="badge bg-primary bg-opacity-10 text-primary small">Farmer Review</span>
                  </div>
                </div>
                <div class="dropdown">
                  <button class="btn btn-sm btn-light text-muted border-0" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-ellipsis-v"></i>
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                    <li><a class="dropdown-item" href="#"><i class="fas fa-edit me-2 text-muted"></i>Edit</a></li>
                    <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash me-2"></i>Delete</a></li>
                  </ul>
                </div>
              </div>
              <div class="d-flex align-items-center mb-2">
                <div class="star-rating-display me-2">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
                <small class="text-muted">Oct 10, 2026</small>
              </div>
              <p class="text-secondary mb-0">Absolutely wonderful produce! The tomatoes were incredibly fresh, and the farmer is always very friendly at the market. Highly recommend supporting this farm.</p>
            </div>
          </div>
        </div>

        <!-- Review Card 2 -->
        <div class="col-md-6 col-lg-12 col-xl-6">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex align-items-center">
                  <img src="https://picsum.photos/50/50?random=4" class="rounded me-3" alt="Product">
                  <div>
                    <h6 class="mb-0 fw-bold">Organic Honey (16oz)</h6>
                    <span class="badge bg-success bg-opacity-10 text-success small">Product Review</span>
                  </div>
                </div>
                <div class="dropdown">
                  <button class="btn btn-sm btn-light text-muted border-0" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-ellipsis-v"></i>
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                    <li><a class="dropdown-item" href="#"><i class="fas fa-edit me-2 text-muted"></i>Edit</a></li>
                    <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash me-2"></i>Delete</a></li>
                  </ul>
                </div>
              </div>
              <div class="d-flex align-items-center mb-2">
                <div class="star-rating-display me-2">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="far fa-star"></i>
                </div>
                <small class="text-muted">Oct 05, 2026</small>
              </div>
              <p class="text-secondary mb-0">Very good honey, great flavor. It was a bit crystallized when I got it, but placing the jar in warm water fixed it perfectly. Will buy again.</p>
            </div>
          </div>
        </div>

        <!-- Review Card 3 -->
        <div class="col-md-6 col-lg-12 col-xl-6">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex align-items-center">
                  <img src="https://picsum.photos/50/50?random=5" class="rounded me-3" alt="Product">
                  <div>
                    <h6 class="mb-0 fw-bold">Free Range Eggs (Dozen)</h6>
                    <span class="badge bg-success bg-opacity-10 text-success small">Product Review</span>
                  </div>
                </div>
                <div class="dropdown">
                  <button class="btn btn-sm btn-light text-muted border-0" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-ellipsis-v"></i>
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                    <li><a class="dropdown-item" href="#"><i class="fas fa-edit me-2 text-muted"></i>Edit</a></li>
                    <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash me-2"></i>Delete</a></li>
                  </ul>
                </div>
              </div>
              <div class="d-flex align-items-center mb-2">
                <div class="star-rating-display me-2">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
                <small class="text-muted">Sep 28, 2026</small>
              </div>
              <p class="text-secondary mb-0">You can really taste the difference compared to store-bought eggs. The yolks are so rich and orange. Always happy to get these every week.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </main>
</div>

<!-- Write Review Modal -->
<div class="modal fade" id="writeReviewModal" tabindex="-1" aria-labelledby="writeReviewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold" id="writeReviewModalLabel">Write a Review</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="reviewForm">
          <div class="mb-3">
            <label class="form-label fw-medium">What would you like to review?</label>
            <select class="form-select bg-light">
              <option value="" selected disabled>Select a recent purchase or farmer</option>
              <optgroup label="Farmers">
                <option value="f1">Green Valley Farm</option>
                <option value="f2">Sunny Acres</option>
              </optgroup>
              <optgroup label="Products">
                <option value="p1">Organic Tomatoes</option>
                <option value="p2">Fresh Honey</option>
                <option value="p3">Free Range Eggs</option>
              </optgroup>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-medium d-block">Rating</label>
            <div class="star-rating fs-3" id="ratingStars">
              <i class="far fa-star" data-rating="1"></i>
              <i class="far fa-star" data-rating="2"></i>
              <i class="far fa-star" data-rating="3"></i>
              <i class="far fa-star" data-rating="4"></i>
              <i class="far fa-star" data-rating="5"></i>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label fw-medium">Your Review</label>
            <textarea class="form-control bg-light" rows="4" placeholder="Share your experience..."></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer border-top-0 pt-0">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-success px-4">Submit Review</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/data.js"></script>
<script src="js/main.js"></script>
<script>
  // Sidebar toggles
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });

  // Interactive Star Rating in Modal
  const stars = document.querySelectorAll('#ratingStars i');
  let currentRating = 0;

  stars.forEach(star => {
    star.addEventListener('mouseover', function() {
      const rating = this.getAttribute('data-rating');
      updateStars(rating, true);
    });

    star.addEventListener('mouseout', function() {
      updateStars(currentRating, false);
    });

    star.addEventListener('click', function() {
      currentRating = this.getAttribute('data-rating');
      updateStars(currentRating, false);
    });
  });

  function updateStars(rating, isHover) {
    stars.forEach(star => {
      const starRating = star.getAttribute('data-rating');
      if (starRating <= rating) {
        star.classList.remove('far');
        star.classList.add('fas');
      } else {
        star.classList.remove('fas');
        star.classList.add('far');
      }
    });
  }
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "Admin Login - MarketLink ";
$current_page = "admin-login";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="admin-login-wrapper">
    <div class="admin-login-left">
      <i class="fas fa-shield-alt"></i>
      <h2>Admin Portal</h2>
      <p class="mt-3">Authorized personnel only. Please ensure you are on a secure connection before proceeding.</p>
    </div>
    
    <div class="admin-login-right">
      <div class="admin-login-form">
        <h3 class="mb-4 fw-bold">Admin Login</h3>
        <form action="admin-dashboard.php">
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-control" placeholder="admin@marketlink.com" required>
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="••••••••" required>
          </div>
          <button type="submit" class="btn btn-success w-100 py-2">Secure Login</button>
        </form>
        <div class="text-center mt-5 text-muted small">
          &copy; 2026 MarketLink Admin. All rights reserved.
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

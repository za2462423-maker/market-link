<?php
$page_title = "Admin Orders - MarketLink ";
$current_page = "admin-orders";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link active"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Manage Orders</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-shopping-bag"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3>3,582</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-clock"></i></div>
              <div class="admin-stat-info">
                <p>Pending</p>
                <h3>145</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info">
                <p>Completed</p>
                <h3>3,310</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon" style="background:#f8d7da; color:#721c24"><i class="fas fa-times-circle"></i></div>
              <div class="admin-stat-info">
                <p>Cancelled</p>
                <h3>127</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <input type="text" class="form-control" placeholder="Search by Order ID..." style="max-width: 300px;">
            <select class="form-select w-auto">
              <option value="">All Statuses</option>
              <option>Pending</option>
              <option>Completed</option>
              <option>Cancelled</option>
            </select>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Farmer</th>
                  <th>Products</th>
                  <th>Pickup Date</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>#ORD-8902</strong></td>
                  <td>Fatima Ali</td>
                  <td>Green Valley Farms</td>
                  <td>3 items</td>
                  <td>Sep 25, 2026</td>
                  <td>PKR 1,250</td>
                  <td><span class="badge badge-pending">Pending</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8901</strong></td>
                  <td>Usman Tariq</td>
                  <td>Ahmad's Organics</td>
                  <td>5 items</td>
                  <td>Sep 24, 2026</td>
                  <td>PKR 3,400</td>
                  <td><span class="badge badge-active">Completed</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8900</strong></td>
                  <td>Aisha Khan</td>
                  <td>Fresh Dairy Co.</td>
                  <td>1 items</td>
                  <td>Sep 24, 2026</td>
                  <td>PKR 850</td>
                  <td><span class="badge badge-active">Completed</span></td>
                  <td><button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8899</strong></td>
                  <td>Bilal Qureshi</td>
                  <td>Green Fields</td>
                  <td>8 items</td>
                  <td>Sep 26, 2026</td>
                  <td>PKR 5,100</td>
                  <td><span class="badge badge-pending">Pending</span></td>
                  <td><button class="btn btn-sm btn-light"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <tr>
                  <td><strong>#ORD-8898</strong></td>
                  <td>Sana Hameed</td>
                  <td>Organic Veggies</td>
                  <td>2 items</td>
                  <td>Sep 23, 2026</td>
                  <td>PKR 2,200</td>
                  <td><span class="badge badge-removed">Cancelled</span></td>
                  <td><button class="btn btn-sm btn-light"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- Order Modal -->
  <div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Order #ORD-8902</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p><strong>Customer:</strong> Fatima Ali</p>
          <p><strong>Farmer:</strong> Green Valley Farms</p>
          <p><strong>Status:</strong> <span class="badge badge-pending">Pending</span></p>
          <p><strong>Pickup Date:</strong> Sep 25, 2026</p>
          <hr>
          <h6>Items:</h6>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Organic Tomatoes (2kg)
              <span>PKR 300</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Fresh Potatoes (3kg)
              <span>PKR 250</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Desi Eggs (1 Dozen)
              <span>PKR 700</span>
            </li>
          </ul>
          <div class="d-flex justify-content-between fw-bold">
            <span>Total</span>
            <span>PKR 1,250</span>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-danger btn-sm">Cancel Order</button>
          <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "MarketLink - Farmer Registration ";
$current_page = "farmer-register";
require_once __DIR__ . '/includes/header.php';
?>

  <div class="split-layout">
    <div class="split-left">
      <div class="mb-auto">
        <h2 class="fw-bold"><i class="fas fa-seedling"></i> MarketLink</h2>
        <span class="badge bg-light text-success mb-3 fs-6">Farmer Portal</span>
      </div>
      <div class="my-5">
        <h2 class="fw-bold mb-3">Join our community of local farmers</h2>
        <p class="mb-4">Set up your digital stall in minutes and start selling directly to customers in your area.</p>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-store"></i></div>
          <span>Create your online stall</span>
        </div>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-box-open"></i></div>
          <span>List your fresh products</span>
        </div>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-hand-holding-usd"></i></div>
          <span>Receive direct orders</span>
        </div>
      </div>
      <div class="mt-auto">
        <p class="mb-0 text-white-50">&copy; 2026 MarketLink</p>
      </div>
    </div>
    
    <div class="split-right">
      <div class="auth-form-container">
        <h3 class="fw-bold mb-1">Register as a Farmer</h3>
        <p class="text-muted mb-4">Fill out the details below to create your digital stall.</p>
        
        <form action="farmer-dashboard.php" method="GET" id="farmerRegisterForm" class="needs-validation" novalidate>
          
          <div class="form-section-title mt-4">Business Information</div>
          <div class="row g-3">
            <div class="col-md-6">
              <label for="stallName" class="form-label">Stall / Business Name *</label>
              <input type="text" class="form-control" id="stallName" required>
              <div class="invalid-feedback">Please provide your business name.</div>
            </div>
            <div class="col-md-6">
              <label for="contactPerson" class="form-label">Contact Person Name *</label>
              <input type="text" class="form-control" id="contactPerson" required>
              <div class="invalid-feedback">Please provide contact person name.</div>
            </div>
            <div class="col-md-6">
              <label for="contactNumber" class="form-label">Contact Number *</label>
              <input type="tel" class="form-control" id="contactNumber" required>
              <div class="invalid-feedback">Please provide a contact number.</div>
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Email Address *</label>
              <input type="email" class="form-control" id="email" required>
              <div class="invalid-feedback">Please provide a valid email.</div>
            </div>
            <div class="col-12">
              <label for="address" class="form-label">Farm / Business Address *</label>
              <input type="text" class="form-control" id="address" required>
              <div class="invalid-feedback">Please provide your address.</div>
            </div>
          </div>
          
          <div class="form-section-title mt-4">Market Details</div>
          <div class="mb-3">
            <label class="form-label">Select Market(s) You Operate In *</label>
            <div class="row g-2">
              <div class="col-md-6">
                <div class="form-check border p-2 rounded">
                  <input class="form-check-input ms-1" type="checkbox" id="market1" required>
                  <label class="form-check-label ms-2" for="market1">Downtown Farmers Market</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-check border p-2 rounded">
                  <input class="form-check-input ms-1" type="checkbox" id="market2">
                  <label class="form-check-label ms-2" for="market2">Westside Weekend Market</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-check border p-2 rounded">
                  <input class="form-check-input ms-1" type="checkbox" id="market3">
                  <label class="form-check-label ms-2" for="market3">Community Farm Stand</label>
                </div>
              </div>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label">Operating Days</label>
            <div class="d-flex flex-wrap gap-2">
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="dayMon" autocomplete="off">
                <label class="btn btn-outline-success btn-sm" for="dayMon">Mon</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="dayTue" autocomplete="off">
                <label class="btn btn-outline-success btn-sm" for="dayTue">Tue</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="dayWed" autocomplete="off">
                <label class="btn btn-outline-success btn-sm" for="dayWed">Wed</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="dayThu" autocomplete="off">
                <label class="btn btn-outline-success btn-sm" for="dayThu">Thu</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="dayFri" autocomplete="off">
                <label class="btn btn-outline-success btn-sm" for="dayFri">Fri</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="daySat" autocomplete="off" checked>
                <label class="btn btn-outline-success btn-sm" for="daySat">Sat</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" id="daySun" autocomplete="off" checked>
                <label class="btn btn-outline-success btn-sm" for="daySun">Sun</label>
              </div>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label">Product Categories *</label>
            <div class="row g-2">
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="catVeg" required>
                  <label class="form-check-label" for="catVeg">Vegetables</label>
                </div>
              </div>
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="catFruit">
                  <label class="form-check-label" for="catFruit">Fruits</label>
                </div>
              </div>
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="catDairy">
                  <label class="form-check-label" for="catDairy">Dairy & Eggs</label>
                </div>
              </div>
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="catMeat">
                  <label class="form-check-label" for="catMeat">Meat & Poultry</label>
                </div>
              </div>
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="catBaked">
                  <label class="form-check-label" for="catBaked">Baked Goods</label>
                </div>
              </div>
            </div>
          </div>

          <div class="form-section-title mt-4">Account Security</div>
          <div class="row g-3">
            <div class="col-md-6">
              <label for="password" class="form-label">Password *</label>
              <input type="password" class="form-control" id="password" required>
              <div class="invalid-feedback">Please provide a password.</div>
            </div>
            <div class="col-md-6">
              <label for="confirmPassword" class="form-label">Confirm Password *</label>
              <input type="password" class="form-control" id="confirmPassword" required>
              <div class="invalid-feedback" id="passwordFeedback">Passwords do not match.</div>
            </div>
          </div>
          
          <div class="mb-4 mt-4 form-check">
            <input type="checkbox" class="form-check-input" id="terms" required>
            <label class="form-check-label text-muted" for="terms">I agree to the <a href="#" class="text-success">Terms of Service</a> and <a href="#" class="text-success">Privacy Policy</a></label>
            <div class="invalid-feedback">You must agree before submitting.</div>
          </div>
          
          <button type="submit" class="btn btn-farmer w-100 py-2 mb-3 fw-semibold">Register</button>
          
          <p class="text-center text-muted">
            Already have a farmer account? <a href="farmer-login.php" class="text-success text-decoration-none fw-semibold">Sign In</a>
          </p>
        </form>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Form validation
    (function () {
      'use strict'
      var form = document.getElementById('farmerRegisterForm');
      var password = document.getElementById('password');
      var confirmPassword = document.getElementById('confirmPassword');
      
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        
        if (password.value !== confirmPassword.value) {
          confirmPassword.setCustomValidity("Passwords don't match");
          event.preventDefault();
          event.stopPropagation();
        } else {
          confirmPassword.setCustomValidity("");
        }
        
        form.classList.add('was-validated');
      }, false);
      
      confirmPassword.addEventListener('input', function() {
        if (password.value !== confirmPassword.value) {
          confirmPassword.setCustomValidity("Passwords don't match");
        } else {
          confirmPassword.setCustomValidity("");
        }
      });
      
      // Ensure at least one market is checked
      const marketCheckboxes = [document.getElementById('market1'), document.getElementById('market2'), document.getElementById('market3')];
      marketCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
          const isChecked = marketCheckboxes.some(c => c.checked);
          marketCheckboxes.forEach(c => {
            if (isChecked) {
              c.removeAttribute('required');
            } else {
              c.setAttribute('required', 'required');
            }
          });
        });
      });
      
      // Ensure at least one category is checked
      const catCheckboxes = [document.getElementById('catVeg'), document.getElementById('catFruit'), document.getElementById('catDairy'), document.getElementById('catMeat'), document.getElementById('catBaked')];
      catCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
          const isChecked = catCheckboxes.some(c => c.checked);
          catCheckboxes.forEach(c => {
            if (isChecked) {
              c.removeAttribute('required');
            } else {
              c.setAttribute('required', 'required');
            }
          });
        });
      });
    })()
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

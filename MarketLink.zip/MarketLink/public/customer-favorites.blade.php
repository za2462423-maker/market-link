<?php
$page_title = "My Favorites - MarketLink ";
$current_page = "customer-favorites";
require_once __DIR__ . '/includes/header.php';
?>


<div class="ml-dashboard-wrapper d-flex">
  
  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="index.php" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="https://picsum.photos/60/60?random=99" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">John Smith</div>
        <div class="ml-sidebar-role">Customer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="customer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="customer-orders.php" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="customer-favorites.php" class="ml-sidebar-link active"><i class="fas fa-heart"></i> Favorites</a>
      <a href="customer-favorites.php#markets" class="ml-sidebar-link"><i class="fas fa-map-marker-alt"></i> Saved Markets</a>
      <a href="customer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications <span class="ml-sidebar-badge badge bg-danger rounded-pill">3</span></a>
      <hr class="ml-sidebar-divider">
      <a href="login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
    
    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">My Favorites</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="products.php" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <div class="ml-topbar-notif position-relative" id="notifBtn" style="cursor:pointer;">
          <i class="fas fa-bell fa-lg text-secondary"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">3</span>
        </div>
        <img src="https://picsum.photos/36/36?random=99" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">
      
      <!-- Nav Tabs -->
      <ul class="nav nav-tabs mb-4 border-0" id="favoritesTab" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active bg-transparent fw-semibold text-dark border-0 border-bottom border-success border-3" id="farmers-tab" data-bs-toggle="tab" data-bs-target="#farmers" type="button" role="tab" aria-controls="farmers" aria-selected="true">Favorite Farmers</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link bg-transparent fw-semibold text-muted border-0" id="products-tab" data-bs-toggle="tab" data-bs-target="#products" type="button" role="tab" aria-controls="products" aria-selected="false">Favorite Products</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link bg-transparent fw-semibold text-muted border-0" id="markets-tab" data-bs-toggle="tab" data-bs-target="#markets" type="button" role="tab" aria-controls="markets" aria-selected="false">Saved Markets</button>
        </li>
      </ul>

      <div class="tab-content" id="favoritesTabContent">
        
        <!-- Farmers Tab -->
        <div class="tab-pane fade show active" id="farmers" role="tabpanel" aria-labelledby="farmers-tab">
          <div class="row g-4">
            <div class="col-md-6 col-lg-4 col-xl-3">
              <div class="card border-0 shadow-sm h-100 text-center p-4">
                <div class="position-absolute top-0 end-0 p-3">
                  <button class="btn btn-sm btn-light text-danger rounded-circle"><i class="fas fa-heart"></i></button>
                </div>
                <img src="https://picsum.photos/100/100?random=1" class="rounded-circle mx-auto mb-3" alt="Farmer">
                <h5 class="fw-bold mb-1">Green Valley Farm</h5>
                <p class="text-muted small mb-3">Organic Vegetables</p>
                <button class="btn btn-outline-success btn-sm w-100">View Profile</button>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3">
              <div class="card border-0 shadow-sm h-100 text-center p-4">
                <div class="position-absolute top-0 end-0 p-3">
                  <button class="btn btn-sm btn-light text-danger rounded-circle"><i class="fas fa-heart"></i></button>
                </div>
                <img src="https://picsum.photos/100/100?random=2" class="rounded-circle mx-auto mb-3" alt="Farmer">
                <h5 class="fw-bold mb-1">Sunny Acres</h5>
                <p class="text-muted small mb-3">Dairy & Eggs</p>
                <button class="btn btn-outline-success btn-sm w-100">View Profile</button>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3">
              <div class="card border-0 shadow-sm h-100 text-center p-4">
                <div class="position-absolute top-0 end-0 p-3">
                  <button class="btn btn-sm btn-light text-danger rounded-circle"><i class="fas fa-heart"></i></button>
                </div>
                <img src="https://picsum.photos/100/100?random=3" class="rounded-circle mx-auto mb-3" alt="Farmer">
                <h5 class="fw-bold mb-1">River Fresh Market</h5>
                <p class="text-muted small mb-3">Fruits & Honey</p>
                <button class="btn btn-outline-success btn-sm w-100">View Profile</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Products Tab -->
        <div class="tab-pane fade" id="products" role="tabpanel" aria-labelledby="products-tab">
          <div class="row g-4">
            <div class="col-md-6 col-lg-4 col-xl-3">
              <div class="card border-0 shadow-sm h-100">
                <div class="position-absolute top-0 end-0 p-2 z-1">
                  <button class="btn btn-sm btn-light text-danger rounded-circle shadow-sm"><i class="fas fa-heart"></i></button>
                </div>
                <img src="https://picsum.photos/300/200?random=4" class="card-img-top" alt="Product">
                <div class="card-body">
                  <h6 class="fw-bold mb-1">Organic Tomatoes</h6>
                  <p class="text-success fw-bold mb-2">$4.50/lb</p>
                  <p class="text-muted small mb-3">By Green Valley Farm</p>
                  <button class="btn btn-success btn-sm w-100"><i class="fas fa-cart-plus me-1"></i> Add to Cart</button>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3">
              <div class="card border-0 shadow-sm h-100">
                <div class="position-absolute top-0 end-0 p-2 z-1">
                  <button class="btn btn-sm btn-light text-danger rounded-circle shadow-sm"><i class="fas fa-heart"></i></button>
                </div>
                <img src="https://picsum.photos/300/200?random=5" class="card-img-top" alt="Product">
                <div class="card-body">
                  <h6 class="fw-bold mb-1">Fresh Honey</h6>
                  <p class="text-success fw-bold mb-2">$8.00/jar</p>
                  <p class="text-muted small mb-3">By River Fresh Market</p>
                  <button class="btn btn-success btn-sm w-100"><i class="fas fa-cart-plus me-1"></i> Add to Cart</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Markets Tab -->
        <div class="tab-pane fade" id="markets" role="tabpanel" aria-labelledby="markets-tab">
          <div class="row g-4">
            <div class="col-md-6">
              <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex">
                  <img src="https://picsum.photos/120/120?random=7" class="rounded me-3 object-fit-cover" style="width:120px; height:120px;" alt="Market">
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between">
                      <h5 class="fw-bold mb-1">Downtown Farmer's Market</h5>
                      <button class="btn btn-sm text-danger p-0"><i class="fas fa-heart"></i></button>
                    </div>
                    <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt me-1"></i> 123 Market Street, City Center</p>
                    <div class="d-flex gap-2 mb-3">
                      <span class="badge bg-light text-dark border"><i class="fas fa-calendar-alt me-1"></i> Saturdays</span>
                      <span class="badge bg-light text-dark border"><i class="fas fa-clock me-1"></i> 8am - 1pm</span>
                    </div>
                    <button class="btn btn-outline-success btn-sm">View Details</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex">
                  <img src="https://picsum.photos/120/120?random=8" class="rounded me-3 object-fit-cover" style="width:120px; height:120px;" alt="Market">
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between">
                      <h5 class="fw-bold mb-1">Riverside Weekend Market</h5>
                      <button class="btn btn-sm text-danger p-0"><i class="fas fa-heart"></i></button>
                    </div>
                    <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt me-1"></i> 45 River Rd, Westside</p>
                    <div class="d-flex gap-2 mb-3">
                      <span class="badge bg-light text-dark border"><i class="fas fa-calendar-alt me-1"></i> Sundays</span>
                      <span class="badge bg-light text-dark border"><i class="fas fa-clock me-1"></i> 9am - 2pm</span>
                    </div>
                    <button class="btn btn-outline-success btn-sm">View Details</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/data.js"></script>
<script src="js/main.js"></script>
<script>
  // Simple script to handle tab styling
  const tabLinks = document.querySelectorAll('#favoritesTab .nav-link');
  tabLinks.forEach(link => {
    link.addEventListener('click', function() {
      tabLinks.forEach(l => {
        l.classList.remove('text-dark', 'border-bottom', 'border-success', 'border-3');
        l.classList.add('text-muted');
      });
      this.classList.remove('text-muted');
      this.classList.add('text-dark', 'border-bottom', 'border-success', 'border-3');
    });
  });

  // Handle URL hash for initial tab selection
  window.addEventListener('DOMContentLoaded', () => {
    if(window.location.hash) {
      const targetBtn = document.querySelector(`button[data-bs-target="${window.location.hash}"]`);
      if(targetBtn) {
        const tab = new bootstrap.Tab(targetBtn);
        tab.show();
        targetBtn.click(); // trigger style change
      }
    }
  });

  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

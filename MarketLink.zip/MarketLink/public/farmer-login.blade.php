<?php
$page_title = "MarketLink - Farmer Login ";
$current_page = "farmer-login";
require_once __DIR__ . '/includes/header.php';
?>

  <div class="split-layout">
    <div class="split-left">
      <div class="mb-auto">
        <h2 class="fw-bold"><i class="fas fa-seedling"></i> MarketLink</h2>
        <span class="badge bg-light text-success mb-3 fs-6">Farmer Portal</span>
      </div>
      <div>
        <h1 class="display-5 fw-bold mb-3">Manage your stall, products, and orders</h1>
        <p class="lead mb-4">Join hundreds of local farmers connecting directly with customers.</p>
        <ul class="feature-list">
          <li><i class="fas fa-check-circle"></i> Reach more local customers</li>
          <li><i class="fas fa-check-circle"></i> Manage inventory easily</li>
          <li><i class="fas fa-check-circle"></i> Streamline your pickup orders</li>
          <li><i class="fas fa-check-circle"></i> Track sales and grow your business</li>
        </ul>
      </div>
      <div class="mt-auto pt-5">
        <p class="mb-0 text-white-50">&copy; 2026 MarketLink. All rights reserved.</p>
      </div>
    </div>
    
    <div class="split-right">
      <div class="auth-form-container">
        <div class="text-center mb-4 d-md-none">
          <h2 class="fw-bold text-success"><i class="fas fa-seedling"></i> MarketLink</h2>
          <span class="badge bg-success mb-3">Farmer Portal</span>
        </div>
        
        <h3 class="fw-bold mb-1">Welcome Back, Farmer</h3>
        <p class="text-muted mb-4">Please enter your details to sign in.</p>
        
        <form action="farmer-dashboard.php" method="GET">
          <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="email" placeholder="farmer@example.com" required>
          </div>
          <div class="mb-3">
            <div class="d-flex justify-content-between">
              <label for="password" class="form-label">Password</label>
              <a href="#" class="text-success text-decoration-none small">Forgot password?</a>
            </div>
            <input type="password" class="form-control" id="password" placeholder="••••••••" required>
          </div>
          <div class="mb-4 form-check">
            <input type="checkbox" class="form-check-input" id="rememberMe">
            <label class="form-check-label text-muted" for="rememberMe">Remember me for 30 days</label>
          </div>
          <button type="submit" class="btn btn-farmer w-100 py-2 mb-3 fw-semibold">Sign In</button>
          
          <p class="text-center text-muted">
            Don't have a farmer account? <a href="farmer-register.php" class="text-success text-decoration-none fw-semibold">Register as Farmer</a>
          </p>
        </form>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

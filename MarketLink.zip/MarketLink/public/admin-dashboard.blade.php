<?php
$page_title = "Admin Dashboard - MarketLink ";
$current_page = "admin-dashboard";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <!-- Sidebar -->
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link active"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Dashboard Overview</h4>
        </div>
        <div class="d-flex align-items-center gap-3">
          <span class="text-muted"><i class="far fa-calendar-alt"></i> Sep 24, 2026</span>
          <button class="btn btn-outline-success btn-sm"><i class="fas fa-download"></i> Report</button>
        </div>
      </div>

      <div class="ml-admin-content">
        <!-- Stats Row -->
        <div class="row g-4 mb-4">
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-tractor"></i></div>
              <div class="admin-stat-info">
                <p>Total Farmers</p>
                <h3>48</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Customers</p>
                <h3>1,240</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-store"></i></div>
              <div class="admin-stat-info">
                <p>Total Markets</p>
                <h3>12</h3>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-purple"><i class="fas fa-shopping-bag"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3>3,582</h3>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-gradient"><i class="fas fa-chart-line"></i></div>
              <div class="admin-stat-info">
                <p>Platform Revenue</p>
                <h3>PKR 2.4M</h3>
              </div>
            </div>
          </div>
        </div>

        <!-- Charts Row -->
        <div class="row g-4 mb-4">
          <div class="col-lg-8">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Monthly Orders 2026</h5>
              </div>
              <div class="admin-card-body">
                <div class="simple-bar-chart">
                  <!-- Bars -->
                  <div class="bar-col"><div class="bar" style="height: 40%;"></div><div class="bar-label">Jan</div></div>
                  <div class="bar-col"><div class="bar" style="height: 50%;"></div><div class="bar-label">Feb</div></div>
                  <div class="bar-col"><div class="bar" style="height: 45%;"></div><div class="bar-label">Mar</div></div>
                  <div class="bar-col"><div class="bar" style="height: 60%;"></div><div class="bar-label">Apr</div></div>
                  <div class="bar-col"><div class="bar" style="height: 55%;"></div><div class="bar-label">May</div></div>
                  <div class="bar-col"><div class="bar" style="height: 70%;"></div><div class="bar-label">Jun</div></div>
                  <div class="bar-col"><div class="bar" style="height: 85%;"></div><div class="bar-label">Jul</div></div>
                  <div class="bar-col"><div class="bar" style="height: 95%;"></div><div class="bar-label">Aug</div></div>
                  <div class="bar-col"><div class="bar" style="height: 80%;"></div><div class="bar-label">Sep</div></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Revenue by Category</h5>
              </div>
              <div class="admin-card-body text-center">
                <div class="pie-chart"></div>
                <div class="pie-legend text-start d-inline-block mt-4">
                  <div class="pie-legend-item"><div class="pie-color" style="background:#4CAF50"></div> Vegetables (35%)</div>
                  <div class="pie-legend-item"><div class="pie-color" style="background:#2196F3"></div> Fruits (25%)</div>
                  <div class="pie-legend-item"><div class="pie-color" style="background:#FFC107"></div> Dairy (20%)</div>
                  <div class="pie-legend-item"><div class="pie-color" style="background:#9C27B0"></div> Baked (15%)</div>
                  <div class="pie-legend-item"><div class="pie-color" style="background:#9E9E9E"></div> Other (5%)</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Tables Row -->
        <div class="row g-4 mb-4">
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Recent Registrations</h5>
                <a href="#" class="btn btn-sm btn-light">View All</a>
              </div>
              <div class="table-responsive">
                <table class="table admin-table table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Type</th>
                      <th>Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Ali Khan</td>
                      <td><span class="text-success"><i class="fas fa-tractor"></i> Farmer</span></td>
                      <td>Sep 24, 2026</td>
                      <td><span class="badge badge-pending">Pending</span></td>
                    </tr>
                    <tr>
                      <td>Sarah Ahmed</td>
                      <td><span class="text-primary"><i class="fas fa-user"></i> Customer</span></td>
                      <td>Sep 23, 2026</td>
                      <td><span class="badge badge-active">Active</span></td>
                    </tr>
                    <tr>
                      <td>Green Valley Farms</td>
                      <td><span class="text-success"><i class="fas fa-tractor"></i> Farmer</span></td>
                      <td>Sep 22, 2026</td>
                      <td><span class="badge badge-approved">Approved</span></td>
                    </tr>
                    <tr>
                      <td>Zain Malik</td>
                      <td><span class="text-primary"><i class="fas fa-user"></i> Customer</span></td>
                      <td>Sep 21, 2026</td>
                      <td><span class="badge badge-active">Active</span></td>
                    </tr>
                    <tr>
                      <td>Fresh Dairy Co.</td>
                      <td><span class="text-success"><i class="fas fa-tractor"></i> Farmer</span></td>
                      <td>Sep 20, 2026</td>
                      <td><span class="badge badge-approved">Approved</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Recent Orders</h5>
                <a href="admin-orders.php" class="btn btn-sm btn-light">View All</a>
              </div>
              <div class="table-responsive">
                <table class="table admin-table table-hover">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>#ORD-8902</td>
                      <td>Fatima Ali</td>
                      <td>PKR 1,250</td>
                      <td><span class="badge badge-pending">Pending</span></td>
                    </tr>
                    <tr>
                      <td>#ORD-8901</td>
                      <td>Usman Tariq</td>
                      <td>PKR 3,400</td>
                      <td><span class="badge badge-active">Completed</span></td>
                    </tr>
                    <tr>
                      <td>#ORD-8900</td>
                      <td>Aisha Khan</td>
                      <td>PKR 850</td>
                      <td><span class="badge badge-active">Completed</span></td>
                    </tr>
                    <tr>
                      <td>#ORD-8899</td>
                      <td>Bilal Qureshi</td>
                      <td>PKR 5,100</td>
                      <td><span class="badge badge-pending">Pending</span></td>
                    </tr>
                    <tr>
                      <td>#ORD-8898</td>
                      <td>Sana Hameed</td>
                      <td>PKR 2,200</td>
                      <td><span class="badge badge-removed">Cancelled</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- Active Farmers -->
        <h5 class="mb-3 fw-bold">Top Performing Farmers</h5>
        <div class="row g-4">
          <div class="col-md-3">
            <div class="mini-farmer-card">
              <img src="https://picsum.photos/100/100?random=11" alt="Farmer">
              <h6>Ahmad's Organics</h6>
              <div class="rating"><i class="fas fa-star"></i> 4.9 (120)</div>
              <p>156 Orders</p>
            </div>
          </div>
          <div class="col-md-3">
            <div class="mini-farmer-card">
              <img src="https://picsum.photos/100/100?random=12" alt="Farmer">
              <h6>Green Fields</h6>
              <div class="rating"><i class="fas fa-star"></i> 4.8 (95)</div>
              <p>134 Orders</p>
            </div>
          </div>
          <div class="col-md-3">
            <div class="mini-farmer-card">
              <img src="https://picsum.photos/100/100?random=13" alt="Farmer">
              <h6>Fresh Harvest</h6>
              <div class="rating"><i class="fas fa-star"></i> 4.9 (210)</div>
              <p>289 Orders</p>
            </div>
          </div>
          <div class="col-md-3">
            <div class="mini-farmer-card">
              <img src="https://picsum.photos/100/100?random=14" alt="Farmer">
              <h6>Pure Dairy Farms</h6>
              <div class="rating"><i class="fas fa-star"></i> 4.7 (88)</div>
              <p>112 Orders</p>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "Order Details - MarketLink ";
$current_page = "order-details";
require_once __DIR__ . '/includes/header.php';
?>


<div class="ml-dashboard-wrapper d-flex">
  
  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="index.php" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="https://picsum.photos/60/60?random=99" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">John Smith</div>
        <div class="ml-sidebar-role">Customer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="customer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="customer-orders.php" class="ml-sidebar-link active"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="customer-favorites.php" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
      <a href="customer-favorites.php#markets" class="ml-sidebar-link"><i class="fas fa-map-marker-alt"></i> Saved Markets</a>
      <a href="customer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications <span class="ml-sidebar-badge badge bg-danger rounded-pill">3</span></a>
      <hr class="ml-sidebar-divider">
      <a href="login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
    
    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">Order Details</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="products.php" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <div class="ml-topbar-notif position-relative" id="notifBtn" style="cursor:pointer;">
          <i class="fas fa-bell fa-lg text-secondary"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">3</span>
        </div>
        <img src="https://picsum.photos/36/36?random=99" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">
      
      <!-- Breadcrumb -->
      <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="customer-dashboard.php" class="text-success text-decoration-none">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="customer-orders.php" class="text-success text-decoration-none">Orders</a></li>
          <li class="breadcrumb-item active" aria-current="page">#ORD-001</li>
        </ol>
      </nav>

      <div class="row g-4">
        <!-- Left Column -->
        <div class="col-lg-8">
          
          <!-- Order Info Card -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom pt-4 pb-3">
              <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">Order #ORD-001</h5>
                <span class="badge bg-secondary fs-6">Placed</span>
              </div>
              <p class="text-muted small mb-0 mt-2">Placed on October 12, 2026 at 10:30 AM</p>
            </div>
            
            <div class="card-body">
              <h6 class="fw-bold mb-3">Items (2)</h6>
              <div class="table-responsive">
                <table class="table align-middle">
                  <thead class="bg-light">
                    <tr>
                      <th>Product</th>
                      <th>Qty</th>
                      <th>Unit Price</th>
                      <th class="text-end">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div class="d-flex align-items-center">
                          <img src="https://picsum.photos/50/50?random=4" class="rounded me-3" alt="Tomatoes">
                          <div>
                            <h6 class="mb-0 fw-semibold">Organic Tomatoes</h6>
                            <small class="text-muted">Per lb</small>
                          </div>
                        </div>
                      </td>
                      <td>2</td>
                      <td>$4.50</td>
                      <td class="text-end fw-medium">$9.00</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="d-flex align-items-center">
                          <img src="https://picsum.photos/50/50?random=5" class="rounded me-3" alt="Carrots">
                          <div>
                            <h6 class="mb-0 fw-semibold">Fresh Carrots</h6>
                            <small class="text-muted">Bunch</small>
                          </div>
                        </div>
                      </td>
                      <td>3</td>
                      <td>$3.00</td>
                      <td class="text-end fw-medium">$9.00</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Order Status Timeline -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom pt-4 pb-3">
              <h5 class="mb-0 fw-bold">Order Status</h5>
            </div>
            <div class="card-body py-4">
              <div class="ml-timeline">
                <div class="ml-timeline-step completed active">
                  <div class="ml-timeline-step-title">Order Placed</div>
                  <div class="ml-timeline-step-desc">October 12, 2026 - 10:30 AM</div>
                </div>
                <div class="ml-timeline-step">
                  <div class="ml-timeline-step-title">Accepted by Farmer</div>
                  <div class="ml-timeline-step-desc">Waiting for confirmation</div>
                </div>
                <div class="ml-timeline-step">
                  <div class="ml-timeline-step-title">Ready for Pickup</div>
                  <div class="ml-timeline-step-desc">Farmer will prepare your items</div>
                </div>
                <div class="ml-timeline-step mb-0">
                  <div class="ml-timeline-step-title">Completed</div>
                  <div class="ml-timeline-step-desc">Order picked up successfully</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Pickup Info & Notes -->
          <div class="row g-4 mb-4">
            <div class="col-md-6">
              <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                  <h6 class="fw-bold mb-3"><i class="fas fa-map-marker-alt text-success me-2"></i>Pickup Information</h6>
                  <p class="mb-1 fw-medium">Downtown Farmer's Market</p>
                  <p class="text-muted small mb-2">123 Market Street, City Center</p>
                  <hr>
                  <p class="mb-1"><i class="fas fa-calendar-alt text-muted me-2"></i> <strong>Oct 15, 2026</strong></p>
                  <p class="mb-0"><i class="fas fa-clock text-muted me-2"></i> 9:00 AM - 12:00 PM</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                  <h6 class="fw-bold mb-3"><i class="fas fa-sticky-note text-warning me-2"></i>Special Notes</h6>
                  <p class="text-muted small mb-0 fst-italic">"Please make sure the tomatoes are not too ripe. I will be arriving closer to 11:30 AM."</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Actions -->
          <div class="d-flex gap-3">
            <button class="btn btn-outline-secondary">Modify Order</button>
            <button class="btn btn-danger">Cancel Order</button>
          </div>

        </div>

        <!-- Right Column -->
        <div class="col-lg-4">
          
          <!-- Summary Card -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom pt-4 pb-3">
              <h5 class="mb-0 fw-bold">Order Summary</h5>
            </div>
            <div class="card-body">
              <div class="d-flex justify-content-between mb-2">
                <span class="text-muted">Subtotal</span>
                <span>$18.00</span>
              </div>
              <div class="d-flex justify-content-between mb-2">
                <span class="text-muted">Service Fee</span>
                <span>$1.50</span>
              </div>
              <div class="d-flex justify-content-between mb-3">
                <span class="text-muted">Taxes</span>
                <span>$0.90</span>
              </div>
              <hr>
              <div class="d-flex justify-content-between align-items-center">
                <span class="fw-bold fs-5">Total</span>
                <span class="fw-bold fs-5 text-success">$20.40</span>
              </div>
              <div class="mt-3">
                <span class="badge bg-success bg-opacity-10 text-success p-2 w-100 rounded text-start"><i class="fas fa-check-circle me-1"></i> Payment due at pickup</span>
              </div>
            </div>
          </div>

          <!-- Farmer Card -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
              <h6 class="fw-bold text-muted mb-3 text-uppercase" style="font-size:0.75rem;">Farmer Information</h6>
              <div class="d-flex align-items-center mb-3">
                <img src="https://picsum.photos/60/60?random=1" class="rounded-circle me-3" alt="Farmer">
                <div>
                  <h6 class="mb-0 fw-bold">Green Valley Farm</h6>
                  <small class="text-muted">Stall #42</small>
                </div>
              </div>
              <button class="btn btn-sm btn-outline-success w-100"><i class="fas fa-comment-dots me-1"></i> Contact Farmer</button>
            </div>
          </div>

          <!-- Customer Card -->
          <div class="card border-0 shadow-sm">
            <div class="card-body">
              <h6 class="fw-bold text-muted mb-3 text-uppercase" style="font-size:0.75rem;">Your Information</h6>
              <div class="mb-2">
                <i class="fas fa-user text-muted me-2 w-15px"></i> John Smith
              </div>
              <div class="mb-2">
                <i class="fas fa-envelope text-muted me-2 w-15px"></i> john.smith@example.com
              </div>
              <div class="mb-0">
                <i class="fas fa-phone text-muted me-2 w-15px"></i> (555) 123-4567
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/data.js"></script>
<script src="js/main.js"></script>
<script>
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

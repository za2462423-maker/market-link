<?php
$page_title = "MarketLink - Farmer Reviews ";
$current_page = "farmer-reviews";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="index.php" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="https://picsum.photos/60/60?random=55" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">Green Valley Farm</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="farmer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="farmer-profile-edit.php" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="farmer-add-product.php" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="farmer-orders.php" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="farmer-reviews.php" class="ml-sidebar-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <a href="farmer-login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative">
            <i class="fas fa-bell"></i>
          </button>
          <img src="https://picsum.photos/40/40?random=55" alt="User" class="rounded-circle border">
        </div>
      </div>

      <div class="dashboard-content">
        <h2 class="h4 mb-4 fw-bold">Customer Reviews</h2>

        <div class="row mb-5">
          <div class="col-lg-6">
            <div class="rating-summary-card">
              <h5 class="fw-bold mb-4">Overall Rating</h5>
              <div class="d-flex align-items-center gap-4">
                <div class="text-center">
                  <div class="overall-rating">4.8</div>
                  <div class="text-warning my-2 fs-5">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                  </div>
                  <div class="text-muted small">Based on 42 reviews</div>
                </div>
                
                <div class="flex-grow-1 border-start ps-4">
                  <div class="star-bar-row">
                    <span class="star-label">5 <i class="fas fa-star text-warning"></i></span>
                    <div class="progress"><div class="progress-bar" style="width: 80%"></div></div>
                    <span class="small text-muted w-25 text-end">34</span>
                  </div>
                  <div class="star-bar-row">
                    <span class="star-label">4 <i class="fas fa-star text-warning"></i></span>
                    <div class="progress"><div class="progress-bar" style="width: 15%"></div></div>
                    <span class="small text-muted w-25 text-end">6</span>
                  </div>
                  <div class="star-bar-row">
                    <span class="star-label">3 <i class="fas fa-star text-warning"></i></span>
                    <div class="progress"><div class="progress-bar" style="width: 5%"></div></div>
                    <span class="small text-muted w-25 text-end">2</span>
                  </div>
                  <div class="star-bar-row">
                    <span class="star-label">2 <i class="fas fa-star text-warning"></i></span>
                    <div class="progress"><div class="progress-bar" style="width: 0%"></div></div>
                    <span class="small text-muted w-25 text-end">0</span>
                  </div>
                  <div class="star-bar-row mb-0">
                    <span class="star-label">1 <i class="fas fa-star text-warning"></i></span>
                    <div class="progress"><div class="progress-bar" style="width: 0%"></div></div>
                    <span class="small text-muted w-25 text-end">0</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-4">
          <h5 class="fw-bold m-0">Recent Reviews</h5>
          <select class="form-select w-auto">
            <option value="all">All Reviews</option>
            <option value="unreplied">Not Replied</option>
            <option value="replied">Replied</option>
          </select>
        </div>

        <!-- Review 1: Not replied -->
        <div class="review-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="d-flex gap-3">
              <img src="https://picsum.photos/40/40?random=301" alt="Customer" class="reviewer-avatar">
              <div>
                <h6 class="mb-1 fw-bold">Ayesha M.</h6>
                <div class="text-warning small mb-1">
                  <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                </div>
                <div class="review-product"><i class="fas fa-box text-muted me-1"></i> Fresh Red Tomatoes</div>
              </div>
            </div>
            <span class="text-muted small">2 days ago</span>
          </div>
          <p class="review-text">Absolutely the freshest tomatoes I've bought all year! So juicy and full of flavor. The pickup process was super smooth and friendly. Will definitely buy again.</p>
          <div class="mt-3 text-end" id="replyArea-1">
            <button class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#replyModal" data-reviewer="Ayesha M."><i class="fas fa-reply"></i> Reply to Customer</button>
          </div>
        </div>

        <!-- Review 2: Replied -->
        <div class="review-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="d-flex gap-3">
              <img src="https://picsum.photos/40/40?random=302" alt="Customer" class="reviewer-avatar">
              <div>
                <h6 class="mb-1 fw-bold">Hamza S.</h6>
                <div class="text-warning small mb-1">
                  <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i>
                </div>
                <div class="review-product"><i class="fas fa-box text-muted me-1"></i> Farm Fresh Milk</div>
              </div>
            </div>
            <span class="text-muted small">1 week ago</span>
          </div>
          <p class="review-text">Great quality milk, tastes much better than store-bought. It would be great if you could offer it in glass bottles instead of plastic.</p>
          
          <div class="reply-box">
            <div class="d-flex justify-content-between mb-1">
              <span class="fw-bold small text-success">Your Reply</span>
              <span class="text-muted small">6 days ago</span>
            </div>
            <p class="mb-0 small">Hi Hamza! Thank you for the feedback. We are actually transitioning to a glass bottle return program next month. Look out for an announcement soon!</p>
          </div>
        </div>

        <!-- Review 3: Not replied -->
        <div class="review-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="d-flex gap-3">
              <img src="https://picsum.photos/40/40?random=303" alt="Customer" class="reviewer-avatar">
              <div>
                <h6 class="mb-1 fw-bold">Nida K.</h6>
                <div class="text-warning small mb-1">
                  <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                </div>
                <div class="review-product"><i class="fas fa-box text-muted me-1"></i> Organic Eggs</div>
              </div>
            </div>
            <span class="text-muted small">2 weeks ago</span>
          </div>
          <p class="review-text">Perfect! Eggs are fresh and the yolks are so vibrant. Have been a regular customer for 3 months now.</p>
          <div class="mt-3 text-end" id="replyArea-3">
            <button class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#replyModal" data-reviewer="Nida K."><i class="fas fa-reply"></i> Reply to Customer</button>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Reply Modal -->
  <div class="modal fade" id="replyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fw-bold">Reply to <span id="modalReviewerName" class="text-success">Customer</span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label fw-medium">Your Message</label>
            <textarea class="form-control" rows="4" placeholder="Type your response here. This will be publicly visible under the review."></textarea>
            <small class="text-muted d-block mt-2">Keep responses professional and courteous.</small>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-success" data-bs-dismiss="modal">Submit Reply</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');

      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.add('show');
      });

      sidebarClose.addEventListener('click', () => {
        sidebar.classList.remove('show');
      });

      // Pass reviewer name to modal
      const replyModal = document.getElementById('replyModal');
      replyModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const reviewer = button.getAttribute('data-reviewer');
        const modalNameSpan = replyModal.querySelector('#modalReviewerName');
        modalNameSpan.textContent = reviewer;
      });
    });
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

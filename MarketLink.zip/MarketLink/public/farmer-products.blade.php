<?php
$page_title = "MarketLink - Farmer Products ";
$current_page = "farmer-products";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="index.php" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="https://picsum.photos/60/60?random=55" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">Green Valley Farm</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="farmer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="farmer-profile-edit.php" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="farmer-products.php" class="ml-sidebar-link active"><i class="fas fa-box"></i> Products</a>
        <a href="farmer-add-product.php" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="farmer-products.php" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="farmer-orders.php" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="farmer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <a href="#" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <a href="farmer-login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative">
            <i class="fas fa-bell"></i>
          </button>
          <img src="https://picsum.photos/40/40?random=55" alt="User" class="rounded-circle border">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <h2 class="h4 mb-0 fw-bold">Products & Inventory</h2>
          <a href="farmer-add-product.php" class="btn btn-success"><i class="fas fa-plus"></i> Add New Product</a>
        </div>

        <div class="stats-bar">
          <div class="stat-item">
            <span class="stat-label">Total Products</span>
            <span class="stat-value">24</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-success">In Stock</span>
            <span class="stat-value text-success">21</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-warning">Low Stock</span>
            <span class="stat-value text-warning">2</span>
          </div>
          <div class="stat-item">
            <span class="stat-label text-danger">Out of Stock</span>
            <span class="stat-value text-danger">1</span>
          </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3">
          <div class="card-body border-bottom p-3">
            <div class="row g-3">
              <div class="col-md-4">
                <div class="input-group">
                  <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                  <input type="text" class="form-control border-start-0 ps-0" placeholder="Search products...">
                </div>
              </div>
              <div class="col-md-3">
                <select class="form-select">
                  <option value="">All Categories</option>
                  <option value="veg">Vegetables</option>
                  <option value="fruit">Fruits</option>
                  <option value="dairy">Dairy</option>
                </select>
              </div>
              <div class="col-md-3">
                <select class="form-select">
                  <option value="">All Statuses</option>
                  <option value="in_stock">In Stock</option>
                  <option value="low_stock">Low Stock</option>
                  <option value="out_stock">Out of Stock</option>
                </select>
              </div>
            </div>
          </div>
          
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th scope="col" class="ps-4">#</th>
                  <th scope="col">Product</th>
                  <th scope="col">Category</th>
                  <th scope="col">Price</th>
                  <th scope="col">Stock</th>
                  <th scope="col">Status</th>
                  <th scope="col" class="text-end pe-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="ps-4 text-muted">1</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=201" class="product-img" alt="Product">
                      <span class="fw-medium">Fresh Red Tomatoes</span>
                    </div>
                  </td>
                  <td>Vegetables</td>
                  <td>PKR 150 / kg</td>
                  <td><span class="fw-medium">45</span> kg</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1" title="Edit"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td class="ps-4 text-muted">2</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=202" class="product-img" alt="Product">
                      <span class="fw-medium">Organic Onions</span>
                    </div>
                  </td>
                  <td>Vegetables</td>
                  <td>PKR 120 / kg</td>
                  <td><span class="fw-medium">30</span> kg</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr class="low-stock-row">
                  <td class="ps-4 text-muted">3</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=203" class="product-img" alt="Product">
                      <span class="fw-medium">Fresh Carrots</span>
                    </div>
                  </td>
                  <td>Vegetables</td>
                  <td>PKR 80 / kg</td>
                  <td><span class="fw-bold text-warning">4</span> kg</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td class="ps-4 text-muted">4</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=204" class="product-img" alt="Product">
                      <span class="fw-medium">Sweet Apples</span>
                    </div>
                  </td>
                  <td>Fruits</td>
                  <td>PKR 300 / kg</td>
                  <td><span class="fw-medium">20</span> kg</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr class="out-stock-row">
                  <td class="ps-4 text-muted">5</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=205" class="product-img" alt="Product">
                      <span class="fw-medium">Organic Cabbage</span>
                    </div>
                  </td>
                  <td>Vegetables</td>
                  <td>PKR 100 / piece</td>
                  <td><span class="fw-bold text-danger">0</span> piece</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch">
                      <label class="form-check-label text-muted small">Sold Out</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td class="ps-4 text-muted">6</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=206" class="product-img" alt="Product">
                      <span class="fw-medium">Farm Fresh Milk</span>
                    </div>
                  </td>
                  <td>Dairy</td>
                  <td>PKR 200 / litre</td>
                  <td><span class="fw-medium">15</span> litre</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td class="ps-4 text-muted">7</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=207" class="product-img" alt="Product">
                      <span class="fw-medium">Free Range Eggs</span>
                    </div>
                  </td>
                  <td>Dairy</td>
                  <td>PKR 350 / dozen</td>
                  <td><span class="fw-medium">12</span> dozen</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr class="low-stock-row">
                  <td class="ps-4 text-muted">8</td>
                  <td>
                    <div class="d-flex align-items-center gap-3">
                      <img src="https://picsum.photos/50/50?random=208" class="product-img" alt="Product">
                      <span class="fw-medium">Green Bell Peppers</span>
                    </div>
                  </td>
                  <td>Vegetables</td>
                  <td>PKR 250 / kg</td>
                  <td><span class="fw-bold text-warning">2</span> kg</td>
                  <td>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" checked>
                      <label class="form-check-label text-success small">Available</label>
                    </div>
                  </td>
                  <td class="text-end pe-4">
                    <button class="btn btn-sm btn-light border text-primary me-1"><i class="fas fa-pen"></i></button>
                    <button class="btn btn-sm btn-light border text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center">
            <span class="text-muted small">Showing 1 to 8 of 24 products</span>
            <nav aria-label="Page navigation">
              <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">Next</a></li>
              </ul>
            </nav>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Delete Modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header border-0">
          <h5 class="modal-title fw-bold">Delete Product</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center py-4">
          <i class="fas fa-exclamation-circle text-danger mb-3" style="font-size: 3rem;"></i>
          <p class="fs-5">Are you sure you want to delete this product?</p>
          <p class="text-muted small mb-0">This action cannot be undone and will remove the product from your online stall.</p>
        </div>
        <div class="modal-footer border-0 d-flex justify-content-center">
          <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger px-4">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');

      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.add('show');
      });

      sidebarClose.addEventListener('click', () => {
        sidebar.classList.remove('show');
      });

      // Toggle status label text
      const switches = document.querySelectorAll('.form-switch input[type="checkbox"]');
      switches.forEach(sw => {
        sw.addEventListener('change', (e) => {
          const label = e.target.nextElementSibling;
          if(e.target.checked) {
            label.textContent = "Available";
            label.className = "form-check-label text-success small";
          } else {
            label.textContent = "Sold Out";
            label.className = "form-check-label text-muted small";
          }
        });
      });
    });
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

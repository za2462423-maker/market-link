<?php
$page_title = "Admin Farmers - MarketLink ";
$current_page = "admin-farmers";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <!-- Sidebar -->
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link active"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Manage Farmers</h4>
        </div>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-outline-secondary btn-sm"><i class="fas fa-file-export"></i> Export</button>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Farmers</p>
                <h3>48</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info">
                <p>Approved</p>
                <h3>35</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-clock"></i></div>
              <div class="admin-stat-info">
                <p>Pending</p>
                <h3>8</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon" style="background:#f8d7da; color:#721c24"><i class="fas fa-ban"></i></div>
              <div class="admin-stat-info">
                <p>Suspended</p>
                <h3>5</h3>
              </div>
            </div>
          </div>
        </div>

        <!-- Filters & Search -->
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex flex-wrap gap-3 align-items-center justify-content-between">
            <div class="d-flex gap-3 flex-grow-1" style="max-width: 500px;">
              <input type="text" class="form-control" placeholder="Search farmers by name, stall, or email...">
            </div>
            <div class="d-flex gap-3">
              <select class="form-select w-auto">
                <option value="">All Statuses</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Table -->
        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Farmer</th>
                  <th>Stall Name</th>
                  <th>Markets</th>
                  <th>Products</th>
                  <th>Orders</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="farmerTableBody">
                <!-- Rows will be rendered by JS, but providing HTML structure -->
                <tr>
                  <td>1</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=21" alt="Avatar">
                      <div>
                        <strong>Ali Khan</strong><br>
                        <small class="text-muted">ali@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Green Valley Farms</td>
                  <td>2</td>
                  <td>15</td>
                  <td>120</td>
                  <td><span class="badge badge-approved" id="status-1">Approved</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Suspend"><i class="fas fa-ban"></i></button>
                    <button class="btn btn-sm btn-light text-primary" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=22" alt="Avatar">
                      <div>
                        <strong>Usman Tariq</strong><br>
                        <small class="text-muted">usman@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Fresh Harvest Stall</td>
                  <td>1</td>
                  <td>8</td>
                  <td>0</td>
                  <td><span class="badge badge-pending" id="status-2">Pending</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" onclick="approveFarmer(2)" title="Approve"><i class="fas fa-check"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Reject"><i class="fas fa-times"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=23" alt="Avatar">
                      <div>
                        <strong>Ayesha Siddiqa</strong><br>
                        <small class="text-muted">ayesha@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Organic Veggies</td>
                  <td>3</td>
                  <td>24</td>
                  <td>340</td>
                  <td><span class="badge badge-suspended" id="status-3">Suspended</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" onclick="approveFarmer(3)" title="Restore"><i class="fas fa-undo"></i></button>
                    <button class="btn btn-sm btn-light text-primary" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=24" alt="Avatar">
                      <div>
                        <strong>Kamran Akmal</strong><br>
                        <small class="text-muted">kamran@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Kamran Dairy</td>
                  <td>1</td>
                  <td>5</td>
                  <td>88</td>
                  <td><span class="badge badge-approved">Approved</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-ban"></i></button>
                    <button class="btn btn-sm btn-light text-primary"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=25" alt="Avatar">
                      <div>
                        <strong>Zahid Hussain</strong><br>
                        <small class="text-muted">zahid@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Zahid Fruits</td>
                  <td>2</td>
                  <td>12</td>
                  <td>210</td>
                  <td><span class="badge badge-approved">Approved</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-ban"></i></button>
                    <button class="btn btn-sm btn-light text-primary"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=26" alt="Avatar">
                      <div>
                        <strong>Bilal Ahmed</strong><br>
                        <small class="text-muted">bilal@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Ahmed Organics</td>
                  <td>1</td>
                  <td>0</td>
                  <td>0</td>
                  <td><span class="badge badge-pending" id="status-6">Pending</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" onclick="approveFarmer(6)"><i class="fas fa-check"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-times"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=27" alt="Avatar">
                      <div>
                        <strong>Sanaullah</strong><br>
                        <small class="text-muted">sanaullah@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Sanaullah Farms</td>
                  <td>1</td>
                  <td>18</td>
                  <td>95</td>
                  <td><span class="badge badge-approved">Approved</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-ban"></i></button>
                    <button class="btn btn-sm btn-light text-primary"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=28" alt="Avatar">
                      <div>
                        <strong>Nadeem Shah</strong><br>
                        <small class="text-muted">nadeem@example.com</small>
                      </div>
                    </div>
                  </td>
                  <td>Shah Bakery</td>
                  <td>2</td>
                  <td>8</td>
                  <td>45</td>
                  <td><span class="badge badge-approved">Approved</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#farmerModal"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-ban"></i></button>
                    <button class="btn btn-sm btn-light text-primary"><i class="fas fa-pencil-alt"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- View Farmer Modal -->
  <div class="modal fade" id="farmerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Farmer Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="d-flex gap-4 mb-4">
            <img src="https://picsum.photos/100/100?random=21" alt="Farmer" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
            <div>
              <h4 class="mb-1">Ali Khan</h4>
              <p class="text-muted mb-2">Green Valley Farms</p>
              <p class="mb-1"><i class="fas fa-envelope text-muted"></i> ali@example.com</p>
              <p class="mb-0"><i class="fas fa-phone text-muted"></i> +92 300 1234567</p>
            </div>
            <div class="ms-auto text-end">
              <span class="badge badge-approved mb-2">Approved</span>
              <p class="text-muted small">Joined: Jan 15, 2026</p>
              <a href="farmer-profile.php" class="btn btn-outline-success btn-sm mt-2">View Public Profile</a>
            </div>
          </div>
          
          <div class="row g-3 mb-4">
            <div class="col-4">
              <div class="border rounded p-3 text-center bg-light">
                <h3 class="mb-0">15</h3>
                <small class="text-muted">Products</small>
              </div>
            </div>
            <div class="col-4">
              <div class="border rounded p-3 text-center bg-light">
                <h3 class="mb-0">120</h3>
                <small class="text-muted">Total Orders</small>
              </div>
            </div>
            <div class="col-4">
              <div class="border rounded p-3 text-center bg-light">
                <h3 class="mb-0">4.8</h3>
                <small class="text-muted">Rating</small>
              </div>
            </div>
          </div>
          
          <h6 class="fw-bold">Required Documents</h6>
          <ul class="list-group list-group-flush mb-4">
            <li class="list-group-item d-flex justify-content-between align-items-center">
              CNIC Copy (Front & Back) <span class="badge bg-success"><i class="fas fa-check"></i> Verified</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Proof of Farming / Stall <span class="badge bg-success"><i class="fas fa-check"></i> Verified</span>
            </li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger">Suspend Farmer</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    function approveFarmer(id) {
      const badge = document.getElementById('status-' + id);
      if(badge) {
        badge.className = 'badge badge-approved';
        badge.innerText = 'Approved';
      }
    }
  </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

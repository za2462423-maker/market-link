<?php
$page_title = "My Orders - MarketLink ";
$current_page = "customer-orders";
require_once __DIR__ . '/includes/header.php';
?>


<div class="ml-dashboard-wrapper d-flex">
  
  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="index.php" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="https://picsum.photos/60/60?random=99" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">John Smith</div>
        <div class="ml-sidebar-role">Customer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="customer-dashboard.php" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="customer-orders.php" class="ml-sidebar-link active"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="customer-favorites.php" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
      <a href="customer-favorites.php#markets" class="ml-sidebar-link"><i class="fas fa-map-marker-alt"></i> Saved Markets</a>
      <a href="customer-reviews.php" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <a href="#" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications <span class="ml-sidebar-badge badge bg-danger rounded-pill">3</span></a>
      <hr class="ml-sidebar-divider">
      <a href="login.php" class="ml-sidebar-link ml-sidebar-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
    
    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">My Orders</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="products.php" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <div class="ml-topbar-notif position-relative" id="notifBtn" style="cursor:pointer;">
          <i class="fas fa-bell fa-lg text-secondary"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">3</span>
        </div>
        <img src="https://picsum.photos/36/36?random=99" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">
      
      <!-- Filter Bar -->
      <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
          <form class="row g-3 align-items-end">
            <div class="col-md-3">
              <label class="form-label small text-muted mb-1">Search Orders</label>
              <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="fas fa-search text-muted"></i></span>
                <input type="text" class="form-control bg-light border-start-0" placeholder="Order ID or Farmer">
              </div>
            </div>
            <div class="col-md-3">
              <label class="form-label small text-muted mb-1">Status</label>
              <select class="form-select bg-light">
                <option value="">All Statuses</option>
                <option value="placed">Placed</option>
                <option value="accepted">Accepted</option>
                <option value="ready">Ready for Pickup</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label small text-muted mb-1">Date Range</label>
              <select class="form-select bg-light">
                <option value="30">Last 30 Days</option>
                <option value="90">Last 3 Months</option>
                <option value="180">Last 6 Months</option>
                <option value="all">All Time</option>
              </select>
            </div>
            <div class="col-md-3">
              <button type="button" class="btn btn-success w-100">Apply Filters</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Orders List -->
      <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
          <div class="table-responsive d-none d-lg-block">
            <table class="table table-hover align-middle mb-0">
              <thead class="bg-light">
                <tr>
                  <th class="ps-4 py-3">Order ID</th>
                  <th class="py-3">Farmer</th>
                  <th class="py-3">Products</th>
                  <th class="py-3">Pickup Date/Time</th>
                  <th class="py-3">Total</th>
                  <th class="py-3">Status</th>
                  <th class="pe-4 py-3 text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                <!-- Placed -->
                <tr>
                  <td class="ps-4 fw-medium">#ORD-001</td>
                  <td>Green Valley Farm</td>
                  <td class="text-truncate" style="max-width: 150px;">Tomatoes, Carrots</td>
                  <td>Oct 15, 2026<br><small class="text-muted">9:00 AM - 12:00 PM</small></td>
                  <td>$24.50</td>
                  <td><span class="badge bg-secondary">Placed</span></td>
                  <td class="pe-4 text-end">
                    <a href="order-details.php" class="btn btn-sm btn-light text-primary" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-light text-warning" title="Modify"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Cancel"><i class="fas fa-times"></i></button>
                  </td>
                </tr>
                <!-- Accepted -->
                <tr>
                  <td class="ps-4 fw-medium">#ORD-002</td>
                  <td>Sunny Acres</td>
                  <td class="text-truncate" style="max-width: 150px;">Organic Eggs (x2)</td>
                  <td>Oct 14, 2026<br><small class="text-muted">10:00 AM - 2:00 PM</small></td>
                  <td>$12.00</td>
                  <td><span class="badge bg-primary">Accepted</span></td>
                  <td class="pe-4 text-end">
                    <a href="order-details.php" class="btn btn-sm btn-light text-primary" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-light text-muted" title="Modify" disabled><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Cancel"><i class="fas fa-times"></i></button>
                  </td>
                </tr>
                <!-- Ready for Pickup -->
                <tr>
                  <td class="ps-4 fw-medium">#ORD-003</td>
                  <td>River Fresh Market</td>
                  <td class="text-truncate" style="max-width: 150px;">Apples, Honey</td>
                  <td>Oct 12, 2026<br><small class="text-muted">9:00 AM - 12:00 PM</small></td>
                  <td>$32.00</td>
                  <td><span class="badge bg-warning text-dark">Ready for Pickup</span></td>
                  <td class="pe-4 text-end">
                    <a href="order-details.php" class="btn btn-sm btn-light text-primary" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-light text-muted" title="Modify" disabled><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-light text-muted" title="Cancel" disabled><i class="fas fa-times"></i></button>
                  </td>
                </tr>
                <!-- Completed -->
                <tr>
                  <td class="ps-4 fw-medium">#ORD-004</td>
                  <td>Local Roots</td>
                  <td class="text-truncate" style="max-width: 150px;">Potatoes</td>
                  <td>Oct 10, 2026<br><small class="text-muted">8:00 AM - 1:00 PM</small></td>
                  <td>$15.75</td>
                  <td><span class="badge bg-success">Completed</span></td>
                  <td class="pe-4 text-end">
                    <a href="order-details.php" class="btn btn-sm btn-light text-primary" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-light text-success" title="Reorder"><i class="fas fa-sync-alt"></i></button>
                  </td>
                </tr>
                <!-- Cancelled -->
                <tr>
                  <td class="ps-4 fw-medium">#ORD-005</td>
                  <td>Green Valley Farm</td>
                  <td class="text-truncate" style="max-width: 150px;">Lettuce</td>
                  <td>Oct 05, 2026<br><small class="text-muted">9:00 AM - 12:00 PM</small></td>
                  <td>$6.00</td>
                  <td><span class="badge bg-danger">Cancelled</span></td>
                  <td class="pe-4 text-end">
                    <a href="order-details.php" class="btn btn-sm btn-light text-primary" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-light text-success" title="Reorder"><i class="fas fa-sync-alt"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Mobile Cards View -->
          <div class="d-lg-none">
            <!-- Card 1 -->
            <div class="p-3 border-bottom">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-bold">#ORD-001</span>
                <span class="badge bg-secondary">Placed</span>
              </div>
              <div class="mb-1"><i class="fas fa-tractor text-muted me-1 w-20px text-center"></i> Green Valley Farm</div>
              <div class="mb-1 text-truncate"><i class="fas fa-shopping-basket text-muted me-1 w-20px text-center"></i> Tomatoes, Carrots</div>
              <div class="mb-2"><i class="fas fa-calendar-alt text-muted me-1 w-20px text-center"></i> Oct 15, 2026 <small class="text-muted">9:00 AM - 12:00 PM</small></div>
              <div class="d-flex justify-content-between align-items-center mt-3">
                <span class="fw-bold text-success">$24.50</span>
                <div>
                  <a href="order-details.php" class="btn btn-sm btn-light text-primary"><i class="fas fa-eye"></i></a>
                  <button class="btn btn-sm btn-light text-warning"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-sm btn-light text-danger"><i class="fas fa-times"></i></button>
                </div>
              </div>
            </div>
            <!-- Additional mobile cards omitted for brevity, would map similarly -->
            <div class="p-3 border-bottom">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-bold">#ORD-004</span>
                <span class="badge bg-success">Completed</span>
              </div>
              <div class="mb-1"><i class="fas fa-tractor text-muted me-1 w-20px text-center"></i> Local Roots</div>
              <div class="mb-1 text-truncate"><i class="fas fa-shopping-basket text-muted me-1 w-20px text-center"></i> Potatoes</div>
              <div class="mb-2"><i class="fas fa-calendar-alt text-muted me-1 w-20px text-center"></i> Oct 10, 2026 <small class="text-muted">8:00 AM - 1:00 PM</small></div>
              <div class="d-flex justify-content-between align-items-center mt-3">
                <span class="fw-bold text-success">$15.75</span>
                <div>
                  <a href="order-details.php" class="btn btn-sm btn-light text-primary"><i class="fas fa-eye"></i></a>
                  <button class="btn btn-sm btn-light text-success"><i class="fas fa-sync-alt"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Pagination -->
      <nav class="mt-4" aria-label="Orders pagination">
        <ul class="pagination justify-content-center">
          <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
          </li>
          <li class="page-item active" aria-current="page"><a class="page-link" href="#">1</a></li>
          <li class="page-item"><a class="page-link" href="#">2</a></li>
          <li class="page-item"><a class="page-link" href="#">3</a></li>
          <li class="page-item">
            <a class="page-link" href="#">Next</a>
          </li>
        </ul>
      </nav>

    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/data.js"></script>
<script src="js/main.js"></script>
<script>
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

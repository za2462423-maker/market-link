<?php
$page_title = "AI Assistant - MarketLink ";
$current_page = "ai-assistant";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>


    <!-- Page Hero -->
    <section class="hero-section">
        <div class="container animate-fadeInUp">
            <h1 class="fw-bold mb-3">MarketLink AI Assistant</h1>
            <p class="lead mb-4">Ask me anything about local markets, farmers, and fresh produce</p>
        </div>
    </section>

    <!-- Chat Interface -->
    <div class="container">
        <div class="chat-container animate-fadeInUp delay-200">
            <!-- Suggested Questions -->
            <div class="suggested-chips">
                <span class="text-muted w-100 d-block mb-2" style="font-size: 0.85rem;"><i class="fas fa-lightbulb me-1"></i> Suggested Questions</span>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Where can I find tomatoes?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Which markets are open today?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Which farmers sell dairy products?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">What are the pickup timings?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Find me fresh organic eggs</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Best rated farmers</button>
            </div>

            <!-- Chat Window -->
            <div class="chat-window" id="full-chat-window">
                <!-- Welcome Message -->
                <div class="bot-message-wrapper animate-chatBubblePop">
                    <div class="bot-avatar">
                        <i class="fas fa-seedling"></i>
                    </div>
                    <div class="message-bubble bot-message">
                        Hi! I am the MarketLink Assistant. I can help you find markets, farmers, and fresh products. What would you like to know?
                    </div>
                </div>
            </div>

            <!-- Input Area -->
            <div class="chat-input-area">
                <div class="chat-input-group">
                    <button class="btn text-muted p-2 me-1" title="Attach file (UI only)"><i class="fas fa-paperclip"></i></button>
                    <input type="text" id="full-chat-input" placeholder="Type your message here..." autocomplete="off">
                    <button class="btn text-muted p-2 mx-1" title="Voice input (UI only)"><i class="fas fa-microphone"></i></button>
                    <button class="btn btn-success text-white" id="full-chat-send" title="Send message"><i class="fas fa-paper-plane"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    
<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "Admin Reviews - MarketLink ";
$current_page = "admin-reviews";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Review Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <select class="form-select w-auto">
              <option value="">All Reviews</option>
              <option>Pending</option>
              <option>Flagged</option>
              <option>Removed</option>
            </select>
          </div>
        </div>

        <div class="row g-4">
          <!-- Review Card -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=61" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Fatima Ali</strong><br>
                    <small class="text-muted">Reviewed: Organic Tomatoes</small>
                  </div>
                </div>
                <span class="badge badge-active">Approved</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"Excellent quality and very fresh. Will definitely buy again from this farmer!"</p>
              <small class="text-muted d-block mb-3">Sep 24, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-danger flex-grow-1"><i class="fas fa-trash"></i> Remove</button>
                <button class="btn btn-sm btn-outline-warning flex-grow-1"><i class="fas fa-flag"></i> Flag</button>
              </div>
            </div>
          </div>

          <!-- Review Card Flagged -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3 border-warning">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=62" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Usman Tariq</strong><br>
                    <small class="text-muted">Reviewed: Fresh Milk</small>
                  </div>
                </div>
                <span class="badge badge-flagged">Flagged</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"Milk smelled weird and was sour. Contains spam text: buy cheap followers at www.spam.com"</p>
              <small class="text-muted d-block mb-3">Sep 23, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-success flex-grow-1"><i class="fas fa-check"></i> Approve</button>
                <button class="btn btn-sm btn-outline-danger flex-grow-1"><i class="fas fa-trash"></i> Remove</button>
              </div>
            </div>
          </div>
          
          <!-- Review Card Removed -->
          <div class="col-md-6 col-xl-4">
            <div class="admin-card h-100 p-3 opacity-75">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="https://picsum.photos/40/40?random=63" class="rounded-circle" style="width:40px;height:40px">
                  <div>
                    <strong>Unknown User</strong><br>
                    <small class="text-muted">Reviewed: Apples</small>
                  </div>
                </div>
                <span class="badge badge-removed">Removed</span>
              </div>
              <div class="text-warning mb-2">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
              </div>
              <p class="mb-3 text-muted">"[Inappropriate Content Removed]"</p>
              <small class="text-muted d-block mb-3">Sep 22, 2026</small>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-success w-100"><i class="fas fa-undo"></i> Restore</button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

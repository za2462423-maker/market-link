<?php
$page_title = "Farmers - MarketLink ";
$current_page = "farmers";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>


    <!-- Page Hero -->
    <section class="hero-section">
        <div class="container">
            <h1>Meet Our Local Farmers</h1>
            <p class="lead mb-4">Connect with the people who grow your food.</p>
        </div>
    </section>

    <!-- Filters Bar -->
    <section class="filters-bar">
        <div class="container">
            <div class="row g-3 align-items-center">
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="fa-solid fa-search text-muted"></i></span>
                        <input type="text" id="searchFilter" class="form-control border-start-0 filter-input" placeholder="Search farmers...">
                    </div>
                </div>
                <div class="col-md-2">
                    <select id="locFilter" class="form-select filter-input">
                        <option value="all">All Locations</option>
                        <option value="Downtown">Downtown</option>
                        <option value="Westside">Westside</option>
                        <option value="Eastside">Eastside</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="marketFilter" class="form-select filter-input">
                        <option value="all">Select Market</option>
                        <option value="Downtown Farmers Market">Downtown Market</option>
                        <option value="Westside Community Market">Westside Market</option>
                        <option value="Eastside Organic Market">Eastside Market</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="catFilter" class="form-select filter-input">
                        <option value="all">All Categories</option>
                        <option value="Vegetables">Vegetables</option>
                        <option value="Fruits">Fruits</option>
                        <option value="Dairy">Dairy</option>
                        <option value="Meat">Meat</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="form-check form-switch">
                        <input class="form-check-input filter-input" type="checkbox" id="openTodayFilter">
                        <label class="form-check-label" for="openTodayFilter">Open Today</label>
                    </div>
                </div>
                <div class="col-md-1 text-md-end">
                    <a href="#" id="clearFiltersBtn" class="text-success text-decoration-none small">Clear All</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h5 class="mb-0 fw-bold" id="resultsCount">Showing 6 farmers</h5>
            <div class="d-flex align-items-center">
                <span class="me-2 text-muted small">Sort by:</span>
                <select class="form-select form-select-sm" style="width: auto;">
                    <option>Highest Rated</option>
                    <option>Newest</option>
                    <option>A-Z</option>
                </select>
            </div>
        </div>

        <div class="row g-4" id="farmersGrid">
            
            <!-- Farmer Card 1 -->
            <div class="col-lg-4 col-md-6 farmer-item" data-name="Green Valley Farms" data-loc="Downtown" data-market="Downtown Farmers Market" data-cat="Vegetables">
                <div class="farmer-card">
                    <button class="fav-btn" title="Add to Favorites"><i class="fa-solid fa-heart"></i></button>
                    <div class="farmer-img-container">
                        <img src="https://images.unsplash.com/photo-1595856752766-3d601d36d8d9?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                        <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Avatar" class="farmer-avatar">
                    </div>
                    <div class="farmer-body">
                        <h3 class="stall-name">Green Valley Farms</h3>
                        <div class="farmer-name">John Smith</div>
                        <div class="rating">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                            <span class="text-muted ms-1 text-dark">4.8 (120)</span>
                        </div>
                        
                        <div>
                            <span class="market-badge"><i class="fa-solid fa-location-dot"></i> Downtown Farmers Market</span>
                        </div>
                        
                        <div class="days-container mt-2">
                            <span class="day-chip">Saturday</span>
                            <span class="day-chip">Sunday</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top">
                            <span class="product-count">24 Products</span>
                            <a href="farmer-profile.php" class="btn btn-sm btn-success">View Profile</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Farmer Card 2 -->
            <div class="col-lg-4 col-md-6 farmer-item" data-name="Sunny Dairy" data-loc="Westside" data-market="Westside Community Market" data-cat="Dairy">
                <div class="farmer-card">
                    <button class="fav-btn" title="Add to Favorites"><i class="fa-solid fa-heart"></i></button>
                    <div class="farmer-img-container">
                        <img src="https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                        <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Avatar" class="farmer-avatar">
                    </div>
                    <div class="farmer-body">
                        <h3 class="stall-name">Sunny Dairy</h3>
                        <div class="farmer-name">Sarah Jenkins</div>
                        <div class="rating">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                            <span class="text-muted ms-1 text-dark">5.0 (89)</span>
                        </div>
                        
                        <div>
                            <span class="market-badge"><i class="fa-solid fa-location-dot"></i> Westside Community Market</span>
                        </div>
                        
                        <div class="days-container mt-2">
                            <span class="day-chip">Wednesday</span>
                            <span class="day-chip">Saturday</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top">
                            <span class="product-count">15 Products</span>
                            <a href="farmer-profile.php" class="btn btn-sm btn-success">View Profile</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Farmer Card 3 -->
            <div class="col-lg-4 col-md-6 farmer-item" data-name="Orchard Hill" data-loc="Eastside" data-market="Eastside Organic Market" data-cat="Fruits">
                <div class="farmer-card">
                    <button class="fav-btn" title="Add to Favorites"><i class="fa-solid fa-heart"></i></button>
                    <div class="farmer-img-container">
                        <img src="https://images.unsplash.com/photo-1590005086576-809fa84c6776?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                        <img src="https://randomuser.me/api/portraits/men/22.jpg" alt="Avatar" class="farmer-avatar">
                    </div>
                    <div class="farmer-body">
                        <h3 class="stall-name">Orchard Hill</h3>
                        <div class="farmer-name">Mike Davis</div>
                        <div class="rating">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i>
                            <span class="text-muted ms-1 text-dark">4.2 (45)</span>
                        </div>
                        
                        <div>
                            <span class="market-badge"><i class="fa-solid fa-location-dot"></i> Eastside Organic Market</span>
                        </div>
                        
                        <div class="days-container mt-2">
                            <span class="day-chip">Sunday</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top">
                            <span class="product-count">12 Products</span>
                            <a href="farmer-profile.php" class="btn btn-sm btn-success">View Profile</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Farmer Card 4 -->
            <div class="col-lg-4 col-md-6 farmer-item" data-name="River Meats" data-loc="Downtown" data-market="Downtown Farmers Market" data-cat="Meat">
                <div class="farmer-card">
                    <button class="fav-btn" title="Add to Favorites"><i class="fa-solid fa-heart"></i></button>
                    <div class="farmer-img-container">
                        <img src="https://images.unsplash.com/photo-1607623814075-e51df1bd682f?auto=format&fit=crop&q=80&w=400&h=200" alt="Cover" class="farmer-cover">
                        <img src="https://randomuser.me/api/portraits/men/54.jpg" alt="Avatar" class="farmer-avatar">
                    </div>
                    <div class="farmer-body">
                        <h3 class="stall-name">River Meats</h3>
                        <div class="farmer-name">Tom Wilson</div>
                        <div class="rating">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                            <span class="text-muted ms-1 text-dark">4.6 (67)</span>
                        </div>
                        
                        <div>
                            <span class="market-badge"><i class="fa-solid fa-location-dot"></i> Downtown Farmers Market</span>
                        </div>
                        
                        <div class="days-container mt-2">
                            <span class="day-chip">Saturday</span>
                            <span class="day-chip">Sunday</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top">
                            <span class="product-count">8 Products</span>
                            <a href="farmer-profile.php" class="btn btn-sm btn-success">View Profile</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Pagination -->
        <nav class="mt-5">
            <ul class="pagination justify-content-center">
                <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                <li class="page-item active"><a class="page-link bg-success border-success" href="#">1</a></li>
                <li class="page-item"><a class="page-link text-success" href="#">2</a></li>
                <li class="page-item"><a class="page-link text-success" href="#">Next</a></li>
            </ul>
        </nav>
    </div>
    
    <!-- Toast Container -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="favToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Added to favorites!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Footer -->
    
<?php
require_once __DIR__ . '/includes/footer.php';
?>

<?php
$page_title = "Pre-Order - MarketLink ";
$current_page = "preorder";
require_once __DIR__ . '/includes/header.php';
?>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-success" href="index.php"><i class="fas fa-leaf me-2"></i>MarketLink</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Place Your Pre-Order</h2>
        </div>

        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step completed">
                <div class="step-icon"><i class="fas fa-check"></i></div>
                <span>Cart</span>
            </div>
            <div class="step-line bg-success"></div>
            <div class="step active" id="step2-indicator">
                <div class="step-icon">2</div>
                <span>Pre-Order Details</span>
            </div>
            <div class="step-line"></div>
            <div class="step" id="step3-indicator">
                <div class="step-icon">3</div>
                <span>Confirmation</span>
            </div>
        </div>

        <div class="row" id="main-content">
            <!-- Left: Form -->
            <div class="col-lg-7 mb-4">
                <form id="preorder-form" class="card border-0 shadow-sm p-4">
                    
                    <h5 class="fw-bold border-bottom pb-2 mb-4">Customer Information</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="John Smith" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" value="(555) 123-4567" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="john.smith@example.com" required>
                        </div>
                    </div>

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Pickup Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-12">
                            <label class="form-label">Select Pickup Market</label>
                            <select class="form-select" required>
                                <option value="" selected disabled>Choose a market...</option>
                                <option value="Downtown">Downtown Farmers Market</option>
                                <option value="Westside">Westside Weekend Market</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Pickup Date</label>
                            <input type="date" class="form-control" id="pickup-date" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Time Slot</label>
                            <select class="form-select" required>
                                <option value="" selected disabled>Choose time...</option>
                                <option value="8-9">8:00 AM - 9:00 AM</option>
                                <option value="9-10">9:00 AM - 10:00 AM</option>
                                <option value="10-11">10:00 AM - 11:00 AM</option>
                                <option value="11-12">11:00 AM - 12:00 PM</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Notes (Optional)</label>
                            <textarea class="form-control" rows="2" placeholder="e.g., I will send my brother to pick up."></textarea>
                        </div>
                    </div>

                    <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
                        <i class="fas fa-wallet fs-4 me-3"></i>
                        <div>
                            <strong>Payment Notice:</strong> Payment will be made in person at the pickup location directly to the farmer. No online payment required.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 fw-bold">Place Pre-Order</button>
                </form>
            </div>

            <!-- Right: Summary -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm sticky-top" style="top: 90px;">
                    <div class="card-body p-4 bg-light rounded">
                        <h4 class="fw-bold mb-4">Order Summary</h4>
                        
                        <div id="order-items-list" class="mb-4">
                            <!-- Items from JS -->
                        </div>

                        <hr>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span class="fw-medium">$32.97</span>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total to Pay at Pickup</span>
                            <span class="fw-bold fs-4 text-success">$32.97</span>
                        </div>
                        
                        <div class="p-3 bg-white border rounded">
                            <h6 class="fw-bold mb-2"><i class="fas fa-box me-2 text-success"></i>Pre-Order Info</h6>
                            <ul class="list-unstyled small text-muted mb-0">
                                <li class="mb-1">&bull; Order contains items from 2 farmers.</li>
                                <li class="mb-1">&bull; Bring order ID to the market.</li>
                                <li>&bull; Pay directly at each farmer's stall.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Confirmation State (Hidden initially) -->
        <div class="row justify-content-center d-none" id="confirmation-content">
            <div class="col-md-8 text-center">
                <div class="card border-0 shadow p-5">
                    <div class="mb-4">
                        <i class="fas fa-check-circle text-success" style="font-size: 5rem;"></i>
                    </div>
                    <h1 class="fw-bold mb-3">Pre-Order Placed Successfully!</h1>
                    <p class="text-muted fs-5 mb-4">Your order ID is <strong class="text-dark">#ML-89245</strong></p>
                    
                    <div class="bg-light p-4 rounded text-start mb-4 mx-auto" style="max-width: 500px;">
                        <h5 class="fw-bold mb-3">Next Steps:</h5>
                        <ol class="mb-0">
                            <li class="mb-2">We've sent a confirmation email with details.</li>
                            <li class="mb-2">Go to the selected market on your chosen date/time.</li>
                            <li>Provide your Order ID and pay in person to collect items.</li>
                        </ol>
                    </div>

                    <div class="d-flex justify-content-center gap-3">
                        <a href="index.php" class="btn btn-outline-success">Return Home</a>
                        <a href="#" class="btn btn-success">View My Orders</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set min date for date picker to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('pickup-date').setAttribute('min', today);

        // Render mock items
        const items = [
            { name: "Organic Tomatoes", qty: 2, price: 4.99, farmer: "Green Acres Farm" },
            { name: "Farmhouse Cheddar", qty: 1, price: 8.99, farmer: "Happy Cows Dairy" },
            { name: "Sourdough Bread", qty: 2, price: 7.00, farmer: "The Wheatery" }
        ];

        const list = document.getElementById('order-items-list');
        // Group by farmer (simplified display)
        items.forEach(item => {
            const div = document.createElement('div');
            div.className = 'd-flex justify-content-between mb-3 border-bottom pb-2';
            div.innerHTML = `
                <div>
                    <h6 class="mb-0 fw-bold">${item.qty}x ${item.name}</h6>
                    <small class="text-muted">${item.farmer}</small>
                </div>
                <span class="fw-medium">$${(item.qty * item.price).toFixed(2)}</span>
            `;
            list.appendChild(div);
        });

        // Form Submission
        document.getElementById('preorder-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Hide main content, show confirmation
            document.getElementById('main-content').classList.add('d-none');
            document.getElementById('confirmation-content').classList.remove('d-none');
            
            // Update step indicator
            document.getElementById('step2-indicator').classList.remove('active');
            document.getElementById('step2-indicator').classList.add('completed');
            document.getElementById('step2-indicator').querySelector('.step-icon').innerHTML = '<i class="fas fa-check"></i>';
            document.getElementById('step3-indicator').classList.add('active');
            document.getElementById('step3-indicator').previousElementSibling.classList.add('bg-success');
            
            window.scrollTo(0, 0);
        });
    </script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

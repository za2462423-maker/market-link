<?php
$page_title = "Admin Products - MarketLink ";
$current_page = "admin-products";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link active"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Product Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex flex-wrap gap-3 align-items-center">
            <input type="text" class="form-control" placeholder="Search products or farmers..." style="max-width: 300px;">
            <select class="form-select w-auto">
              <option value="">All Categories</option>
              <option>Vegetables</option>
              <option>Fruits</option>
              <option>Dairy</option>
            </select>
            <select class="form-select w-auto">
              <option value="">All Statuses</option>
              <option>Active</option>
              <option>Flagged</option>
              <option>Removed</option>
            </select>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Farmer</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=51" alt="Product">
                      <strong>Organic Tomatoes</strong>
                    </div>
                  </td>
                  <td>Green Valley Farms</td>
                  <td>Vegetables</td>
                  <td>PKR 150/kg</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning" title="Flag"><i class="fas fa-flag"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Remove"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr class="row-flagged">
                  <td>2</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=52" alt="Product">
                      <strong>Fresh Milk (Unpasteurized)</strong>
                    </div>
                  </td>
                  <td>Ali Dairy</td>
                  <td>Dairy</td>
                  <td>PKR 220/L</td>
                  <td><span class="badge badge-flagged">Flagged</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" title="Unflag"><i class="fas fa-check"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Remove"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=53" alt="Product">
                      <strong>Apples</strong>
                    </div>
                  </td>
                  <td>Zahid Fruits</td>
                  <td>Fruits</td>
                  <td>PKR 300/kg</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning" title="Flag"><i class="fas fa-flag"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Remove"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=54" alt="Product">
                      <strong>Desi Ghee</strong>
                    </div>
                  </td>
                  <td>Pure Dairy Farms</td>
                  <td>Dairy</td>
                  <td>PKR 2500/kg</td>
                  <td><span class="badge badge-removed">Removed</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" title="Restore"><i class="fas fa-undo"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

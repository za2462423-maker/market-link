<?php
$page_title = "Admin Reports - MarketLink ";
$current_page = "admin-reports";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link active"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Reports & Analytics</h4>
        </div>
        <div class="d-flex gap-3 align-items-center">
          <input type="date" class="form-control form-control-sm">
          <span>to</span>
          <input type="date" class="form-control form-control-sm">
          <button class="btn btn-success btn-sm"><i class="fas fa-download"></i> Download Report</button>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Report Cards -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-purple"><i class="fas fa-shopping-cart"></i></div>
              <div class="admin-stat-info">
                <p>Orders This Month</p>
                <h3>845</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-gradient"><i class="fas fa-money-bill-wave"></i></div>
              <div class="admin-stat-info">
                <p>Revenue This Month</p>
                <h3>PKR 540K</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-green"><i class="fas fa-tractor"></i></div>
              <div class="admin-stat-info">
                <p>New Farmers</p>
                <h3>12</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>New Customers</p>
                <h3>154</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4 mb-4">
          <div class="col-lg-8">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Revenue by Month</h5>
              </div>
              <div class="admin-card-body">
                <div class="simple-bar-chart" style="height: 300px;">
                  <!-- Bars -->
                  <div class="bar-col"><div class="bar" style="height: 20%; background-color:#2196F3"></div><div class="bar-label">Jan</div></div>
                  <div class="bar-col"><div class="bar" style="height: 35%; background-color:#2196F3"></div><div class="bar-label">Feb</div></div>
                  <div class="bar-col"><div class="bar" style="height: 40%; background-color:#2196F3"></div><div class="bar-label">Mar</div></div>
                  <div class="bar-col"><div class="bar" style="height: 30%; background-color:#2196F3"></div><div class="bar-label">Apr</div></div>
                  <div class="bar-col"><div class="bar" style="height: 50%; background-color:#2196F3"></div><div class="bar-label">May</div></div>
                  <div class="bar-col"><div class="bar" style="height: 65%; background-color:#2196F3"></div><div class="bar-label">Jun</div></div>
                  <div class="bar-col"><div class="bar" style="height: 80%; background-color:#2196F3"></div><div class="bar-label">Jul</div></div>
                  <div class="bar-col"><div class="bar" style="height: 90%; background-color:#2196F3"></div><div class="bar-label">Aug</div></div>
                  <div class="bar-col"><div class="bar" style="height: 75%; background-color:#2196F3"></div><div class="bar-label">Sep</div></div>
                  <div class="bar-col"><div class="bar" style="height: 0%; background-color:#2196F3"></div><div class="bar-label">Oct</div></div>
                  <div class="bar-col"><div class="bar" style="height: 0%; background-color:#2196F3"></div><div class="bar-label">Nov</div></div>
                  <div class="bar-col"><div class="bar" style="height: 0%; background-color:#2196F3"></div><div class="bar-label">Dec</div></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Popular Categories</h5>
              </div>
              <div class="admin-card-body">
                <div class="mb-4">
                  <div class="d-flex justify-content-between mb-1"><span>Vegetables</span><span>45%</span></div>
                  <div class="progress" style="height: 8px;"><div class="progress-bar bg-success" style="width: 45%"></div></div>
                </div>
                <div class="mb-4">
                  <div class="d-flex justify-content-between mb-1"><span>Fruits</span><span>30%</span></div>
                  <div class="progress" style="height: 8px;"><div class="progress-bar bg-info" style="width: 30%"></div></div>
                </div>
                <div class="mb-4">
                  <div class="d-flex justify-content-between mb-1"><span>Dairy</span><span>15%</span></div>
                  <div class="progress" style="height: 8px;"><div class="progress-bar bg-warning" style="width: 15%"></div></div>
                </div>
                <div class="mb-4">
                  <div class="d-flex justify-content-between mb-1"><span>Baked Goods</span><span>8%</span></div>
                  <div class="progress" style="height: 8px;"><div class="progress-bar bg-primary" style="width: 8%"></div></div>
                </div>
                <div class="mb-0">
                  <div class="d-flex justify-content-between mb-1"><span>Other</span><span>2%</span></div>
                  <div class="progress" style="height: 8px;"><div class="progress-bar bg-secondary" style="width: 2%"></div></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4">
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Market Activity</h5>
              </div>
              <div class="table-responsive">
                <table class="table admin-table mb-0">
                  <thead>
                    <tr>
                      <th>Market Name</th>
                      <th>Orders</th>
                      <th>Revenue</th>
                      <th>Farmers</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>F-8 Farmers Market</td>
                      <td>1,240</td>
                      <td>PKR 850K</td>
                      <td>12</td>
                    </tr>
                    <tr>
                      <td>G-9 Karachi Co.</td>
                      <td>850</td>
                      <td>PKR 620K</td>
                      <td>24</td>
                    </tr>
                    <tr>
                      <td>Saddar Fresh Bazaar</td>
                      <td>1,492</td>
                      <td>PKR 930K</td>
                      <td>45</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Top 5 Products</h5>
              </div>
              <div class="admin-card-body">
                <div class="d-flex align-items-center mb-3">
                  <span class="text-muted me-3" style="width: 20px">1.</span>
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Organic Tomatoes</span><span>2,140 sold</span></div>
                    <div class="progress" style="height: 6px;"><div class="progress-bar bg-success" style="width: 90%"></div></div>
                  </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                  <span class="text-muted me-3" style="width: 20px">2.</span>
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Fresh Milk</span><span>1,850 sold</span></div>
                    <div class="progress" style="height: 6px;"><div class="progress-bar bg-info" style="width: 75%"></div></div>
                  </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                  <span class="text-muted me-3" style="width: 20px">3.</span>
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Desi Eggs</span><span>1,520 sold</span></div>
                    <div class="progress" style="height: 6px;"><div class="progress-bar bg-warning" style="width: 60%"></div></div>
                  </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                  <span class="text-muted me-3" style="width: 20px">4.</span>
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Apples</span><span>1,100 sold</span></div>
                    <div class="progress" style="height: 6px;"><div class="progress-bar bg-danger" style="width: 45%"></div></div>
                  </div>
                </div>
                <div class="d-flex align-items-center mb-0">
                  <span class="text-muted me-3" style="width: 20px">5.</span>
                  <div class="flex-grow-1">
                    <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Potatoes</span><span>950 sold</span></div>
                    <div class="progress" style="height: 6px;"><div class="progress-bar bg-primary" style="width: 35%"></div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

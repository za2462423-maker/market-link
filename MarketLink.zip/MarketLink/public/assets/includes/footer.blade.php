    <!-- Footer -->
    <footer class="ml-footer">
      <div class="container">
        <div class="row g-4">
          <div class="col-lg-4">
            <div class="ml-footer-brand"><i class="fas fa-seedling"></i> MarketLink</div>
            <p>Connecting local farmers with customers. Fresh, seasonal, community-grown.</p>
            <div class="ml-social-links">
              <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
              <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
              <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
              <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
          <div class="col-lg-2 col-md-4">
            <h6>Quick Links</h6>
            <ul class="ml-footer-links list-unstyled">
              <li><a href="markets.php">Markets</a></li>
              <li><a href="farmers.php">Farmers</a></li>
              <li><a href="products.php">Products</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="sitemap.php">Sitemap</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-4">
            <h6>For Farmers</h6>
            <ul class="ml-footer-links list-unstyled">
              <li><a href="farmer-login.php">Farmer Login</a></li>
              <li><a href="farmer-register.php">Join as Farmer</a></li>
              <li><a href="farmer-dashboard.php">Dashboard</a></li>
            </ul>
          </div>
          <div class="col-lg-4 col-md-4">
            <h6>Newsletter</h6>
            <p class="ml-footer-text text-muted">Get updates on fresh arrivals and market events.</p>
            <form class="ml-newsletter-form" id="footerNewsletter" action="contact.php" method="POST">
              <div class="input-group">
                <input type="email" class="form-control" name="newsletter_email" placeholder="Your email" aria-label="Footer Email" required>
                <button class="btn ml-btn-primary" type="submit">Subscribe</button>
              </div>
            </form>
          </div>
        </div>
        <hr class="ml-footer-divider my-4">
        <div class="row align-items-center">
          <div class="col-md-6"><p class="ml-footer-copy mb-0">&copy; <?php echo date('Y'); ?> MarketLink. All rights reserved.</p></div>
          <div class="col-md-6 text-md-end"><p class="ml-footer-copy mb-0">Made with <i class="fas fa-heart text-danger"></i> for local farmers</p></div>
        </div>
      </div>
    </footer>

    <!-- Floating UI -->
    <a href="#" class="btn ml-btn-primary rounded-circle position-fixed bottom-0 start-0 m-4 shadow-lg d-flex align-items-center justify-content-center" style="width:50px; height:50px; z-index: 1000;" aria-label="Back to top">
        <i class="fas fa-arrow-up"></i>
    </a>

    <button class="btn ml-btn-primary rounded-circle position-fixed bottom-0 end-0 m-4 shadow-lg d-flex align-items-center justify-content-center" style="width:60px; height:60px; z-index: 1000;" aria-label="AI Chatbot" data-bs-toggle="collapse" data-bs-target="#chatWidget">
        <i class="fas fa-comments fs-3"></i>
    </button>
    
    <div class="collapse position-fixed bottom-0 end-0 m-4 mb-5 pb-5 me-5 z-3" id="chatWidget" style="width: 350px;">
        <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center p-3">
                <h6 class="mb-0 fw-bold"><i class="fas fa-robot me-2"></i> MarketLink Assistant</h6>
                <button type="button" class="btn-close btn-close-white btn-sm" data-bs-toggle="collapse" data-bs-target="#chatWidget" aria-label="Close"></button>
            </div>
            <div class="card-body bg-light" id="chatWidgetBody" style="height: 300px; overflow-y: auto;">
                <div class="d-flex mb-3">
                    <div class="bg-white p-3 rounded-3 shadow-sm" style="max-width: 80%;">
                        <p class="mb-0 small">Hi! I can help you find products, markets, or answer questions about ordering. What are you looking for?</p>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-white p-3 border-top-0">
                <form id="chatWidgetForm" onsubmit="return false;">
                    <div class="input-group">
                        <input type="text" id="chatWidgetInput" class="form-control rounded-pill-start bg-light border-0" placeholder="Type a message...">
                        <button type="submit" id="chatWidgetSend" class="btn btn-success rounded-pill-end px-3"><i class="fas fa-paper-plane"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/data.js"></script>
    <script src="js/main.js"></script>
    <script src="js/cart.js"></script>
    <script src="js/chatbot.js"></script>
</body>
</html>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg ml-navbar sticky-top">
      <div class="container">
        <a class="navbar-brand ml-brand" href="index.php">
          <i class="fas fa-seedling"></i> MarketLink
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'index') ? 'active' : ''; ?>" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'markets') ? 'active' : ''; ?>" href="markets.php">Markets</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'farmers') ? 'active' : ''; ?>" href="farmers.php">Farmers</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'products') ? 'active' : ''; ?>" href="products.php">Products</a></li>
            <li class="nav-item"><a class="nav-link {{ $current_page === 'about' ? 'active' : '' }}" href="{{ url('/about') }}">About</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'contact') ? 'active' : ''; ?>" href="contact.php">Contact</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'login') ? 'active' : ''; ?>" href="login.php">login</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($current_page === 'register') ? 'active' : ''; ?>" href="register.php">register</a></li>
          </ul>
          <div class="d-flex align-items-center gap-2">
            <a href="cart.php" class="ml-cart-btn" id="cartNavBtn" aria-label="Shopping Cart">
              <i class="fas fa-shopping-basket"></i> 
              <span class="ml-cart-badge" id="cartBadge">0</span>
            </a>
            <a href="login.php" class="btn ml-btn-outline-green">Login</a>
            <a href="register.php" class="btn ml-btn-primary">Register</a>
          </div>
        </div>
      </div>
    </nav>

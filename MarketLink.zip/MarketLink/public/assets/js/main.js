// Global JS functionality

document.addEventListener('DOMContentLoaded', () => {
    // 1. Navbar Sticky & Shadow
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('sticky-nav');
        } else {
            navbar.classList.remove('sticky-nav');
        }
    });

    // 2. Back to Top Button
    const backToTopBtn = document.getElementById('backToTop');
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 3. Scroll Animations (Intersection Observer)
    const animElements = document.querySelectorAll('.animate-on-scroll');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('anim-fade-up');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    animElements.forEach(el => observer.observe(el));

    // 4. Mobile Menu Toggle
    const mobileToggle = document.querySelector('.navbar-toggler');
    // Handled by Bootstrap natively if data-bs-toggle is present

    // 5. Toast Notification System
    window.showToast = function(message, type = 'success') {
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle text-green' : 'info-circle'} me-2"></i> ${message}`;
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    };

    // 6. Favorite Toggle
    document.querySelectorAll('.btn-favorite').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const icon = btn.querySelector('i');
            if (icon.classList.contains('far')) {
                icon.classList.replace('far', 'fas');
                icon.classList.add('text-danger');
                showToast('Added to favorites!');
            } else {
                icon.classList.replace('fas', 'far');
                icon.classList.remove('text-danger');
                showToast('Removed from favorites');
            }
        });
    });

    // 7. Add to Cart (Mock)
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const productId = btn.getAttribute('data-id') || '1';
            // Assuming cart logic exists globally
            if(window.addToCart) {
                window.addToCart({ id: productId, name: 'Product', price: 10, quantity: 1, image: 'https://via.placeholder.com/150' });
            } else {
                showToast('Item added to cart!');
            }
        });
    });

    // 8. AI Chatbot Widget
    const chatToggle = document.getElementById('chatToggleBtn');
    const chatWidget = document.getElementById('chatbotWidget');
    if (chatToggle && chatWidget) {
        chatToggle.addEventListener('click', () => {
            chatWidget.classList.toggle('open');
            chatToggle.style.display = chatWidget.classList.contains('open') ? 'none' : 'block';
        });

        const closeChat = document.getElementById('closeChat');
        if (closeChat) {
            closeChat.addEventListener('click', () => {
                chatWidget.classList.remove('open');
                chatToggle.style.display = 'block';
            });
        }

        const chatInput = document.getElementById('chatInput');
        const sendBtn = document.getElementById('sendChat');
        const chatMsgs = document.getElementById('chatMessages');

        const botResponses = {
            'tomatoes': 'You can find fresh tomatoes at the Downtown Market or through Farmer Joe.',
            'dairy': 'We have several dairy farmers. Check out Green Valley Farms for milk and cheese.',
            'pickup': 'Pickup timings vary by market. Usually from 8 AM to 2 PM on weekends.',
            'open today': 'Market hours today are 9 AM to 1 PM at the Central Square.'
        };

        const appendMessage = (text, sender) => {
            const msgDiv = document.createElement('div');
            msgDiv.style.padding = '8px 12px';
            msgDiv.style.borderRadius = '12px';
            msgDiv.style.maxWidth = '80%';
            msgDiv.style.marginBottom = '8px';
            
            if (sender === 'user') {
                msgDiv.style.background = '#22c55e';
                msgDiv.style.color = 'white';
                msgDiv.style.alignSelf = 'flex-end';
            } else {
                msgDiv.style.background = '#f3f4f6';
                msgDiv.style.color = '#333';
                msgDiv.style.alignSelf = 'flex-start';
            }
            msgDiv.textContent = text;
            chatMsgs.appendChild(msgDiv);
            chatMsgs.scrollTop = chatMsgs.scrollHeight;
        };

        const handleSend = () => {
            const val = chatInput.value.trim().toLowerCase();
            if (!val) return;
            appendMessage(chatInput.value, 'user');
            chatInput.value = '';
            
            setTimeout(() => {
                let response = "I'm not sure about that. Could you try rephrasing?";
                for (const key in botResponses) {
                    if (val.includes(key)) {
                        response = botResponses[key];
                        break;
                    }
                }
                appendMessage(response, 'bot');
            }, 600);
        };

        if(sendBtn) sendBtn.addEventListener('click', handleSend);
        if(chatInput) chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSend();
        });
    }

    // 9. Newsletter Form
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Subscribed successfully!');
            newsletterForm.reset();
        });
    }

    // 10. Live Search
    const searchInput = document.getElementById('mainSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('[data-searchable]').forEach(el => {
                const text = el.textContent.toLowerCase();
                el.style.display = text.includes(term) ? '' : 'none';
            });
        });
    }

    // 11. Number Counters
    const counters = document.querySelectorAll('.stat-number');
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target') || parseInt(counter.innerText);
        const increment = target / 50;
        let c = 0;
        const updateCounter = () => {
            c += increment;
            if (c < target) {
                counter.innerText = Math.ceil(c);
                setTimeout(updateCounter, 30);
            } else {
                counter.innerText = target;
            }
        };
        updateCounter();
    });
});

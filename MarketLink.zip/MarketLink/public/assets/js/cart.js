// Cart Management

let cart = JSON.parse(localStorage.getItem('ml_cart')) || [];

function saveCart() {
    localStorage.setItem('ml_cart', JSON.stringify(cart));
    updateCartBadge();
}

window.addToCart = function(product) {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
        existing.quantity += (product.quantity || 1);
    } else {
        cart.push({ ...product, quantity: product.quantity || 1 });
    }
    saveCart();
    if (window.showToast) {
        window.showToast('Added to cart!');
    }
};

window.removeFromCart = function(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    renderCart();
};

window.updateQuantity = function(id, delta) {
    const item = cart.find(item => item.id === id);
    if (item) {
        item.quantity += delta;
        if (item.quantity <= 0) {
            removeFromCart(id);
        } else {
            saveCart();
            renderCart();
        }
    }
};

window.getCart = function() {
    return cart;
};

window.getCartTotal = function() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
};

window.getCartCount = function() {
    return cart.reduce((count, item) => count + item.quantity, 0);
};

window.clearCart = function() {
    cart = [];
    saveCart();
    renderCart();
};

function updateCartBadge() {
    const badges = document.querySelectorAll('.cart-badge');
    badges.forEach(badge => {
        badge.textContent = window.getCartCount();
        badge.style.display = window.getCartCount() > 0 ? 'inline-block' : 'none';
    });
}

function renderCart() {
    const cartContainer = document.getElementById('cartItemsContainer');
    const totalEl = document.getElementById('cartTotalAmount');
    if (!cartContainer) return;

    if (cart.length === 0) {
        cartContainer.innerHTML = '<p class="text-center text-muted py-4">Your cart is empty.</p>';
        if (totalEl) totalEl.textContent = '$0.00';
        return;
    }

    cartContainer.innerHTML = cart.map(item => `
        <div class="d-flex align-items-center mb-3 p-3 border rounded">
            <img src="${item.image || 'https://via.placeholder.com/80'}" alt="${item.name}" width="80" class="rounded me-3">
            <div class="flex-grow-1">
                <h5 class="mb-1">${item.name}</h5>
                <p class="mb-0 text-muted">$${parseFloat(item.price).toFixed(2)}</p>
            </div>
            <div class="d-flex align-items-center mx-3">
                <button class="btn btn-sm btn-outline-secondary" onclick="updateQuantity('${item.id}', -1)">-</button>
                <span class="mx-2">${item.quantity}</span>
                <button class="btn btn-sm btn-outline-secondary" onclick="updateQuantity('${item.id}', 1)">+</button>
            </div>
            <div class="fw-bold me-3">$${(item.price * item.quantity).toFixed(2)}</div>
            <button class="btn btn-sm btn-danger" onclick="removeFromCart('${item.id}')"><i class="fas fa-trash"></i></button>
        </div>
    `).join('');

    if (totalEl) {
        totalEl.textContent = '$' + window.getCartTotal().toFixed(2);
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    updateCartBadge();
    renderCart();
});

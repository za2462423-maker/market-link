// js/chatbot.js

const chatbotHTML = `
<div id="ml-chatbot-container" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999; font-family: 'Poppins', sans-serif;">
    <!-- Chatbot Toggle Button -->
    <button id="ml-chatbot-toggle" class="btn btn-success rounded-circle animate-pulse shadow-lg" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; border: none; background-color: #28a745;">
        <i class="fas fa-comment-dots fa-2x text-white"></i>
    </button>

    <!-- Chatbot Widget -->
    <div id="ml-chatbot-widget" class="card shadow-lg d-none" style="width: 360px; height: 500px; position: absolute; bottom: 80px; right: 0; border-radius: 15px; overflow: hidden; display: flex; flex-direction: column; background-color: white;">
        
        <!-- Header -->
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center" style="border-bottom: none; padding: 15px;">
            <div class="d-flex align-items-center">
                <div class="bg-white text-success rounded-circle d-flex justify-content-center align-items-center me-2" style="width: 35px; height: 35px;">
                    <i class="fas fa-seedling"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold">MarketLink AI</h6>
                    <small style="font-size: 0.75rem; opacity: 0.8;">Online | Local Assistant</small>
                </div>
            </div>
            <button id="ml-chatbot-close" class="btn text-white p-0" style="background: transparent; border: none;">
                <i class="fas fa-times fa-lg"></i>
            </button>
        </div>

        <!-- Chat Area -->
        <div id="ml-chatbot-messages" class="card-body bg-light" style="flex-grow: 1; overflow-y: auto; padding: 15px;">
            <!-- Welcome Message -->
            <div class="d-flex mb-3 animate-chatBubblePop">
                <div class="bg-success text-white rounded-circle d-flex justify-content-center align-items-center me-2 flex-shrink-0" style="width: 30px; height: 30px; align-self: flex-end;">
                    <i class="fas fa-seedling" style="font-size: 0.8rem;"></i>
                </div>
                <div class="bg-white p-2 shadow-sm rounded-3" style="max-width: 80%; border-bottom-left-radius: 0;">
                    <p class="mb-0" style="font-size: 0.9rem; color: #333;">Hi! I am the MarketLink Assistant. I can help you find markets, farmers, and fresh products. What would you like to know?</p>
                </div>
            </div>
            
            <!-- Quick Replies -->
            <div class="d-flex flex-wrap gap-2 mb-3" id="ml-chatbot-quick-replies">
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Where can I find tomatoes?</button>
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Which markets are open today?</button>
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Find me fresh organic eggs</button>
            </div>
        </div>

        <!-- Input Area -->
        <div class="card-footer bg-white p-2" style="border-top: 1px solid #eee;">
            <div class="input-group">
                <button class="btn btn-link text-muted" type="button" style="text-decoration: none;">
                    <i class="fas fa-paperclip"></i>
                </button>
                <input type="text" id="ml-chatbot-input" class="form-control border-0" placeholder="Type your message..." style="box-shadow: none; font-size: 0.9rem;" autocomplete="off">
                <button id="ml-chatbot-send" class="btn text-success" type="button" style="background: transparent; border: none;">
                    <i class="fas fa-paper-plane fa-lg"></i>
                </button>
            </div>
        </div>
    </div>
</div>
`;

// Only inject if not on the main ai-assistant page
if (!document.getElementById('ai-assistant-page-marker')) {
    document.addEventListener('DOMContentLoaded', () => {
        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
        initChatbot();
    });
}

function initChatbot() {
    const toggleBtn = document.getElementById('ml-chatbot-toggle');
    const closeBtn = document.getElementById('ml-chatbot-close');
    const widget = document.getElementById('ml-chatbot-widget');
    const messagesContainer = document.getElementById('ml-chatbot-messages');
    const inputField = document.getElementById('ml-chatbot-input');
    const sendBtn = document.getElementById('ml-chatbot-send');
    const quickReplies = document.querySelectorAll('.chat-quick-reply');

    // Toggle widget
    toggleBtn.addEventListener('click', () => {
        widget.classList.toggle('d-none');
        if (!widget.classList.contains('d-none')) {
            inputField.focus();
        }
    });

    closeBtn.addEventListener('click', () => {
        widget.classList.add('d-none');
    });

    // Send Message Event
    sendBtn.addEventListener('click', handleSendMessage);
    inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSendMessage();
    });

    // Quick Replies
    quickReplies.forEach(btn => {
        btn.addEventListener('click', function() {
            inputField.value = this.innerText;
            handleSendMessage();
            document.getElementById('ml-chatbot-quick-replies').style.display = 'none';
        });
    });

    function handleSendMessage() {
        const text = inputField.value.trim();
        if (text === '') return;
        
        // Add User Message
        addUserMessage(text);
        inputField.value = '';

        // Hide quick replies if visible
        const qrContainer = document.getElementById('ml-chatbot-quick-replies');
        if(qrContainer) qrContainer.style.display = 'none';

        // Add Bot Typing indicator (optional, but let's just go direct to response with slight delay)
        setTimeout(() => {
            const response = getBotResponse(text);
            addBotMessage(response);
        }, 600);
    }

    function addUserMessage(text) {
        const html = \`
        <div class="d-flex mb-3 justify-content-end animate-chatBubblePop">
            <div class="bg-success text-white p-2 shadow-sm rounded-3" style="max-width: 80%; border-bottom-right-radius: 0;">
                <p class="mb-0" style="font-size: 0.9rem;">\${escapeHTML(text)}</p>
            </div>
        </div>\`;
        messagesContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    function addBotMessage(text) {
        // Create element
        const wrapper = document.createElement('div');
        wrapper.className = 'd-flex mb-3 animate-chatBubblePop';
        
        const avatar = document.createElement('div');
        avatar.className = 'bg-success text-white rounded-circle d-flex justify-content-center align-items-center me-2 flex-shrink-0';
        avatar.style = 'width: 30px; height: 30px; align-self: flex-end;';
        avatar.innerHTML = '<i class="fas fa-seedling" style="font-size: 0.8rem;"></i>';
        
        const bubble = document.createElement('div');
        bubble.className = 'bg-white p-2 shadow-sm rounded-3';
        bubble.style = 'max-width: 80%; border-bottom-left-radius: 0;';
        
        const p = document.createElement('p');
        p.className = 'mb-0';
        p.style = 'font-size: 0.9rem; color: #333;';
        
        bubble.appendChild(p);
        wrapper.appendChild(avatar);
        wrapper.appendChild(bubble);
        messagesContainer.appendChild(wrapper);
        
        // Typewriter effect
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                p.innerHTML += text.charAt(i);
                i++;
                scrollToBottom();
                setTimeout(typeWriter, 15);
            }
        }
        typeWriter();
    }

    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
        );
    }
}

// Logic for responses exported so AI Assistant full page can use it too
window.getBotResponse = function(input) {
    const text = input.toLowerCase();
    
    if (text.includes('tomato') || text.includes('tomatoes')) {
        return 'Tomatoes are available at Green Valley Farm and Sunrise Organics! You can find them at Downtown Market (Tue, Thu, Sat) and Westside Market (Wed, Fri). Current price is PKR 80/kg. Would you like to pre-order?';
    }
    if (text.includes('open today') || text.includes('today')) {
        return 'Today (Thursday), the following markets are open: Downtown Market (8AM-2PM), Northgate Market (9AM-1PM). You can browse their farmers and products right now!';
    }
    if (text.includes('dairy')) {
        return 'For dairy products, check out Happy Cow Dairy Farm at Eastside Market, and Valley Fresh at Downtown Market. They offer fresh milk, yogurt, cheese and eggs every week.';
    }
    if (text.includes('pickup') || text.includes('timings') || text.includes('timing')) {
        return 'Pickup timings vary by market. Downtown Market: 8AM-2PM, Westside: 9AM-3PM, Northgate: 9AM-1PM, Eastside: 7AM-12PM. You can also check specific farmer profiles for their individual pickup windows.';
    }
    if (text.includes('organic')) {
        return 'MarketLink has 12 certified organic farmers! You can filter by typing "organic" in the search bar on the Farmers page, or browse our Products page with Organic filter.';
    }
    if (text.includes('egg') || text.includes('eggs')) {
        return 'Fresh eggs are available from Happy Cow Dairy (Eastside Market, Wed & Sat) and Sunshine Poultry Farm (Downtown Market, Tue-Sat). PKR 150/dozen.';
    }
    if (text.includes('market')) {
        return 'We have 12 local farmers markets across the city! You can explore them on our Markets page. Would you like recommendations based on your location?';
    }
    if (text.includes('farmer')) {
        return 'MarketLink connects you with 200+ verified local farmers. You can browse all farmers, filter by location and specialty, and pre-order directly from their profiles!';
    }
    
    return 'That is a great question! I am still learning. You can try browsing our Products page or Markets directory for what you are looking for. Is there something specific I can help you find?';
};

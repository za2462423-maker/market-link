<?php
$page_title = "Admin Customers - MarketLink ";
$current_page = "admin-customers";
require_once __DIR__ . '/includes/header.php';
?>


  <div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="index.php" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="https://picsum.photos/48/48?random=1" alt="Admin">
        <div>
          <div>Super Admin</div>
          <div>admin@marketlink.com</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="admin-dashboard.php" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="admin-farmers.php" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="admin-customers.php" class="ml-admin-nav-link active"><i class="fas fa-users"></i> Customers</a>
        <a href="admin-markets.php" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="admin-products.php" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="admin-orders.php" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="admin-reviews.php" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="admin-reports.php" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="#" class="ml-admin-nav-link"><i class="fas fa-cog"></i> Settings</a>
        <hr>
        <a href="admin-login.php" class="ml-admin-nav-link ml-admin-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div>
          <h4 class="m-0 fw-bold">Manage Customers</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Customers</p>
                <h3>1,240</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-user-check"></i></div>
              <div class="admin-stat-info">
                <p>Active Customers</p>
                <h3>1,150</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-gray"><i class="fas fa-user-slash"></i></div>
              <div class="admin-stat-info">
                <p>Inactive Customers</p>
                <h3>90</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <input type="text" class="form-control" placeholder="Search customers by name, email, or phone..." style="max-width: 400px;">
            <select class="form-select w-auto">
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Customer</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Location</th>
                  <th>Joined</th>
                  <th>Orders</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=31" alt="Avatar">
                      <strong>Fatima Ali</strong>
                    </div>
                  </td>
                  <td>fatima@example.com</td>
                  <td>0300-1122334</td>
                  <td>Islamabad</td>
                  <td>Mar 12, 2026</td>
                  <td>15</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning" title="Deactivate"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger" title="Delete"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=32" alt="Avatar">
                      <strong>Usman Tariq</strong>
                    </div>
                  </td>
                  <td>usman.t@example.com</td>
                  <td>0321-4455667</td>
                  <td>Rawalpindi</td>
                  <td>Apr 05, 2026</td>
                  <td>8</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=33" alt="Avatar">
                      <strong>Aisha Khan</strong>
                    </div>
                  </td>
                  <td>aisha.k@example.com</td>
                  <td>0333-9988776</td>
                  <td>Islamabad</td>
                  <td>Jan 22, 2026</td>
                  <td>42</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=34" alt="Avatar">
                      <strong>Bilal Qureshi</strong>
                    </div>
                  </td>
                  <td>bilal.q@example.com</td>
                  <td>0345-1234567</td>
                  <td>Islamabad</td>
                  <td>Jun 18, 2026</td>
                  <td>2</td>
                  <td><span class="badge badge-inactive">Inactive</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-success" title="Activate"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=35" alt="Avatar">
                      <strong>Sana Hameed</strong>
                    </div>
                  </td>
                  <td>sana.h@example.com</td>
                  <td>0301-2233445</td>
                  <td>Rawalpindi</td>
                  <td>Jul 30, 2026</td>
                  <td>5</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=36" alt="Avatar">
                      <strong>Omar Farooq</strong>
                    </div>
                  </td>
                  <td>omar.f@example.com</td>
                  <td>0322-8877665</td>
                  <td>Islamabad</td>
                  <td>Feb 14, 2026</td>
                  <td>21</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=37" alt="Avatar">
                      <strong>Hassan Ali</strong>
                    </div>
                  </td>
                  <td>hassan.a@example.com</td>
                  <td>0331-5544332</td>
                  <td>Islamabad</td>
                  <td>Sep 02, 2026</td>
                  <td>0</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="https://picsum.photos/40/40?random=38" alt="Avatar">
                      <strong>Zainab Bibi</strong>
                    </div>
                  </td>
                  <td>zainab.b@example.com</td>
                  <td>0300-9988776</td>
                  <td>Rawalpindi</td>
                  <td>May 10, 2026</td>
                  <td>11</td>
                  <td><span class="badge badge-active">Active</span></td>
                  <td>
                    <button class="btn btn-sm btn-light"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-light text-warning"><i class="fas fa-power-off"></i></button>
                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>

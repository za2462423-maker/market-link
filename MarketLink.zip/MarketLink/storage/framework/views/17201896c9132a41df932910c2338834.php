<?php
    $page_title = "MarketLink - Fresh From Local Farmers to Your Table";
    $current_page = "index";
?>

<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- Page Hero -->
    <div class="bg-light py-4 border-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="fw-bold mb-1">Farm-Fresh Products</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Products</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container py-5">
        <div class="row">
            <!-- Left Filter Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="card-title mb-0 fw-bold">Filters</h5>
                            <a href="#" class="text-decoration-none text-muted small" id="clear-filters">Clear All</a>
                        </div>
                        
                        <!-- Search -->
                        <div class="mb-4">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search products..." id="search-input">
                                <button class="btn btn-outline-secondary" type="button"><i class="fas fa-search"></i></button>
                            </div>
                        </div>

                        <!-- Categories -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Categories</h6>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Vegetables" id="cat-veg">
                                <label class="form-check-label d-flex justify-content-between" for="cat-veg">
                                    Vegetables <span class="text-muted small">(42)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Fruits" id="cat-fruits">
                                <label class="form-check-label d-flex justify-content-between" for="cat-fruits">
                                    Fruits <span class="text-muted small">(28)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Dairy" id="cat-dairy">
                                <label class="form-check-label d-flex justify-content-between" for="cat-dairy">
                                    Dairy <span class="text-muted small">(15)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Baked Goods" id="cat-baked">
                                <label class="form-check-label d-flex justify-content-between" for="cat-baked">
                                    Baked Goods <span class="text-muted small">(19)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Other" id="cat-other">
                                <label class="form-check-label d-flex justify-content-between" for="cat-other">
                                    Other <span class="text-muted small">(8)</span>
                                </label>
                            </div>
                        </div>

                        <!-- Price Range -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Price Range ($)</h6>
                            <div class="d-flex align-items-center">
                                <input type="number" class="form-control form-control-sm" id="min-price" placeholder="Min" min="0">
                                <span class="mx-2">-</span>
                                <input type="number" class="form-control form-control-sm" id="max-price" placeholder="Max" min="0">
                            </div>
                        </div>

                        <!-- Availability -->
                        <div class="mb-4">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="in-stock-only">
                                <label class="form-check-label fw-bold" for="in-stock-only">In Stock Only</label>
                            </div>
                        </div>

                        <!-- Markets -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Markets</h6>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Downtown" id="mkt-dt"><label class="form-check-label" for="mkt-dt">Downtown Market</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Uptown" id="mkt-ut"><label class="form-check-label" for="mkt-ut">Uptown Farmers</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Riverside" id="mkt-rs"><label class="form-check-label" for="mkt-rs">Riverside Organic</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Westside" id="mkt-ws"><label class="form-check-label" for="mkt-ws">Westside Weekend</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Eastside" id="mkt-es"><label class="form-check-label" for="mkt-es">Eastside Community</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" value="Central" id="mkt-c"><label class="form-check-label" for="mkt-c">Central Square</label></div>
                        </div>

                        <!-- Days -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Pickup Days</h6>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-mon"><label class="btn btn-outline-secondary btn-sm" for="day-mon">M</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-tue"><label class="btn btn-outline-secondary btn-sm" for="day-tue">T</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-wed"><label class="btn btn-outline-secondary btn-sm" for="day-wed">W</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-thu"><label class="btn btn-outline-secondary btn-sm" for="day-thu">T</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-fri"><label class="btn btn-outline-secondary btn-sm" for="day-fri">F</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-sat"><label class="btn btn-outline-secondary btn-sm" for="day-sat">S</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" id="day-sun"><label class="btn btn-outline-secondary btn-sm" for="day-sun">S</label></div>
                            </div>
                        </div>

                        <!-- Rating -->
                        <div>
                            <h6 class="fw-bold mb-2">Minimum Rating</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="rating-filter" id="rate-4" value="4">
                                <label class="form-check-label text-warning" for="rate-4">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i> & Up
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="rating-filter" id="rate-3" value="3">
                                <label class="form-check-label text-warning" for="rate-3">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i> & Up
                                </label>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Right Content -->
            <div class="col-lg-9">
                <!-- Top Bar -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 p-3 bg-white rounded shadow-sm border">
                    <p class="mb-2 mb-md-0 fw-medium">Showing <span id="product-count">12</span> products</p>
                    <div class="d-flex align-items-center">
                        <select class="form-select form-select-sm me-3 w-auto" id="sort-select">
                            <option value="newest">Newest</option>
                            <option value="price-asc">Price: Low to High</option>
                            <option value="price-desc">Price: High to Low</option>
                            <option value="rating">Highest Rated</option>
                            <option value="name">Name: A to Z</option>
                        </select>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-secondary active" id="btn-grid"><i class="fas fa-th"></i></button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="btn-list"><i class="fas fa-list"></i></button>
                        </div>
                    </div>
                </div>

                <!-- Product Grid -->
                <div class="row g-4" id="product-grid">
                    <!-- Products will be generated here -->
                </div>
                
                <!-- Product List (hidden by default) -->
                <div class="d-none" id="product-list">
                    <!-- List items will be generated here -->
                </div>

                <!-- Pagination -->
                <nav class="mt-5" aria-label="Product pagination">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled"><a class="page-link" href="#" tabindex="-1">Previous</a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Quick View Modal -->
    <div class="modal fade" id="quickViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-0" id="quick-view-content">
                    <!-- Content populated by JS -->
                </div>
            </div>
        </div>
    </div>

    <!-- Toast for Add to Cart -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="cartToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Item added to cart successfully!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Footer -->
<?php
@include('includes.footer')
?>

<?php /**PATH C:\Users\DELL\OneDrive\Desktop\MarketLink\resources\views/products.blade.php ENDPATH**/ ?>
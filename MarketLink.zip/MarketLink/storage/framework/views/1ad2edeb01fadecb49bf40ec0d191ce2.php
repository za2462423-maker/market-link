<?php
    $page_title = "MarketLink - Fresh From Local Farmers to Your Table";
    $current_page = "index";
?>

<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main>
    <!-- HERO SECTION -->
        <!-- HERO SECTION -->
        <section class="ml-hero d-flex align-items-center" style="background: linear-gradient(rgba(24, 61, 38, 0.8), rgba(24, 61, 38, 0.8)), url('https://images.unsplash.com/photo-1542838132-92c53300491e?w=1600') no-repeat center center/cover; min-height: 100vh;">
            <div class="container text-center text-white">
                <h1 class="display-3 fw-bold mb-4 ml-hero-title">Fresh From Local Farmers to Your Table</h1>
                <p class="lead mb-5 ml-hero-subtitle">Discover seasonal produce, support your local community, and eat healthier.</p>
                
                <div class="ml-search-widget bg-white p-3 rounded-4 shadow-lg mx-auto mb-5" style="max-width: 800px;">
                    <ul class="nav nav-pills mb-3 justify-content-center" id="search-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="products-tab" data-bs-toggle="pill" data-bs-target="#products" type="button" role="tab" aria-controls="products" aria-selected="true">Products</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="farmers-tab" data-bs-toggle="pill" data-bs-target="#farmers" type="button" role="tab" aria-controls="farmers" aria-selected="false">Farmers</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="markets-tab" data-bs-toggle="pill" data-bs-target="#markets" type="button" role="tab" aria-controls="markets" aria-selected="false">Markets</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="search-tabs-content">
                        <div class="tab-pane fade show active" id="products" role="tabpanel" aria-labelledby="products-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search for fresh tomatoes, honey..." aria-label="Search Products">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="farmers" role="tabpanel" aria-labelledby="farmers-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search farmer name or specialty..." aria-label="Search Farmers">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="markets" role="tabpanel" aria-labelledby="markets-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search market by city or zip..." aria-label="Search Markets">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-3 flex-wrap">
                    <a href="markets.php" class="btn btn-lg ml-btn-primary px-4 py-3">Explore Markets</a>
                    <a href="products.php" class="btn btn-lg ml-btn-outline-light px-4 py-3">Browse Products</a>
                </div>
            </div>
        </section>

        <!-- STATS BAR -->
        <section class="ml-stats py-5 bg-light">
            <div class="container">
                <div class="row text-center g-4">
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0"><span class="ml-counter">50</span>+</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Active Markets</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0"><span class="ml-counter">200</span>+</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Local Farmers</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0"><span class="ml-counter">1000</span>+</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Fresh Products</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0"><span class="ml-counter">5000</span>+</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Happy Customers</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- FEATURED MARKETS -->
        <section class="ml-featured-markets py-5">
            <div class="container py-4">
                <div class="d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <h2 class="fw-bold mb-2">Featured Markets</h2>
                        <div class="ml-underline"></div>
                    </div>
                    <a href="markets.php" class="btn ml-btn-outline-green d-none d-md-inline-block">View All Markets <i class="fas fa-arrow-right ms-1"></i></a>
                </div>

                <div class="row g-4">
                    <!-- Market 1 -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 ml-market-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/600/400?random=1" class="card-img-top object-fit-cover" alt="Downtown Farmers Market" height="250">
                                <span class="badge bg-success position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">Open Today</span>
                            </div>
                            <div class="card-body p-4">
                                <h5 class="card-title fw-bold">Downtown Farmers Market</h5>
                                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt text-danger me-2"></i> 123 Main St, City Center</p>
                                <p class="text-muted small mb-3"><i class="far fa-clock text-primary me-2"></i> Saturdays, 8:00 AM - 1:00 PM</p>
                                <hr>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="small fw-medium"><i class="fas fa-user-friends me-1"></i> 24 Farmers</span>
                                    <a href="market-details.php" class="btn ml-btn-primary btn-sm px-3">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Market 2 -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 ml-market-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/600/400?random=2" class="card-img-top object-fit-cover" alt="Riverside Organic Market" height="250">
                                <span class="badge bg-secondary position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">Sundays</span>
                            </div>
                            <div class="card-body p-4">
                                <h5 class="card-title fw-bold">Riverside Organic Market</h5>
                                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt text-danger me-2"></i> 45 River Rd, Westside</p>
                                <p class="text-muted small mb-3"><i class="far fa-clock text-primary me-2"></i> Sundays, 9:00 AM - 2:00 PM</p>
                                <hr>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="small fw-medium"><i class="fas fa-user-friends me-1"></i> 18 Farmers</span>
                                    <a href="market-details.php" class="btn ml-btn-primary btn-sm px-3">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Market 3 -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 ml-market-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/600/400?random=3" class="card-img-top object-fit-cover" alt="Community Square Market" height="250">
                                <span class="badge bg-secondary position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">Wednesdays</span>
                            </div>
                            <div class="card-body p-4">
                                <h5 class="card-title fw-bold">Community Square Market</h5>
                                <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt text-danger me-2"></i> 789 Square Ave, North District</p>
                                <p class="text-muted small mb-3"><i class="far fa-clock text-primary me-2"></i> Wednesdays, 3:00 PM - 7:00 PM</p>
                                <hr>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="small fw-medium"><i class="fas fa-user-friends me-1"></i> 15 Farmers</span>
                                    <a href="market-details.php" class="btn ml-btn-primary btn-sm px-3">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center mt-4 d-md-none">
                    <a href="markets.php" class="btn ml-btn-outline-green w-100">View All Markets</a>
                </div>
            </div>
        </section>

        <!-- HOW IT WORKS -->
        <section class="ml-how-it-works py-5 bg-light">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">How It Works</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row text-center position-relative g-4">
                    <!-- Dashed line connecting steps (hidden on mobile) -->
                    <div class="position-absolute top-50 start-50 translate-middle w-75 d-none d-lg-block" style="border-top: 2px dashed #a3b18a; z-index: 1;"></div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-map-marker-alt fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">1. Find a Market</h5>
                        <p class="text-muted small">Locate nearby farmers markets and check their operating hours.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-shopping-basket fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">2. Browse Products</h5>
                        <p class="text-muted small">Explore fresh, seasonal produce available from local farmers.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-clipboard-list fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">3. Pre-Order</h5>
                        <p class="text-muted small">Secure your favorites by ordering online before market day.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-shopping-bag fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">4. Pick Up</h5>
                        <p class="text-muted small">Visit the market and collect your fresh goods directly from the farmer.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- FEATURED FARMERS -->
        <section class="ml-featured-farmers py-5">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">Meet Our Farmers</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row g-4">
                    <!-- Farmer 1 -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card h-100 ml-farmer-card border-0 shadow-sm text-center p-4 rounded-4 position-relative">
                            <button class="btn btn-light rounded-circle position-absolute top-0 end-0 m-3 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                <i class="far fa-heart"></i>
                            </button>
                            <img src="https://picsum.photos/200/200?random=11" class="rounded-circle mx-auto mb-3 object-fit-cover shadow-sm" alt="Farmer Jane" width="100" height="100">
                            <h5 class="fw-bold mb-1">Jane Doe</h5>
                            <p class="text-muted small mb-2">Sunrise Organic Farm</p>
                            <div class="text-warning small mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> (4.8)
                            </div>
                            <div class="d-flex flex-wrap justify-content-center gap-1 mb-4">
                                <span class="badge bg-light text-dark border">Vegetables</span>
                                <span class="badge bg-light text-dark border">Fruits</span>
                            </div>
                            <a href="farmer-profile.php" class="btn ml-btn-outline-green w-100 mt-auto">View Profile</a>
                        </div>
                    </div>
                    <!-- Farmer 2 -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card h-100 ml-farmer-card border-0 shadow-sm text-center p-4 rounded-4 position-relative">
                            <button class="btn btn-light rounded-circle position-absolute top-0 end-0 m-3 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                <i class="far fa-heart"></i>
                            </button>
                            <img src="https://picsum.photos/200/200?random=12" class="rounded-circle mx-auto mb-3 object-fit-cover shadow-sm" alt="Farmer John" width="100" height="100">
                            <h5 class="fw-bold mb-1">John Smith</h5>
                            <p class="text-muted small mb-2">Smith Family Dairy</p>
                            <div class="text-warning small mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i> (5.0)
                            </div>
                            <div class="d-flex flex-wrap justify-content-center gap-1 mb-4">
                                <span class="badge bg-light text-dark border">Dairy</span>
                                <span class="badge bg-light text-dark border">Cheese</span>
                            </div>
                            <a href="farmer-profile.php" class="btn ml-btn-outline-green w-100 mt-auto">View Profile</a>
                        </div>
                    </div>
                    <!-- Farmer 3 -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card h-100 ml-farmer-card border-0 shadow-sm text-center p-4 rounded-4 position-relative">
                            <button class="btn btn-light rounded-circle position-absolute top-0 end-0 m-3 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                <i class="far fa-heart"></i>
                            </button>
                            <img src="https://picsum.photos/200/200?random=13" class="rounded-circle mx-auto mb-3 object-fit-cover shadow-sm" alt="Farmer Alice" width="100" height="100">
                            <h5 class="fw-bold mb-1">Alice Johnson</h5>
                            <p class="text-muted small mb-2">Green Leaf Apiary</p>
                            <div class="text-warning small mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i> (4.0)
                            </div>
                            <div class="d-flex flex-wrap justify-content-center gap-1 mb-4">
                                <span class="badge bg-light text-dark border">Honey</span>
                                <span class="badge bg-light text-dark border">Beeswax</span>
                            </div>
                            <a href="farmer-profile.php" class="btn ml-btn-outline-green w-100 mt-auto">View Profile</a>
                        </div>
                    </div>
                    <!-- Farmer 4 -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card h-100 ml-farmer-card border-0 shadow-sm text-center p-4 rounded-4 position-relative">
                            <button class="btn btn-light rounded-circle position-absolute top-0 end-0 m-3 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                <i class="far fa-heart"></i>
                            </button>
                            <img src="https://picsum.photos/200/200?random=14" class="rounded-circle mx-auto mb-3 object-fit-cover shadow-sm" alt="Farmer Bob" width="100" height="100">
                            <h5 class="fw-bold mb-1">Bob Williams</h5>
                            <p class="text-muted small mb-2">Williams Orchards</p>
                            <div class="text-warning small mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> (4.7)
                            </div>
                            <div class="d-flex flex-wrap justify-content-center gap-1 mb-4">
                                <span class="badge bg-light text-dark border">Apples</span>
                                <span class="badge bg-light text-dark border">Cider</span>
                            </div>
                            <a href="farmer-profile.php" class="btn ml-btn-outline-green w-100 mt-auto">View Profile</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- POPULAR PRODUCTS -->
        <section class="ml-popular-products py-5 bg-light">
            <div class="container py-4">
                <div class="d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <h2 class="fw-bold mb-2">Popular Products</h2>
                        <div class="ml-underline"></div>
                    </div>
                    <a href="products.php" class="btn ml-btn-outline-green d-none d-md-inline-block">Shop All <i class="fas fa-arrow-right ms-1"></i></a>
                </div>

                <div class="row g-4">
                    <!-- Product 1 -->
                    <div class="col-6 col-lg-3">
                        <div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/400/300?random=21" class="card-img-top object-fit-cover" alt="Heirloom Tomatoes" height="200">
                                <button class="btn btn-light btn-sm rounded-circle position-absolute top-0 end-0 m-2 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <div class="card-body p-3">
                                <a href="farmer-profile.php" class="text-muted small text-decoration-none">Sunrise Organic Farm</a>
                                <h6 class="card-title fw-bold mt-1 mb-2">Heirloom Tomatoes</h6>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="fw-bold fs-5 ml-text-green">$4.99 <small class="text-muted fs-6 fw-normal">/ lb</small></span>
                                    <button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm" aria-label="Add to Cart" style="width:36px; height:36px;"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Product 2 -->
                    <div class="col-6 col-lg-3">
                        <div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/400/300?random=22" class="card-img-top object-fit-cover" alt="Wildflower Honey" height="200">
                                <button class="btn btn-light btn-sm rounded-circle position-absolute top-0 end-0 m-2 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <div class="card-body p-3">
                                <a href="farmer-profile.php" class="text-muted small text-decoration-none">Green Leaf Apiary</a>
                                <h6 class="card-title fw-bold mt-1 mb-2">Wildflower Honey</h6>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="fw-bold fs-5 ml-text-green">$9.50 <small class="text-muted fs-6 fw-normal">/ jar</small></span>
                                    <button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm" aria-label="Add to Cart" style="width:36px; height:36px;"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Product 3 -->
                    <div class="col-6 col-lg-3">
                        <div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/400/300?random=23" class="card-img-top object-fit-cover" alt="Artisan Cheese" height="200">
                                <button class="btn btn-light btn-sm rounded-circle position-absolute top-0 end-0 m-2 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                    <i class="far fa-heart"></i>
                                </button>
                                <span class="badge bg-danger position-absolute top-0 start-0 m-2">Sale</span>
                            </div>
                            <div class="card-body p-3">
                                <a href="farmer-profile.php" class="text-muted small text-decoration-none">Smith Family Dairy</a>
                                <h6 class="card-title fw-bold mt-1 mb-2">Artisan Cheddar Cheese</h6>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="fw-bold fs-5 ml-text-green">$7.99 <small class="text-muted text-decoration-line-through fs-6 fw-normal">$9.99</small></span>
                                    <button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm" aria-label="Add to Cart" style="width:36px; height:36px;"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Product 4 -->
                    <div class="col-6 col-lg-3">
                        <div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">
                            <div class="position-relative">
                                <img src="https://picsum.photos/400/300?random=24" class="card-img-top object-fit-cover" alt="Fresh Apples" height="200">
                                <button class="btn btn-light btn-sm rounded-circle position-absolute top-0 end-0 m-2 shadow-sm text-danger ml-fav-btn" aria-label="Favorite">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <div class="card-body p-3">
                                <a href="farmer-profile.php" class="text-muted small text-decoration-none">Williams Orchards</a>
                                <h6 class="card-title fw-bold mt-1 mb-2">Fuji Apples (Basket)</h6>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="fw-bold fs-5 ml-text-green">$12.00 <small class="text-muted fs-6 fw-normal">/ basket</small></span>
                                    <button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm" aria-label="Add to Cart" style="width:36px; height:36px;"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center mt-4 d-md-none">
                    <a href="products.php" class="btn ml-btn-outline-green w-100">Shop All Products</a>
                </div>
            </div>
        </section>

        <!-- BENEFITS / TWO COLUMNS -->
        <section class="ml-benefits py-5">
            <div class="container py-4">
                <div class="row g-5 align-items-center">
                    <!-- Customer Benefits -->
                    <div class="col-lg-6">
                        <h2 class="fw-bold mb-4">Why Shop With MarketLink?</h2>
                        <div class="row g-4 mt-2">
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-truck-slash"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">No Shipping Wait</h5>
                                    <p class="text-muted">Pick up directly from the market. No long delivery times or lost packages.</p>
                                </div>
                            </div>
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-leaf"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">Fresh & Seasonal</h5>
                                    <p class="text-muted">Enjoy produce picked at peak ripeness, ensuring better taste and nutrition.</p>
                                </div>
                            </div>
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-hand-holding-heart"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">Support Local</h5>
                                    <p class="text-muted">Keep your money in the community and support local agriculture directly.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Farmer Benefits -->
                    <div class="col-lg-6">
                        <div class="bg-light p-5 rounded-4 position-relative">
                            <div class="position-absolute top-0 end-0 p-3 text-success opacity-25">
                                <i class="fas fa-seedling fa-5x"></i>
                            </div>
                            <h2 class="fw-bold mb-4 position-relative z-1">Are You a Farmer?</h2>
                            <p class="mb-4 position-relative z-1 text-muted">Join our platform to expand your reach, manage pre-orders, and connect with more customers.</p>
                            <ul class="list-unstyled mb-4 position-relative z-1">
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Reach thousands of local customers</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Reduce waste with pre-orders</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Easy inventory and sales management</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Secure online payments</li>
                            </ul>
                            <a href="farmer-register.php" class="btn ml-btn-primary position-relative z-1">Join as Farmer</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- TESTIMONIALS -->
        <section class="ml-testimonials py-5 bg-light">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">What Our Community Says</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card h-100 border-0 shadow-sm p-4 rounded-4">
                            <div class="text-warning mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <p class="fst-italic text-muted mb-4">"MarketLink has completely changed how I shop. I love being able to pre-order my favorite sourdough bread so it doesn't sell out before I get to the market!"</p>
                            <div class="d-flex align-items-center gap-3 mt-auto">
                                <img src="https://picsum.photos/100/100?random=31" class="rounded-circle" alt="User" width="50" height="50">
                                <div>
                                    <h6 class="fw-bold mb-0">Sarah Jenkins</h6>
                                    <small class="text-muted">Customer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 border-0 shadow-sm p-4 rounded-4">
                            <div class="text-warning mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <p class="fst-italic text-muted mb-4">"As a small farm, knowing how much to harvest for market day was always a gamble. With pre-orders on MarketLink, our food waste is down and profits are up."</p>
                            <div class="d-flex align-items-center gap-3 mt-auto">
                                <img src="https://picsum.photos/100/100?random=32" class="rounded-circle" alt="User" width="50" height="50">
                                <div>
                                    <h6 class="fw-bold mb-0">Mike R.</h6>
                                    <small class="text-muted">Farmer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 border-0 shadow-sm p-4 rounded-4">
                            <div class="text-warning mb-3">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                            </div>
                            <p class="fst-italic text-muted mb-4">"The platform is so easy to use. I can find new farmers markets in my area, check what's in season, and support my local community. Highly recommend!"</p>
                            <div class="d-flex align-items-center gap-3 mt-auto">
                                <img src="https://picsum.photos/100/100?random=33" class="rounded-circle" alt="User" width="50" height="50">
                                <div>
                                    <h6 class="fw-bold mb-0">Emily Davis</h6>
                                    <small class="text-muted">Customer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- MAP PREVIEW -->
        <section class="ml-map-preview py-5">
            <div class="container py-4 text-center">
                <h2 class="fw-bold mb-4">Explore Markets Near You</h2>
                <div class="rounded-4 overflow-hidden shadow-sm" style="height: 400px; background-color: #e5e3df; position: relative;">
                    <!-- Placeholder for Map -->
                    <div class="d-flex flex-column align-items-center justify-content-center h-100 w-100" style="background: url('https://picsum.photos/1200/400?random=40') center/cover; position: relative;">
                        <div class="position-absolute top-0 start-0 w-100 h-100" style="background-color: rgba(43, 91, 63, 0.4);"></div>
                        <div class="position-relative z-1 text-white">
                            <i class="fas fa-map-marked-alt fa-4x mb-3"></i>
                            <h4 class="fw-bold">Interactive Map Available</h4>
                            <p>Find markets, farmers, and events in your area.</p>
                            <a href="markets.php" class="btn ml-btn-primary mt-2">Open Map</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- NEWSLETTER -->
        <section class="ml-newsletter py-5 text-white" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-4">
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0 text-center text-lg-start">
                        <h3 class="fw-bold mb-2">Stay Fresh!</h3>
                        <p class="mb-0 text-white-50">Subscribe to our newsletter for seasonal updates, new farm alerts, and market events.</p>
                    </div>
                    <div class="col-lg-6">
                        <form class="bg-white p-2 rounded-pill shadow-sm d-flex">
                            <input type="email" class="form-control border-0 rounded-pill px-4 shadow-none" placeholder="Enter your email address" aria-label="Email Address" required>
                            <button type="submit" class="btn ml-btn-primary rounded-pill px-4">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    
<?php
@include('includes.footer')
?>
<?php /**PATH C:\Users\DELL\OneDrive\Desktop\MarketLink\resources\views/index.blade.php ENDPATH**/ ?>
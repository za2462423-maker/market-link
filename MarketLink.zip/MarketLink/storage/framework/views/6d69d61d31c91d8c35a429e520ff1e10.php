<?php
    $page_title = "MarketLink - Fresh From Local Farmers to Your Table";
    $current_page = "index";
?>

<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Page Hero -->
    <section class="hero-section">
        <div class="container">
            <h1>Discover Local Markets</h1>
            <p class="lead mb-4">Find the freshest produce and support local farmers near you.</p>
            <div class="search-wrapper">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-search text-muted"></i></span>
                    <input type="text" id="heroSearch" class="form-control border-start-0" placeholder="Search markets by name or city...">
                    <button class="btn btn-dark px-4" type="button" onclick="document.getElementById('searchInput').value = document.getElementById('heroSearch').value; applyFilters();">Search</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-4">
            <!-- Left Sidebar (Filters) -->
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px; z-index: 10;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="card-title mb-0 fw-bold">Filters</h5>
                            <button class="btn btn-sm btn-link text-muted text-decoration-none p-0" id="clearFiltersBtn">Clear all</button>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Search</label>
                            <input type="text" class="form-control form-control-sm" id="searchInput" placeholder="Search by name...">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Location</label>
                            <select class="form-select form-select-sm" id="locationFilter">
                                <option value="all">All Locations</option>
                                <option value="Downtown">Downtown</option>
                                <option value="Westside">Westside</option>
                                <option value="Eastside">Eastside</option>
                                <option value="Northgate">Northgate</option>
                                <option value="South End">South End</option>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Operating Days</label>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Monday" id="dayMon">
                                <label class="form-check-label" for="dayMon">Monday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Tuesday" id="dayTue">
                                <label class="form-check-label" for="dayTue">Tuesday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Wednesday" id="dayWed">
                                <label class="form-check-label" for="dayWed">Wednesday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Thursday" id="dayThu">
                                <label class="form-check-label" for="dayThu">Thursday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Friday" id="dayFri">
                                <label class="form-check-label" for="dayFri">Friday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Saturday" id="daySat">
                                <label class="form-check-label" for="daySat">Saturday</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input day-filter" type="checkbox" value="Sunday" id="daySun">
                                <label class="form-check-label" for="daySun">Sunday</label>
                            </div>
                        </div>
                        
                        <button class="btn btn-success w-100" id="applyFiltersBtn">Apply Filters</button>
                    </div>
                </div>
            </div>
            
            <!-- Right Content (Market Cards) -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h6 class="mb-0 text-muted" id="resultsCount">Showing 6 markets</h6>
                    <div class="d-flex align-items-center">
                        <span class="me-2 text-muted small">Sort by:</span>
                        <select class="form-select form-select-sm border-0 bg-light" style="width: auto;">
                            <option value="nearest">Nearest</option>
                            <option value="az">A-Z</option>
                            <option value="farmers">Most Farmers</option>
                        </select>
                    </div>
                </div>
                
                <div class="row g-4" id="marketsGrid">
                    <!-- Market Card 1 -->
                    <div class="col-md-6 market-item" data-name="Downtown Farmers Market" data-location="Downtown" data-days="Saturday,Sunday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1533900298318-6b8da08a523e?auto=format&fit=crop&q=80&w=400&h=240" alt="Downtown Farmers Market">
                            <div class="market-card-body">
                                <h3 class="market-title">Downtown Farmers Market</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> 100 Main St, Downtown</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 8:00 AM - 2:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 45 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Saturday</span>
                                    <span class="chip">Sunday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Market Card 2 -->
                    <div class="col-md-6 market-item" data-name="Westside Community Market" data-location="Westside" data-days="Wednesday,Saturday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&q=80&w=400&h=240" alt="Westside Community Market">
                            <div class="market-card-body">
                                <h3 class="market-title">Westside Community Market</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> 550 West Ave, Westside</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 7:00 AM - 1:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 32 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Wednesday</span>
                                    <span class="chip">Saturday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Market Card 3 -->
                    <div class="col-md-6 market-item" data-name="Eastside Organic Market" data-location="Eastside" data-days="Sunday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1519999482648-25049ddd37b1?auto=format&fit=crop&q=80&w=400&h=240" alt="Eastside Organic Market">
                            <div class="market-card-body">
                                <h3 class="market-title">Eastside Organic Market</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> 320 East Blvd, Eastside</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 9:00 AM - 3:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 28 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Sunday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Market Card 4 -->
                    <div class="col-md-6 market-item" data-name="Northgate Weekly Market" data-location="Northgate" data-days="Thursday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400&h=240" alt="Northgate Weekly Market">
                            <div class="market-card-body">
                                <h3 class="market-title">Northgate Weekly Market</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> 800 North Rd, Northgate</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 3:00 PM - 7:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 15 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Thursday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Market Card 5 -->
                    <div class="col-md-6 market-item" data-name="South End Producers" data-location="South End" data-days="Saturday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1603048297172-c92544798d5e?auto=format&fit=crop&q=80&w=400&h=240" alt="South End Producers">
                            <div class="market-card-body">
                                <h3 class="market-title">South End Producers</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> 1200 South St, South End</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 8:00 AM - 1:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 40 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Saturday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Market Card 6 -->
                    <div class="col-md-6 market-item" data-name="City Center Night Market" data-location="Downtown" data-days="Friday">
                        <div class="market-card">
                            <img src="https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&q=80&w=400&h=240" alt="City Center Night Market">
                            <div class="market-card-body">
                                <h3 class="market-title">City Center Night Market</h3>
                                <div class="market-meta">
                                    <div class="mb-1"><i class="fa-solid fa-location-dot"></i> Plaza Square, Downtown</div>
                                    <div class="mb-1"><i class="fa-regular fa-clock"></i> 5:00 PM - 10:00 PM</div>
                                    <div><i class="fa-solid fa-users"></i> 25 Farmers</div>
                                </div>
                                <div class="mb-3">
                                    <span class="chip">Friday</span>
                                </div>
                                <div class="mt-auto">
                                    <a href="market-details.php" class="btn btn-outline-success w-100">View Market</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Pagination -->
                <nav class="mt-5">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled"><a class="page-link" href="#" tabindex="-1">Previous</a></li>
                        <li class="page-item active"><a class="page-link bg-success border-success" href="#">1</a></li>
                        <li class="page-item"><a class="page-link text-success" href="#">2</a></li>
                        <li class="page-item"><a class="page-link text-success" href="#">3</a></li>
                        <li class="page-item"><a class="page-link text-success" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Map Section -->
    <section class="map-section">
        <div class="container">
            <div class="text-center mb-4">
                <h2 class="fw-bold">Markets on the Map</h2>
                <p class="text-muted">Find a market conveniently located near you.</p>
            </div>
            <div class="map-container">
                <div class="text-center text-success fw-bold fs-4 position-absolute" style="z-index: 1;">
                    <i class="fa-solid fa-map-location-dot fs-1 mb-2"></i><br>
                    Interactive Map Area
                </div>
                <div class="map-marker" style="top: 20%; left: 30%;" title="Downtown Farmers Market">1</div>
                <div class="map-marker" style="top: 50%; left: 60%;" title="Westside Community Market">2</div>
                <div class="map-marker" style="top: 70%; left: 20%;" title="South End Producers">3</div>
                <div class="map-marker" style="top: 30%; left: 80%;" title="Eastside Organic Market">4</div>
                
                <div class="position-absolute bottom-0 start-50 translate-middle-x mb-3" style="z-index: 2;">
                    <button class="btn btn-light shadow-sm"><i class="fa-solid fa-location-arrow text-success me-2"></i>Use My Location</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    
<?php
@include('includes.footer')
?>
<?php /**PATH C:\Users\DELL\OneDrive\Desktop\MarketLink\resources\views/markets.blade.php ENDPATH**/ ?>